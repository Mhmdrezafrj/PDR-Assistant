package com.pdrassistant.app

import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.domain.RelatedExperiences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RelatedExperiencesTest {

    private fun exp(
        id: Long, part: String = "", damage: String = "", repair: String = "PDR",
        confidence: String = "UNSURE", updated: Long = 0
    ) = Experience(
        id = id, title = "t$id", repairType = repair, carPart = part, damageType = damage,
        confidence = confidence, createdAt = 0, updatedAt = updated
    )

    @Test fun normalizeUnifiesArabicLettersAndSpaces() {
        assertEquals("درب جلو", RelatedExperiences.normalize("  درب   جلو "))
        assertEquals(RelatedExperiences.normalize("كاپوت"), RelatedExperiences.normalize("کاپوت"))
        assertEquals(RelatedExperiences.normalize("ي"), RelatedExperiences.normalize("ی"))
    }

    @Test fun exactPartAndDamageRanksFirst() {
        val a = exp(1, part = "درب جلو", damage = "فرورفتگی ساده")
        val b = exp(2, part = "درب جلو")
        val c = exp(3, part = "کاپوت")
        val r = RelatedExperiences.rank("PDR", "درب جلو", "فرورفتگی ساده", listOf(c, b, a))
        // a: قطعه+آسیب+نوع (۸)، b: قطعه+نوع (۵)، c: فقط نوع تعمیر (۲)
        assertEquals(listOf(1L, 2L, 3L), r.map { it.experience.id })
        assertEquals(listOf(8, 5, 2), r.map { it.score })
    }

    @Test fun noMatchGivesEmptyList() {
        val r = RelatedExperiences.rank("PAINT", "سقف", "تگرگ‌زدگی", listOf(exp(1, "درب", "چروک", "PDR")))
        assertTrue(r.isEmpty())
    }

    @Test fun blankFieldsNeverMatchEachOther() {
        // قطعه خالی در هر دو طرف نباید امتیاز بدهد
        val r = RelatedExperiences.rank("", "", "", listOf(exp(1, "", "", "PDR")))
        assertTrue(r.isEmpty())
    }

    @Test fun excludesGivenIdAndHonorsLimit() {
        val list = (1L..10L).map { exp(it, part = "درب") }
        val r = RelatedExperiences.rank("PDR", "درب", "", list, excludeId = 3, limit = 4)
        assertEquals(4, r.size)
        assertTrue(r.none { it.experience.id == 3L })
    }

    @Test fun testedConfidenceBreaksTies() {
        val weak = exp(1, part = "درب", confidence = "HEARD")
        val strong = exp(2, part = "درب", confidence = "TESTED")
        val r = RelatedExperiences.rank("", "درب", "", listOf(weak, strong))
        assertEquals(2L, r.first().experience.id)
    }

    @Test fun confidenceAloneIsNotAMatch() {
        val r = RelatedExperiences.rank("", "", "", listOf(exp(1, confidence = "TESTED")))
        assertTrue(r.isEmpty())
    }

    @Test fun newerWinsWhenScoresEqual() {
        val old = exp(1, part = "درب", updated = 10)
        val new = exp(2, part = "درب", updated = 20)
        val r = RelatedExperiences.rank("", "درب", "", listOf(old, new))
        assertEquals(listOf(2L, 1L), r.map { it.experience.id })
    }
}
