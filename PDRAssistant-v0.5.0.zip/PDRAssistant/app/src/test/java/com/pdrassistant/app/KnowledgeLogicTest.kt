package com.pdrassistant.app

import com.pdrassistant.app.data.KnowledgeEntry
import com.pdrassistant.app.domain.KnowledgeKind
import com.pdrassistant.app.domain.KnowledgeLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KnowledgeLogicTest {

    private fun k(
        id: Long, title: String = "t", cat: String = "", kind: String = "PERSONAL", body: String = "",
        part: String = "", damage: String = "", updated: Long = 0, source: String = ""
    ) = KnowledgeEntry(
        id = id, title = title, category = cat, kind = kind, body = body, source = source,
        carPart = part, damageType = damage, createdAt = 0, updatedAt = updated
    )

    @Test fun unknownKindFallsBackToPersonal() {
        assertEquals(KnowledgeKind.PERSONAL, KnowledgeKind.fromKey("???"))
        assertEquals(KnowledgeKind.PERSONAL, KnowledgeKind.fromKey(null))
        assertEquals(KnowledgeKind.FACT, KnowledgeKind.fromKey("FACT"))
    }

    @Test fun everyKindHasWarning() {
        assertTrue(KnowledgeKind.entries.all { it.warning.isNotBlank() && it.label.isNotBlank() })
    }

    @Test fun searchIsNormalizedAndCoversFields() {
        val list = listOf(k(1, title = "كشش ورق"), k(2, body = "حرارت"), k(3, source = "کتاب الف"), k(4))
        assertEquals(listOf(1L), KnowledgeLogic.search(list, "کشش").map { it.id })
        assertEquals(listOf(2L), KnowledgeLogic.search(list, " حرارت ").map { it.id })
        assertEquals(listOf(3L), KnowledgeLogic.search(list, "کتاب").map { it.id })
        assertEquals(4, KnowledgeLogic.search(list, "  ").size)
    }

    @Test fun filterByKindAndCategory() {
        val list = listOf(
            k(1, cat = "رنگ", kind = "FACT"), k(2, cat = "رنگ", kind = "PERSONAL"),
            k(3, cat = "ابزار", kind = "FACT")
        )
        assertEquals(listOf(1L), KnowledgeLogic.filter(list, "FACT", "رنگ").map { it.id })
        assertEquals(listOf(1L, 3L), KnowledgeLogic.filter(list, "FACT", null).map { it.id })
        assertEquals(listOf(1L, 2L), KnowledgeLogic.filter(list, null, " رنگ ").map { it.id })
        assertEquals(3, KnowledgeLogic.filter(list, "", "").size)
    }

    @Test fun categoriesAreDeduplicatedAndSorted() {
        val list = listOf(k(1, cat = "ب"), k(2, cat = " ب "), k(3, cat = "الف"), k(4, cat = ""))
        assertEquals(listOf("الف", "ب"), KnowledgeLogic.categoriesIn(list))
    }

    @Test fun suggestionsMergeDefaultsAndUserCategories() {
        val s = KnowledgeLogic.categorySuggestions(listOf(k(1, cat = "ایمنی"), k(2, cat = "دسته‌ی من")))
        assertEquals(1, s.count { it == "ایمنی" })
        assertTrue("دسته‌ی من" in s)
        assertEquals(KnowledgeLogic.defaultCategories.size + 1, s.size)
    }

    @Test fun groupingPutsUncategorizedLast() {
        val g = KnowledgeLogic.groupByCategory(listOf(k(1), k(2, cat = "ب"), k(3, cat = "الف"), k(4, cat = "ب")))
        assertEquals(listOf("الف", "ب", "بدون دسته"), g.map { it.first })
        assertEquals(listOf(2L, 4L), g[1].second.map { it.id })
        assertEquals(listOf(1L), g[2].second.map { it.id })
    }

    @Test fun groupingWithoutUncategorizedHasNoExtraGroup() {
        assertEquals(1, KnowledgeLogic.groupByCategory(listOf(k(1, cat = "الف"))).size)
        assertTrue(KnowledgeLogic.groupByCategory(emptyList()).isEmpty())
    }

    @Test fun relatedScoresAndPrefersFacts() {
        val list = listOf(
            k(1, part = "درب", damage = "فرورفتگی"),                 // 6
            k(2, part = "درب", damage = "فرورفتگی", kind = "FACT"),  // 7
            k(3, part = "درب"),                                      // 3
            k(4, part = "گلگیر"),                                    // 0
            k(5, kind = "FACT")                                      // 0 (بدون قطعه/آسیب)
        )
        assertEquals(listOf(2L, 1L, 3L), KnowledgeLogic.related("درب", "فرورفتگی", list).map { it.id })
    }

    @Test fun relatedTieBrokenByNewestAndLimited() {
        val list = (1..8).map { k(it.toLong(), part = "درب", updated = it.toLong()) }
        val r = KnowledgeLogic.related("درب", null, list, limit = 3)
        assertEquals(listOf(8L, 7L, 6L), r.map { it.id })
    }

    @Test fun relatedIgnoresBlankProjectFields() {
        assertTrue(KnowledgeLogic.related("", null, listOf(k(1, part = ""), k(2))).isEmpty())
    }

    @Test fun countByKindCoversAllKinds() {
        val c = KnowledgeLogic.countByKind(listOf(k(1, kind = "FACT"), k(2), k(3, kind = "HYPOTHESIS"), k(4)))
        assertEquals(1, c[KnowledgeKind.FACT])
        assertEquals(2, c[KnowledgeKind.PERSONAL])
        assertEquals(1, c[KnowledgeKind.HYPOTHESIS])
    }
}
