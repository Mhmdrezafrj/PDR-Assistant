package com.pdrassistant.app

import com.pdrassistant.app.data.LearningResource
import com.pdrassistant.app.domain.ResourceLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourceLogicTest {

    private fun r(
        id: Long = 0, title: String = "t", part: String = "", damage: String = "", repair: String = "PDR",
        rating: Int = 0, status: String = "TO_WATCH", updated: Long = 0, keyPoints: String = "", notes: String = "",
        url: String = "", author: String = "", kind: String = "VIDEO"
    ) = LearningResource(
        id = id, title = title, kind = kind, url = url, author = author, repairType = repair, carPart = part,
        damageType = damage, keyPoints = keyPoints, notes = notes, rating = rating, status = status,
        createdAt = 0, updatedAt = updated
    )

    @Test fun normalizeUrlAddsHttpsAndTrims() {
        assertEquals("https://youtu.be/abc", ResourceLogic.normalizeUrl("  youtu.be/abc "))
        assertEquals("http://a.com", ResourceLogic.normalizeUrl("http://a.com"))
        assertEquals("HTTPS://A.COM", ResourceLogic.normalizeUrl("HTTPS://A.COM"))
        assertEquals("", ResourceLogic.normalizeUrl("   "))
    }

    @Test fun normalizeUrlLeavesTextWithSpacesAlone() {
        assertEquals("این لینک نیست", ResourceLogic.normalizeUrl("این لینک نیست"))
    }

    @Test fun validUrls() {
        assertTrue(ResourceLogic.isValidUrl(""))
        assertTrue(ResourceLogic.isValidUrl("youtu.be/abc"))
        assertTrue(ResourceLogic.isValidUrl("https://www.youtube.com/watch?v=abc123&t=90s"))
        assertTrue(ResourceLogic.isValidUrl("http://example.ir:8080/path/x"))
        assertTrue(ResourceLogic.isValidUrl("https://aparat.com/v/xyz"))
    }

    @Test fun invalidUrls() {
        assertFalse(ResourceLogic.isValidUrl("hello"))
        assertFalse(ResourceLogic.isValidUrl("این لینک نیست"))
        assertFalse(ResourceLogic.isValidUrl("https://"))
        assertFalse(ResourceLogic.isValidUrl("https://a"))
        assertFalse(ResourceLogic.isValidUrl("javascript:alert(1)"))
        assertFalse(ResourceLogic.isValidUrl("ftp://a.com/x"))
    }

    @Test fun searchMatchesAnyTextFieldIgnoringArabicLetters() {
        val list = listOf(
            r(1, title = "آموزش PDR"),
            r(2, title = "x", notes = "كاپوت را گرم نكن"),
            r(3, title = "y", author = "استاد رضایی")
        )
        assertEquals(listOf(1L), ResourceLogic.search(list, "pdr").map { it.id })
        assertEquals(listOf(2L), ResourceLogic.search(list, "کاپوت").map { it.id })
        assertEquals(listOf(3L), ResourceLogic.search(list, "رضایی").map { it.id })
        assertEquals(3, ResourceLogic.search(list, "  ").size)
    }

    @Test fun relatedRanksByPartDamageThenRepairThenRating() {
        val all = listOf(
            r(1, part = "درب", damage = "چروک", repair = "PDR"),      // ۳+۳+۲ = ۸
            r(2, part = "درب", repair = "PDR", rating = 5),            // ۳+۲+۱ = ۶
            r(3, part = "درب", repair = "PAINT"),                      // ۳
            r(4, part = "کاپوت", damage = "تا خوردگی")                 // بی‌ارتباط
        )
        val res = ResourceLogic.related("PDR", "درب", "چروک", all)
        assertEquals(listOf(1L, 2L, 3L), res.map { it.id })
    }

    @Test fun relatedNeedsPartOrDamageMatch() {
        val all = listOf(r(1, part = "", damage = "", repair = "PDR", rating = 5))
        assertTrue(ResourceLogic.related("PDR", "درب", "چروک", all).isEmpty())
        assertTrue(ResourceLogic.related("PDR", "", "", all).isEmpty())
    }

    @Test fun relatedHonorsLimitAndRecency() {
        val all = (1L..10L).map { r(it, part = "درب", updated = it) }
        val res = ResourceLogic.related("", "درب", "", all, limit = 3)
        assertEquals(listOf(10L, 9L, 8L), res.map { it.id })
    }

    @Test fun draftCopiesFieldsAndBuildsSource() {
        val d = ResourceLogic.toExperienceDraft(
            r(title = " گلوپلر ", part = "درب", damage = "چروک", repair = "PDR", keyPoints = "۱. چسب\n۲. کشش",
                notes = "خوب بود", url = "youtu.be/abc", author = "استاد", kind = "VIDEO")
        )
        assertEquals(0L, d.id)
        assertEquals("گلوپلر", d.title)
        assertEquals("درب", d.carPart)
        assertEquals("چروک", d.damageType)
        assertEquals("۱. چسب\n۲. کشش", d.steps)
        assertEquals("خوب بود", d.masterNotes)
        assertEquals("ویدئو: گلوپلر — استاد\nhttps://youtu.be/abc", d.source)
    }

    @Test fun draftConfidenceDependsOnStatus() {
        assertEquals("HEARD", ResourceLogic.toExperienceDraft(r(status = "TO_WATCH")).confidence)
        assertEquals("HEARD", ResourceLogic.toExperienceDraft(r(status = "WATCHED")).confidence)
        assertEquals("ONCE", ResourceLogic.toExperienceDraft(r(status = "TRIED")).confidence)
    }

    @Test fun draftWithoutUrlOrAuthorHasShortSource() {
        assertEquals("کتاب: مبانی", ResourceLogic.toExperienceDraft(r(title = "مبانی", kind = "BOOK")).source)
    }
}
