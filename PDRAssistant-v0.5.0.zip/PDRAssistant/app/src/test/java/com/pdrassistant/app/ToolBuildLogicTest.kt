package com.pdrassistant.app

import com.pdrassistant.app.data.ToolBuild
import com.pdrassistant.app.data.ToolMaterial
import com.pdrassistant.app.domain.ToolBuildLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolBuildLogicTest {

    private val build = ToolBuild(name = "قلاب دست‌ساز", purpose = "فشار از زیر ورق", status = "BUILDING",
        design = "طول ۳۰ سانتی‌متر", steps = "برش\nجوش", result = "", createdAt = 0, updatedAt = 0)

    private fun m(name: String, qty: String = "", acquired: Boolean = false) =
        ToolMaterial(buildId = 1, name = name, quantity = qty, acquired = acquired, createdAt = 0)

    @Test fun progressCountsAcquired() {
        assertEquals(1 to 3, ToolBuildLogic.progress(listOf(m("a", acquired = true), m("b"), m("c"))))
        assertEquals(0 to 0, ToolBuildLogic.progress(emptyList()))
    }

    @Test fun allAcquiredNeedsAtLeastOneMaterial() {
        assertFalse(ToolBuildLogic.allAcquired(emptyList()))
        assertFalse(ToolBuildLogic.allAcquired(listOf(m("a", acquired = true), m("b"))))
        assertTrue(ToolBuildLogic.allAcquired(listOf(m("a", acquired = true), m("b", acquired = true))))
    }

    @Test fun shoppingListHasOnlyMissingItemsWithQuantity() {
        val t = ToolBuildLogic.shoppingList(build, listOf(m("میله", "۲ متر"), m("پیچ", acquired = true), m("چسب")))
        assertTrue(t.contains("[ ] میله — ۲ متر"))
        assertTrue(t.contains("[ ] چسب\n"))
        assertFalse(t.contains("پیچ"))
    }

    @Test fun shoppingListMessagesForEmptyAndComplete() {
        assertTrue(ToolBuildLogic.shoppingList(build, emptyList()).contains("هنوز ماده‌ای ثبت نشده"))
        assertTrue(ToolBuildLogic.shoppingList(build, listOf(m("a", acquired = true))).contains("همه‌ی مواد تهیه شده"))
    }

    @Test fun reportHasAllFilledSectionsAndSkipsEmptyOnes() {
        val r = ToolBuildLogic.report(build, listOf(m("میله", "۲ متر", acquired = true), m("چسب")))
        assertTrue(r.startsWith("ساخت ابزار — قلاب دست‌ساز"))
        assertTrue(r.contains("وضعیت: در حال ساخت"))
        assertTrue(r.contains("کاربرد:\nفشار از زیر ورق"))
        assertTrue(r.contains("طرح و ابعاد:\nطول ۳۰ سانتی‌متر"))
        assertTrue(r.contains("مواد اولیه (1 از 2 تهیه شده):"))
        assertTrue(r.contains("[✓] میله — ۲ متر"))
        assertTrue(r.contains("مراحل ساخت:\nبرش\nجوش"))
        assertFalse(r.contains("نتیجه و اصلاحات"))
    }
}
