package com.pdrassistant.app

import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Tool
import com.pdrassistant.app.domain.ChecklistLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChecklistLogicTest {

    private fun tool(name: String, owned: Boolean = true) =
        Tool(name = name, owned = owned, createdAt = 0, updatedAt = 0)

    private fun exp(tools: String) =
        Experience(title = "t", tools = tools, createdAt = 0, updatedAt = 0)

    @Test fun cleanLineRemovesNumberingAndBullets() {
        assertEquals("چراغ را تنظیم کن", ChecklistLogic.cleanLine("۱. چراغ را تنظیم کن"))
        assertEquals("چراغ را تنظیم کن", ChecklistLogic.cleanLine("2- چراغ را تنظیم کن"))
        assertEquals("چراغ را تنظیم کن", ChecklistLogic.cleanLine("3) چراغ را تنظیم کن"))
        assertEquals("چراغ را تنظیم کن", ChecklistLogic.cleanLine("- چراغ را تنظیم کن"))
        assertEquals("چراغ را تنظیم کن", ChecklistLogic.cleanLine("  • چراغ را تنظیم کن  "))
    }

    @Test fun cleanLineKeepsNumbersInsideText() {
        assertEquals("فشار 2 بار اعمال شود", ChecklistLogic.cleanLine("فشار 2 بار اعمال شود"))
        assertEquals("200 گرم", ChecklistLogic.cleanLine("200 گرم"))
    }

    @Test fun stepsToItemsSkipsBlankAndDuplicates() {
        val steps = "۱. شستشو\n\n2. بازدید\n   \n۳. شستشو\n4. اجرا"
        assertEquals(listOf("شستشو", "بازدید", "اجرا"), ChecklistLogic.stepsToItems(steps, emptyList()))
    }

    @Test fun stepsToItemsSkipsExistingItems() {
        val r = ChecklistLogic.stepsToItems("شستشو\nبازدید", listOf("  شستشو "))
        assertEquals(listOf("بازدید"), r)
    }

    @Test fun stepsToItemsOfEmptyTextIsEmpty() {
        assertTrue(ChecklistLogic.stepsToItems("", emptyList()).isEmpty())
        assertTrue(ChecklistLogic.stepsToItems("\n \n", emptyList()).isEmpty())
    }

    @Test fun suggestedToolsAreDedupedAndMatchedWithBank() {
        val bank = listOf(tool("چراغ PDR", owned = true), tool("گلوپلر", owned = false))
        val r = ChecklistLogic.suggestedTools(
            listOf(exp("چراغ PDR\nگلوپلر\nمیله"), exp("- گلوپلر\nچراغ  PDR")), bank
        )
        assertEquals(listOf("چراغ PDR", "گلوپلر", "میله"), r.map { it.name })
        assertTrue(r[0].available)       // دارم
        assertFalse(r[1].available)      // در بانک هست ولی ندارم
        assertNull(r[2].inBank)          // اصلاً ثبت نشده
        assertFalse(r[2].available)
    }

    @Test fun suggestedToolsMatchIgnoresArabicLetterVariants() {
        val bank = listOf(tool("پتک لاستيكي"))
        val r = ChecklistLogic.suggestedTools(listOf(exp("پتک لاستیکی")), bank)
        assertTrue(r.single().available)
    }

    @Test fun noRelatedExperiencesMeansNoSuggestions() {
        assertTrue(ChecklistLogic.suggestedTools(emptyList(), listOf(tool("x"))).isEmpty())
    }
}
