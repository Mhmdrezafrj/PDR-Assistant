package com.pdrassistant.app

import com.pdrassistant.app.data.ChecklistItem
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Project
import com.pdrassistant.app.domain.ProjectReport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectReportTest {

    @Test fun parseMinutesAcceptsAsciiPersianAndArabicDigits() {
        assertEquals(90, ProjectReport.parseMinutes("90"))
        assertEquals(90, ProjectReport.parseMinutes("۹۰"))
        assertEquals(125, ProjectReport.parseMinutes(" ١٢٥ "))
        assertEquals(0, ProjectReport.parseMinutes(""))
        assertEquals(0, ProjectReport.parseMinutes("   "))
    }

    @Test fun parseMinutesRejectsGarbageAndHugeValues() {
        assertNull(ProjectReport.parseMinutes("12abc"))
        assertNull(ProjectReport.parseMinutes("-5"))
        assertNull(ProjectReport.parseMinutes("1.5"))
        assertNull(ProjectReport.parseMinutes("100001"))
        assertNull(ProjectReport.parseMinutes("99999999999"))
        assertEquals(100_000, ProjectReport.parseMinutes("100000"))
    }

    @Test fun formatDuration() {
        assertEquals("ثبت نشده", ProjectReport.formatDuration(0))
        assertEquals("45 دقیقه", ProjectReport.formatDuration(45))
        assertEquals("2 ساعت", ProjectReport.formatDuration(120))
        assertEquals("2 ساعت و 30 دقیقه", ProjectReport.formatDuration(150))
    }

    private val project = Project(
        id = 1, title = "پژو ۲۰۶", vehicle = "سفید", carPart = "درب جلو", damageType = "فرورفتگی",
        repairType = "PDR", status = "DONE", outcome = "PARTIAL", timeSpentMinutes = 150,
        mistakes = "فشار زیاد", lessons = "آرام‌تر", resultNotes = "لبه کمی بالا ماند",
        createdAt = 0, updatedAt = 0
    )

    @Test fun reportContainsEvaluatedSections() {
        val items = listOf(
            ChecklistItem(projectId = 1, text = "شستشو", done = true, createdAt = 0),
            ChecklistItem(projectId = 1, text = "اجرا", done = false, createdAt = 0)
        )
        val exp = Experience(title = "t", tools = "چراغ PDR\nگلوپلر", createdAt = 0, updatedAt = 0)
        val r = ProjectReport.build(project, items, listOf(exp), "2026/11/17")
        assertTrue(r.startsWith("گزارش کار — پژو ۲۰۶"))
        assertTrue(r.contains("نتیجه: نسبتاً موفق"))
        assertTrue(r.contains("زمان صرف‌شده: 2 ساعت و 30 دقیقه"))
        assertTrue(r.contains("چک‌لیست (1 از 2):"))
        assertTrue(r.contains("[✓] شستشو"))
        assertTrue(r.contains("[ ] اجرا"))
        assertTrue(r.contains("- چراغ PDR"))
        assertTrue(r.contains("اشتباهات و مشکلات:\nفشار زیاد"))
        assertTrue(r.contains("درس‌ها:\nآرام‌تر"))
        assertTrue(r.contains("توضیح نتیجه:\nلبه کمی بالا ماند"))
        assertTrue(r.contains("2026/11/17"))
    }

    @Test fun reportOmitsEmptySections() {
        val bare = Project(title = "ساده", createdAt = 0, updatedAt = 0)
        val r = ProjectReport.build(bare, emptyList(), emptyList(), "d")
        assertFalse(r.contains("چک‌لیست"))
        assertFalse(r.contains("ابزارها"))
        assertFalse(r.contains("اشتباهات"))
        assertFalse(r.contains("زمان صرف‌شده"))
        assertTrue(r.contains("نتیجه: ارزیابی نشده"))
        assertTrue(r.endsWith("\n") && !r.endsWith("\n\n"))
    }
}
