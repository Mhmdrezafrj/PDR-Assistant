package com.pdrassistant.app

import com.pdrassistant.app.data.BackupCodec
import com.pdrassistant.app.data.ChecklistItem
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.KnowledgeEntry
import com.pdrassistant.app.data.LearningResource
import com.pdrassistant.app.data.Project
import com.pdrassistant.app.data.Tool
import com.pdrassistant.app.data.ToolBuild
import com.pdrassistant.app.data.ToolMaterial
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class BackupCodecTest {

    private val project = Project(
        id = 7, title = "پژو ۲۰۶", vehicle = "سفید", plate = "", carPart = "درب جلو",
        damageType = "فرورفتگی", repairType = "PDR", status = "DONE", notes = "خط «تیز» و \"نقل‌قول\"\nخط دوم",
        resultNotes = "خوب شد", createdAt = 1000, updatedAt = 2000
    )
    private val experience = Experience(
        id = 3, title = "بادگیری با گلوپلر", repairType = "PDR", carPart = "درب جلو",
        damageType = "فرورفتگی", tools = "گلوپلر\nچراغ", steps = "۱\n۲\n۳", conditions = "ورق آلومینیوم",
        result = "عالی", possibleErrors = "بالاآمدگی", mediaFiles = "a.jpg\nb.mp4", source = "ویدئو",
        confidence = "TESTED", masterNotes = "حتماً گرم نشود", projectId = 7, createdAt = 10, updatedAt = 20
    )

    private val tool = Tool(id = 4, name = "چراغ PDR", category = "PDR", notes = "مدل ۲ بازویی", owned = false, createdAt = 5, updatedAt = 6)
    private val item = ChecklistItem(id = 9, projectId = 7, text = "شستشوی محل", done = true, position = 2, createdAt = 8)

    private val build = ToolBuild(
        id = 2, name = "قلاب", purpose = "فشار از زیر", status = "DONE", design = "۳۰ سانت", steps = "برش\nجوش",
        planFiles = "p1.jpg\np2.png", photoFiles = "f1.jpg", result = "خوب", toolId = 4, createdAt = 1, updatedAt = 2
    )
    private val material = ToolMaterial(id = 5, buildId = 2, name = "میله", quantity = "۲ متر", acquired = true, position = 1, createdAt = 3)

    private val resource = LearningResource(
        id = 8, title = "آموزش گلوپلر", kind = "VIDEO", url = "https://youtu.be/abc", author = "استاد",
        repairType = "PDR", carPart = "درب جلو", damageType = "چروک", keyPoints = "۰۲:۳۰ چسب\n۰۵:۰۰ کشش",
        notes = "خوب", rating = 4, status = "WATCHED", createdAt = 1, updatedAt = 2
    )

    @Test fun roundTripKeepsLearningResources() {
        val text = BackupCodec.encode(emptyList(), emptyList(), 1, resources = listOf(resource))
        assertEquals(listOf(resource), BackupCodec.decode(text).resources)
    }

    private val knowledge = KnowledgeEntry(
        id = 6, title = "کشش ورق", category = "رفتار فلز", kind = "HYPOTHESIS", body = "خط اول\nخط «دوم»",
        source = "آزمایش خودم", carPart = "درب جلو", damageType = "فرورفتگی", createdAt = 11, updatedAt = 12
    )

    @Test fun roundTripKeepsKnowledge() {
        val text = BackupCodec.encode(emptyList(), emptyList(), 1, knowledge = listOf(knowledge))
        assertEquals(listOf(knowledge), BackupCodec.decode(text).knowledge)
    }

    @Test fun version4BackupStillLoadsWithoutKnowledge() {
        val v4 = """{"magic":"pdr-assistant-backup","formatVersion":4,"createdAt":1,
            "projects":[],"experiences":[],"tools":[],"checklist":[],"toolBuilds":[],"toolMaterials":[],"resources":[]}"""
        assertTrue(BackupCodec.decode(v4).knowledge.isEmpty())
    }

    @Test fun knowledgeWithoutKindDefaultsToPersonal() {
        val json = """{"magic":"pdr-assistant-backup","formatVersion":5,"createdAt":1,"projects":[],"experiences":[],
            "knowledge":[{"id":1,"title":"x","createdAt":1,"updatedAt":2}]}"""
        val k = BackupCodec.decode(json).knowledge.single()
        assertEquals("PERSONAL", k.kind)
        assertEquals("", k.body)
    }

    @Test fun rejectsDuplicateKnowledgeIds() {
        assertRejected(BackupCodec.encode(emptyList(), emptyList(), 1, knowledge = listOf(knowledge, knowledge)))
    }

    @Test fun version3BackupStillLoadsWithoutResources() {
        val v3 = """{"magic":"pdr-assistant-backup","formatVersion":3,"createdAt":1,
            "projects":[],"experiences":[],"tools":[],"checklist":[],"toolBuilds":[],"toolMaterials":[]}"""
        assertTrue(BackupCodec.decode(v3).resources.isEmpty())
    }

    @Test fun ratingOutOfRangeIsClamped() {
        val text = BackupCodec.encode(emptyList(), emptyList(), 1, resources = listOf(resource.copy(rating = 9)))
        assertEquals(5, BackupCodec.decode(text).resources.single().rating)
    }

    @Test fun rejectsDuplicateResourceIds() {
        assertRejected(BackupCodec.encode(emptyList(), emptyList(), 1, resources = listOf(resource, resource)))
    }

    @Test fun roundTripKeepsEvaluationFieldsOfProject() {
        val p = project.copy(outcome = "PARTIAL", timeSpentMinutes = 150, mistakes = "فشار", lessons = "آرام")
        val snap = BackupCodec.decode(BackupCodec.encode(listOf(p), emptyList(), 1))
        assertEquals(listOf(p), snap.projects)
    }

    @Test fun roundTripKeepsToolBuildsAndMaterials() {
        val text = BackupCodec.encode(listOf(project), emptyList(), 1, listOf(tool), emptyList(), listOf(build), listOf(material))
        val snap = BackupCodec.decode(text)
        assertEquals(listOf(build), snap.toolBuilds)
        assertEquals(listOf(material), snap.toolMaterials)
    }

    @Test fun orphanMaterialsAndDanglingToolIdAreCleaned() {
        val orphan = material.copy(id = 6, buildId = 999)
        val dangling = build.copy(toolId = 777)
        val snap = BackupCodec.decode(
            BackupCodec.encode(emptyList(), emptyList(), 1, listOf(tool), emptyList(), listOf(dangling), listOf(material, orphan))
        )
        assertEquals(listOf(material), snap.toolMaterials)
        assertNull(snap.toolBuilds.single().toolId)
    }

    @Test fun version2BackupStillLoadsWithDefaults() {
        // ساختار فایل پشتیبان 0.2.0: پروژه بدون فیلدهای ارزیابی و بدون بخش ساخت ابزار
        val v2 = """{"magic":"pdr-assistant-backup","formatVersion":2,"createdAt":1,
            "projects":[{"id":1,"title":"x","vehicle":"","plate":"","carPart":"","damageType":"",
              "repairType":"PDR","status":"DONE","notes":"","resultNotes":"","createdAt":1,"updatedAt":2}],
            "experiences":[],"tools":[],"checklist":[]}"""
        val snap = BackupCodec.decode(v2)
        val p = snap.projects.single()
        assertEquals("", p.outcome)
        assertEquals(0, p.timeSpentMinutes)
        assertTrue(snap.toolBuilds.isEmpty() && snap.toolMaterials.isEmpty())
    }

    @Test fun rejectsDuplicateBuildIds() {
        assertRejected(BackupCodec.encode(emptyList(), emptyList(), 1, emptyList(), emptyList(), listOf(build, build), emptyList()))
    }

    @Test fun roundTripKeepsToolsAndChecklist() {
        val text = BackupCodec.encode(listOf(project), listOf(experience), 1, listOf(tool), listOf(item))
        val snap = BackupCodec.decode(text)
        assertEquals(listOf(tool), snap.tools)
        assertEquals(listOf(item), snap.checklist)
    }

    @Test fun orphanChecklistItemsAreDropped() {
        val orphan = item.copy(id = 10, projectId = 999)
        val snap = BackupCodec.decode(BackupCodec.encode(listOf(project), emptyList(), 1, emptyList(), listOf(item, orphan)))
        assertEquals(listOf(item), snap.checklist)
    }

    @Test fun version1BackupStillLoadsWithEmptyToolsAndChecklist() {
        // ساختار دقیق فایل پشتیبان برنامه 0.1.0
        val v1 = """{"magic":"pdr-assistant-backup","formatVersion":1,"createdAt":1,
            "projects":[],"experiences":[]}"""
        val snap = BackupCodec.decode(v1)
        assertTrue(snap.tools.isEmpty() && snap.checklist.isEmpty())
    }

    @Test fun rejectsDuplicateToolIds() {
        assertRejected(BackupCodec.encode(emptyList(), emptyList(), 1, listOf(tool, tool), emptyList()))
    }

    @Test fun roundTripKeepsEveryField() {
        val text = BackupCodec.encode(listOf(project), listOf(experience), now = 99)
        val snap = BackupCodec.decode(text)
        assertEquals(listOf(project), snap.projects)
        assertEquals(listOf(experience), snap.experiences)
    }

    @Test fun nullProjectIdSurvives() {
        val e = experience.copy(projectId = null)
        val snap = BackupCodec.decode(BackupCodec.encode(listOf(project), listOf(e), 1))
        assertNull(snap.experiences.single().projectId)
    }

    @Test fun danglingProjectReferenceIsCleared() {
        val e = experience.copy(projectId = 999)
        val snap = BackupCodec.decode(BackupCodec.encode(listOf(project), listOf(e), 1))
        assertNull(snap.experiences.single().projectId)
    }

    @Test fun emptyBackupIsValid() {
        val snap = BackupCodec.decode(BackupCodec.encode(emptyList(), emptyList(), 1))
        assertEquals(0, snap.projects.size + snap.experiences.size)
    }

    private fun assertRejected(text: String) {
        try {
            BackupCodec.decode(text)
            fail("باید رد می‌شد: $text")
        } catch (e: BackupCodec.BackupException) {
            // درست
        }
    }

    @Test fun rejectsGarbageAndForeignJson() {
        assertRejected("این JSON نیست")
        assertRejected("{}")
        assertRejected("""{"magic":"something-else","formatVersion":1}""")
    }

    @Test fun rejectsNewerFormat() {
        assertRejected("""{"magic":"pdr-assistant-backup","formatVersion":99,"projects":[],"experiences":[]}""")
    }

    @Test fun rejectsTruncatedStructure() {
        assertRejected("""{"magic":"pdr-assistant-backup","formatVersion":1,"projects":[]}""")
    }

    @Test fun rejectsDuplicateIds() {
        val text = BackupCodec.encode(listOf(project, project), emptyList(), 1)
        assertRejected(text)
    }
}
