package com.pdrassistant.app

import com.pdrassistant.app.data.Project
import com.pdrassistant.app.domain.PastLessons
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PastLessonsTest {

    private fun p(
        id: Long, part: String = "", damage: String = "", repair: String = "PDR",
        outcome: String = "", mistakes: String = "", lessons: String = "", updated: Long = 0
    ) = Project(
        id = id, title = "p$id", carPart = part, damageType = damage, repairType = repair,
        outcome = outcome, mistakes = mistakes, lessons = lessons, createdAt = 0, updatedAt = updated
    )

    @Test fun hasLessonOnlyWhenSomethingToRemember() {
        assertFalse(PastLessons.hasLesson(p(1)))
        assertFalse(PastLessons.hasLesson(p(1, outcome = "SUCCESS")))
        assertTrue(PastLessons.hasLesson(p(1, outcome = "PARTIAL")))
        assertTrue(PastLessons.hasLesson(p(1, outcome = "FAILED")))
        assertTrue(PastLessons.hasLesson(p(1, mistakes = "گرم کردم")))
        assertTrue(PastLessons.hasLesson(p(1, lessons = "ابتدا تست کن")))
    }

    @Test fun findsOnlyMatchingPartOrDamage() {
        val cur = p(1, part = "درب جلو", damage = "چروک")
        val all = listOf(
            p(2, part = "درب جلو", outcome = "FAILED"),
            p(3, part = "کاپوت", damage = "تا خوردگی", outcome = "FAILED")
        )
        assertEquals(listOf(2L), PastLessons.find(cur, all).map { it.project.id })
    }

    @Test fun excludesCurrentProjectAndSuccessfulWithoutNotes() {
        val cur = p(1, part = "درب")
        val all = listOf(cur.copy(outcome = "FAILED"), p(2, part = "درب", outcome = "SUCCESS"))
        assertTrue(PastLessons.find(cur, all).isEmpty())
    }

    @Test fun ranksByScoreThenSeverityThenRecency() {
        val cur = p(1, part = "درب", damage = "چروک", repair = "PDR")
        val all = listOf(
            p(2, part = "درب", outcome = "PARTIAL", updated = 5),                      // امتیاز ۲ (قطعه + نوع)
            p(3, part = "درب", damage = "چروک", outcome = "PARTIAL", updated = 1),     // امتیاز ۳
            p(4, part = "درب", outcome = "FAILED", updated = 1),                       // امتیاز ۲، شدیدتر
            p(5, part = "درب", outcome = "FAILED", updated = 9)                        // امتیاز ۲، شدید، جدیدتر
        )
        assertEquals(listOf(3L, 5L, 4L, 2L), PastLessons.find(cur, all).map { it.project.id })
    }

    @Test fun repairTypeAloneIsNotAMatch() {
        val cur = p(1, part = "", damage = "", repair = "PDR")
        assertTrue(PastLessons.find(cur, listOf(p(2, repair = "PDR", outcome = "FAILED"))).isEmpty())
    }

    @Test fun blankPartsNeverMatchEachOther() {
        val cur = p(1, part = "", damage = "چروک")
        val r = PastLessons.find(cur, listOf(p(2, part = "", damage = "", outcome = "FAILED")))
        assertTrue(r.isEmpty())
    }

    @Test fun honorsLimit() {
        val cur = p(1, part = "درب")
        val all = (2L..20L).map { p(it, part = "درب", outcome = "FAILED") }
        assertEquals(3, PastLessons.find(cur, all, limit = 3).size)
    }
}
