package com.pdrassistant.app.data

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * تبدیل کل اطلاعات به JSON و بالعکس (پشتیبان‌گیری/بازیابی).
 * - نسخه فرمت در فایل ثبت می‌شود؛ فایل جدیدتر از نسخه پشتیبانی‌شده رد می‌شود.
 * - فرمت 1 تا 3 (نسخه‌های 0.1.0 تا 0.3.0) هنوز خوانده می‌شوند: بخش‌های نبوده در آن‌ها خالی/پیش‌فرض در نظر گرفته می‌شود.
 * - فایل‌های تصویر/ویدئو در 0.1.0 داخل پشتیبان نیستند (فقط نام آن‌ها).
 */
object BackupCodec {
    const val FORMAT_VERSION = 5
    private const val MAGIC = "pdr-assistant-backup"

    class BackupException(message: String) : Exception(message)

    data class Snapshot(
        val projects: List<Project>,
        val experiences: List<Experience>,
        val tools: List<Tool> = emptyList(),
        val checklist: List<ChecklistItem> = emptyList(),
        val toolBuilds: List<ToolBuild> = emptyList(),
        val toolMaterials: List<ToolMaterial> = emptyList(),
        val resources: List<LearningResource> = emptyList(),
        val knowledge: List<KnowledgeEntry> = emptyList()
    )

    fun encode(
        projects: List<Project>,
        experiences: List<Experience>,
        now: Long,
        tools: List<Tool> = emptyList(),
        checklist: List<ChecklistItem> = emptyList(),
        toolBuilds: List<ToolBuild> = emptyList(),
        toolMaterials: List<ToolMaterial> = emptyList(),
        resources: List<LearningResource> = emptyList(),
        knowledge: List<KnowledgeEntry> = emptyList()
    ): String {
        val root = JSONObject()
        root.put("magic", MAGIC)
        root.put("formatVersion", FORMAT_VERSION)
        root.put("createdAt", now)
        root.put("projects", JSONArray().also { arr -> projects.forEach { arr.put(projectToJson(it)) } })
        root.put("experiences", JSONArray().also { arr -> experiences.forEach { arr.put(experienceToJson(it)) } })
        root.put("tools", JSONArray().also { arr -> tools.forEach { arr.put(toolToJson(it)) } })
        root.put("checklist", JSONArray().also { arr -> checklist.forEach { arr.put(checklistToJson(it)) } })
        root.put("toolBuilds", JSONArray().also { arr -> toolBuilds.forEach { arr.put(toolBuildToJson(it)) } })
        root.put("toolMaterials", JSONArray().also { arr -> toolMaterials.forEach { arr.put(toolMaterialToJson(it)) } })
        root.put("resources", JSONArray().also { arr -> resources.forEach { arr.put(resourceToJson(it)) } })
        root.put("knowledge", JSONArray().also { arr -> knowledge.forEach { arr.put(knowledgeToJson(it)) } })
        return root.toString(2)
    }

    fun decode(text: String): Snapshot {
        val root = try {
            JSONObject(text)
        } catch (e: JSONException) {
            throw BackupException("این فایل پشتیبان معتبر نیست.")
        }
        if (root.optString("magic") != MAGIC) {
            throw BackupException("این فایل، پشتیبان دستیار PDR نیست.")
        }
        val version = root.optInt("formatVersion", -1)
        if (version < 1) throw BackupException("نسخه فایل پشتیبان نامعتبر است.")
        if (version > FORMAT_VERSION) {
            throw BackupException("این پشتیبان با نسخه جدیدتری از برنامه ساخته شده؛ ابتدا برنامه را به‌روزرسانی کنید.")
        }
        try {
            val projects = root.getJSONArray("projects").let { a ->
                (0 until a.length()).map { projectFromJson(a.getJSONObject(it)) }
            }
            val experiences = root.getJSONArray("experiences").let { a ->
                (0 until a.length()).map { experienceFromJson(a.getJSONObject(it)) }
            }
            val tools = (root.optJSONArray("tools") ?: JSONArray()).let { a ->
                (0 until a.length()).map { toolFromJson(a.getJSONObject(it)) }
            }
            val checklist = (root.optJSONArray("checklist") ?: JSONArray()).let { a ->
                (0 until a.length()).map { checklistFromJson(a.getJSONObject(it)) }
            }
            if (tools.map { it.id }.toSet().size != tools.size ||
                checklist.map { it.id }.toSet().size != checklist.size
            ) throw BackupException("فایل پشتیبان شناسه‌های تکراری دارد.")
            val builds = (root.optJSONArray("toolBuilds") ?: JSONArray()).let { a ->
                (0 until a.length()).map { toolBuildFromJson(a.getJSONObject(it)) }
            }
            val materials = (root.optJSONArray("toolMaterials") ?: JSONArray()).let { a ->
                (0 until a.length()).map { toolMaterialFromJson(a.getJSONObject(it)) }
            }
            val resources = (root.optJSONArray("resources") ?: JSONArray()).let { a ->
                (0 until a.length()).map { resourceFromJson(a.getJSONObject(it)) }
            }
            val knowledge = (root.optJSONArray("knowledge") ?: JSONArray()).let { a ->
                (0 until a.length()).map { knowledgeFromJson(a.getJSONObject(it)) }
            }
            if (knowledge.map { it.id }.toSet().size != knowledge.size) {
                throw BackupException("فایل پشتیبان شناسه‌های تکراری دارد.")
            }
            if (resources.map { it.id }.toSet().size != resources.size) {
                throw BackupException("فایل پشتیبان شناسه‌های تکراری دارد.")
            }
            if (builds.map { it.id }.toSet().size != builds.size ||
                materials.map { it.id }.toSet().size != materials.size
            ) throw BackupException("فایل پشتیبان شناسه‌های تکراری دارد.")
            // جلوگیری از شناسه تکراری و ارجاع به پروژه‌ای که وجود ندارد
            if (projects.map { it.id }.toSet().size != projects.size ||
                experiences.map { it.id }.toSet().size != experiences.size
            ) throw BackupException("فایل پشتیبان شناسه‌های تکراری دارد.")
            val projectIds = projects.map { it.id }.toSet()
            val fixed = experiences.map {
                if (it.projectId != null && it.projectId !in projectIds) it.copy(projectId = null) else it
            }
            // مرحله‌های چک‌لیستِ پروژه‌ای که در فایل نیست، بی‌صاحب‌اند و حذف می‌شوند.
            val checklistFixed = checklist.filter { it.projectId in projectIds }
            val toolIds = tools.map { it.id }.toSet()
            val buildsFixed = builds.map {
                if (it.toolId != null && it.toolId !in toolIds) it.copy(toolId = null) else it
            }
            val buildIds = builds.map { it.id }.toSet()
            val materialsFixed = materials.filter { it.buildId in buildIds }
            return Snapshot(projects, fixed, tools, checklistFixed, buildsFixed, materialsFixed, resources, knowledge)
        } catch (e: JSONException) {
            throw BackupException("ساختار فایل پشتیبان ناقص است.")
        }
    }

    private fun projectToJson(p: Project) = JSONObject().apply {
        put("id", p.id); put("title", p.title); put("vehicle", p.vehicle); put("plate", p.plate)
        put("carPart", p.carPart); put("damageType", p.damageType); put("repairType", p.repairType)
        put("status", p.status); put("notes", p.notes); put("resultNotes", p.resultNotes)
        put("outcome", p.outcome); put("timeSpentMinutes", p.timeSpentMinutes)
        put("mistakes", p.mistakes); put("lessons", p.lessons)
        put("createdAt", p.createdAt); put("updatedAt", p.updatedAt)
    }

    private fun projectFromJson(o: JSONObject) = Project(
        id = o.getLong("id"),
        title = o.getString("title"),
        vehicle = o.optString("vehicle"),
        plate = o.optString("plate"),
        carPart = o.optString("carPart"),
        damageType = o.optString("damageType"),
        repairType = o.optString("repairType", "PDR"),
        status = o.optString("status", "PLANNED"),
        notes = o.optString("notes"),
        resultNotes = o.optString("resultNotes"),
        outcome = o.optString("outcome"),
        timeSpentMinutes = o.optInt("timeSpentMinutes", 0),
        mistakes = o.optString("mistakes"),
        lessons = o.optString("lessons"),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )

    private fun experienceToJson(e: Experience) = JSONObject().apply {
        put("id", e.id); put("title", e.title); put("repairType", e.repairType)
        put("carPart", e.carPart); put("damageType", e.damageType); put("tools", e.tools)
        put("steps", e.steps); put("conditions", e.conditions); put("result", e.result)
        put("possibleErrors", e.possibleErrors); put("mediaFiles", e.mediaFiles)
        put("source", e.source); put("confidence", e.confidence); put("masterNotes", e.masterNotes)
        put("projectId", e.projectId ?: JSONObject.NULL)
        put("createdAt", e.createdAt); put("updatedAt", e.updatedAt)
    }

    private fun experienceFromJson(o: JSONObject) = Experience(
        id = o.getLong("id"),
        title = o.getString("title"),
        repairType = o.optString("repairType", "PDR"),
        carPart = o.optString("carPart"),
        damageType = o.optString("damageType"),
        tools = o.optString("tools"),
        steps = o.optString("steps"),
        conditions = o.optString("conditions"),
        result = o.optString("result"),
        possibleErrors = o.optString("possibleErrors"),
        mediaFiles = o.optString("mediaFiles"),
        source = o.optString("source"),
        confidence = o.optString("confidence", "UNSURE"),
        masterNotes = o.optString("masterNotes"),
        projectId = if (o.isNull("projectId")) null else o.getLong("projectId"),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )

    private fun toolToJson(t: Tool) = JSONObject().apply {
        put("id", t.id); put("name", t.name); put("category", t.category); put("notes", t.notes)
        put("owned", t.owned); put("createdAt", t.createdAt); put("updatedAt", t.updatedAt)
    }

    private fun toolFromJson(o: JSONObject) = Tool(
        id = o.getLong("id"),
        name = o.getString("name"),
        category = o.optString("category"),
        notes = o.optString("notes"),
        owned = o.optBoolean("owned", true),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )

    private fun checklistToJson(c: ChecklistItem) = JSONObject().apply {
        put("id", c.id); put("projectId", c.projectId); put("text", c.text)
        put("done", c.done); put("position", c.position); put("createdAt", c.createdAt)
    }

    private fun checklistFromJson(o: JSONObject) = ChecklistItem(
        id = o.getLong("id"),
        projectId = o.getLong("projectId"),
        text = o.getString("text"),
        done = o.optBoolean("done", false),
        position = o.optInt("position", 0),
        createdAt = o.getLong("createdAt")
    )

    private fun toolBuildToJson(b: ToolBuild) = JSONObject().apply {
        put("id", b.id); put("name", b.name); put("purpose", b.purpose); put("status", b.status)
        put("design", b.design); put("steps", b.steps); put("planFiles", b.planFiles)
        put("photoFiles", b.photoFiles); put("result", b.result)
        put("toolId", b.toolId ?: JSONObject.NULL)
        put("createdAt", b.createdAt); put("updatedAt", b.updatedAt)
    }

    private fun toolBuildFromJson(o: JSONObject) = ToolBuild(
        id = o.getLong("id"),
        name = o.getString("name"),
        purpose = o.optString("purpose"),
        status = o.optString("status", "IDEA"),
        design = o.optString("design"),
        steps = o.optString("steps"),
        planFiles = o.optString("planFiles"),
        photoFiles = o.optString("photoFiles"),
        result = o.optString("result"),
        toolId = if (o.isNull("toolId")) null else o.getLong("toolId"),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )

    private fun toolMaterialToJson(m: ToolMaterial) = JSONObject().apply {
        put("id", m.id); put("buildId", m.buildId); put("name", m.name); put("quantity", m.quantity)
        put("acquired", m.acquired); put("position", m.position); put("createdAt", m.createdAt)
    }

    private fun toolMaterialFromJson(o: JSONObject) = ToolMaterial(
        id = o.getLong("id"),
        buildId = o.getLong("buildId"),
        name = o.getString("name"),
        quantity = o.optString("quantity"),
        acquired = o.optBoolean("acquired", false),
        position = o.optInt("position", 0),
        createdAt = o.getLong("createdAt")
    )

    private fun resourceToJson(r: LearningResource) = JSONObject().apply {
        put("id", r.id); put("title", r.title); put("kind", r.kind); put("url", r.url)
        put("author", r.author); put("repairType", r.repairType); put("carPart", r.carPart)
        put("damageType", r.damageType); put("keyPoints", r.keyPoints); put("notes", r.notes)
        put("rating", r.rating); put("status", r.status)
        put("createdAt", r.createdAt); put("updatedAt", r.updatedAt)
    }

    private fun resourceFromJson(o: JSONObject) = LearningResource(
        id = o.getLong("id"),
        title = o.getString("title"),
        kind = o.optString("kind", "VIDEO"),
        url = o.optString("url"),
        author = o.optString("author"),
        repairType = o.optString("repairType", "PDR"),
        carPart = o.optString("carPart"),
        damageType = o.optString("damageType"),
        keyPoints = o.optString("keyPoints"),
        notes = o.optString("notes"),
        rating = o.optInt("rating", 0).coerceIn(0, 5),
        status = o.optString("status", "TO_WATCH"),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )

    private fun knowledgeToJson(k: KnowledgeEntry) = JSONObject().apply {
        put("id", k.id); put("title", k.title); put("category", k.category); put("kind", k.kind)
        put("body", k.body); put("source", k.source); put("carPart", k.carPart)
        put("damageType", k.damageType); put("createdAt", k.createdAt); put("updatedAt", k.updatedAt)
    }

    private fun knowledgeFromJson(o: JSONObject) = KnowledgeEntry(
        id = o.getLong("id"),
        title = o.getString("title"),
        category = o.optString("category"),
        kind = o.optString("kind", "PERSONAL"),
        body = o.optString("body"),
        source = o.optString("source"),
        carPart = o.optString("carPart"),
        damageType = o.optString("damageType"),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )
}
