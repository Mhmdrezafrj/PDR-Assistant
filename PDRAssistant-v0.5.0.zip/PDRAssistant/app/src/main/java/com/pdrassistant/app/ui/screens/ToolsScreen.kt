package com.pdrassistant.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.Tool
import com.pdrassistant.app.domain.RelatedExperiences
import com.pdrassistant.app.domain.Suggestions
import com.pdrassistant.app.ui.Route
import com.pdrassistant.app.ui.components.ChoiceRow
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.EmptyState
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.components.SuggestionRow
import com.pdrassistant.app.ui.components.Tag
import com.pdrassistant.app.ui.theme.PdrColors

private enum class ToolFilter(val label: String) {
    ALL("همه"), OWNED("دارم"), MISSING("ندارم")
}

// ============================ فهرست ============================

@Composable
fun ToolsScreen(
    tools: List<Tool>,
    go: (Route) -> Unit,
    onToggleOwned: (Tool) -> Unit
) {
    var filter by remember { mutableStateOf(ToolFilter.ALL) }
    var query by remember { mutableStateOf("") }
    val q = RelatedExperiences.normalize(query)

    val shown = tools.filter { t ->
        when (filter) {
            ToolFilter.ALL -> true
            ToolFilter.OWNED -> t.owned
            ToolFilter.MISSING -> !t.owned
        } && (q.isEmpty() ||
            RelatedExperiences.normalize(t.name + " " + t.category + " " + t.notes).contains(q))
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle(
                    "بانک ابزار",
                    "${tools.count { it.owned }} ابزار دارم · ${tools.count { !it.owned }} ندارم",
                    Modifier.weight(1f)
                )
                PillButton("جدید", onClick = { go(Route.ToolEdit(null)) })
            }
        }
        item { PdrField(query, { query = it }, "جستجو (نام، دسته، یادداشت)") }
        item { ChoiceRow(ToolFilter.entries, filter, { it.label }, { filter = it }) }
        if (shown.isEmpty()) {
            item {
                EmptyState(
                    if (tools.isEmpty()) "بانک ابزار خالی است" else "نتیجه‌ای پیدا نشد",
                    if (tools.isEmpty()) "ابزارهای کارگاه‌تان را ثبت کنید تا در چک‌لیست پروژه‌ها بدانید کدام را دارید."
                    else "عبارت یا فیلتر را تغییر دهید."
                )
            }
        }
        items(shown, key = { it.id }) { t ->
            DarkCard(onClick = { go(Route.ToolEdit(t.id)) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(if (t.owned) PdrColors.Peach else PdrColors.Danger, 16)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            t.name, color = PdrColors.Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        val sub = listOf(t.category, t.notes).filter { it.isNotBlank() }.joinToString(" · ")
                        if (sub.isNotBlank()) {
                            Text(sub, color = PdrColors.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    // لمس برچسب، وضعیت «دارم/ندارم» را فوراً عوض می‌کند.
                    Tag(
                        if (t.owned) "دارم" else "ندارم",
                        color = if (t.owned) PdrColors.Peach else PdrColors.Danger,
                        selected = true,
                        onClick = { onToggleOwned(t) }
                    )
                }
            }
        }
    }
}

// ============================ ایجاد/ویرایش ============================

@Composable
fun ToolEditScreen(
    existing: Tool?,
    allTools: List<Tool>,
    onBack: () -> Unit,
    onSave: (Tool, (Long) -> Unit) -> Unit,
    onDelete: (Tool) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var category by remember { mutableStateOf(existing?.category.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }
    var owned by remember { mutableStateOf(existing?.owned ?: true) }
    var saving by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    val nameKey = RelatedExperiences.normalize(name)
    val duplicate = nameKey.isNotEmpty() &&
        allTools.any { it.id != existing?.id && RelatedExperiences.normalize(it.name) == nameKey }

    SubScreen(if (existing == null) "ابزار جدید" else "ویرایش ابزار", onBack) {
        PdrField(name, { name = it }, "نام ابزار (الزامی)")
        if (duplicate) {
            Text(
                "ابزاری با همین نام قبلاً ثبت شده است. اگر ذخیره کنید، دو مورد هم‌نام خواهید داشت.",
                color = PdrColors.Danger, fontSize = 13.sp
            )
        }
        SuggestionRow(Suggestions.tools) { name = it }

        PdrField(category, { category = it }, "دسته")
        SuggestionRow(Suggestions.toolCategories) { category = it }

        SectionLabel("وضعیت")
        ChoiceRow(listOf(true, false), owned, { if (it) "دارم" else "ندارم / باید تهیه شود" }, { owned = it })

        PdrField(notes, { notes = it }, "یادداشت (مدل، اندازه، محل نگهداری، نکته استفاده...)", minLines = 3)

        PillButton(
            if (saving) "در حال ذخیره..." else "ذخیره",
            onClick = {
                if (name.isNotBlank() && !saving) {
                    saving = true
                    val base = existing ?: Tool(name = "", createdAt = 0, updatedAt = 0)
                    onSave(
                        base.copy(name = name.trim(), category = category.trim(), notes = notes.trim(), owned = owned)
                    ) { onBack() }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
        if (name.isBlank()) Text("برای ذخیره، نام ابزار را وارد کنید.", color = PdrColors.Muted, fontSize = 13.sp)

        if (existing != null) {
            PillButton("حذف ابزار", onClick = { confirmDelete = true }, primary = false)
        }
    }

    if (confirmDelete && existing != null) {
        ConfirmDialog(
            "حذف ابزار؟",
            "ابزار «${existing.name}» از بانک حذف می‌شود. تجربه‌ها و چک‌لیست‌ها تغییری نمی‌کنند.",
            "حذف",
            onConfirm = { confirmDelete = false; onDelete(existing); onBack() },
            onDismiss = { confirmDelete = false }
        )
    }
}
