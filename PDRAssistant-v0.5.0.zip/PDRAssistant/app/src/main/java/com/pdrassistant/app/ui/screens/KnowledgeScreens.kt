package com.pdrassistant.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.KnowledgeEntry
import com.pdrassistant.app.domain.KnowledgeKind
import com.pdrassistant.app.domain.KnowledgeLogic
import com.pdrassistant.app.domain.Suggestions
import com.pdrassistant.app.ui.Route
import com.pdrassistant.app.ui.components.ChoiceRow
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.DetailBlock
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.EmptyState
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PeachCard
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.components.SuggestionRow
import com.pdrassistant.app.ui.components.Tag
import com.pdrassistant.app.ui.formatDate
import com.pdrassistant.app.ui.shareText
import com.pdrassistant.app.ui.theme.PdrColors

/** رنگ نشانه‌ی هر نوع مطلب: اصل فنی آبی، تجربه‌ی شخصی هلویی، فرضیه صورتی. */
fun knowledgeColor(key: String?): Color = when (KnowledgeKind.fromKey(key)) {
    KnowledgeKind.FACT -> PdrColors.Blue
    KnowledgeKind.PERSONAL -> PdrColors.Peach
    KnowledgeKind.HYPOTHESIS -> PdrColors.Pink
}

// ============================ فهرست ============================

@Composable
fun KnowledgeListScreen(entries: List<KnowledgeEntry>, go: (Route) -> Unit) {
    var query by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf<KnowledgeKind?>(null) }
    var category by remember { mutableStateOf<String?>(null) }

    val categories = KnowledgeLogic.categoriesIn(entries)
    // اگر دسته‌ی انتخاب‌شده دیگر وجود ندارد (مثلاً حذف شده)، فیلتر را کنار بگذار.
    val activeCategory = category?.takeIf { c -> categories.any { it == c } }
    val shown = KnowledgeLogic.filter(KnowledgeLogic.search(entries, query), kind?.key, activeCategory)
    val groups = KnowledgeLogic.groupByCategory(shown)
    val counts = KnowledgeLogic.countByKind(entries)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle(
                    "دانشنامه‌ی من",
                    "${entries.size} مطلب · ${counts[KnowledgeKind.FACT]} اصل فنی · " +
                        "${counts[KnowledgeKind.PERSONAL]} تجربه · ${counts[KnowledgeKind.HYPOTHESIS]} فرضیه",
                    Modifier.weight(1f)
                )
                PillButton("جدید", onClick = { go(Route.KnowledgeEdit(null)) })
            }
        }
        item { PdrField(query, { query = it }, "جستجو (عنوان، متن، منبع، قطعه...)") }
        item {
            ChoiceRow(
                listOf<KnowledgeKind?>(null) + KnowledgeKind.entries, kind,
                { it?.label ?: "همه‌ی انواع" }, { kind = it }
            )
        }
        if (categories.isNotEmpty()) {
            item {
                ChoiceRow(
                    listOf<String?>(null) + categories, activeCategory,
                    { it ?: "همه‌ی دسته‌ها" }, { category = it }
                )
            }
        }
        if (shown.isEmpty()) {
            item {
                EmptyState(
                    if (entries.isEmpty()) "دانشنامه خالی است" else "نتیجه‌ای پیدا نشد",
                    if (entries.isEmpty())
                        "هر نکته‌ای که درباره‌ی ورق، ابزار و تعمیر یاد می‌گیرید را اینجا بنویسید و مشخص کنید اصل فنی است، تجربه‌ی خودتان است یا فقط فرضیه. برنامه خودش هیچ مطلب فنی اضافه نمی‌کند."
                    else "عبارت یا فیلتر را تغییر دهید."
                )
            }
        }
        groups.forEach { (name, list) ->
            item(key = "h-$name") { SectionLabel("$name (${list.size})") }
            items(list, key = { it.id }) { k -> KnowledgeRow(k) { go(Route.KnowledgeDetail(k.id)) } }
        }
    }
}

@Composable
fun KnowledgeRow(k: KnowledgeEntry, onClick: () -> Unit) {
    DarkCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Dot(knowledgeColor(k.kind), 18)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    k.title, color = PdrColors.Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                val sub = listOf(k.carPart, k.damageType).filter { it.isNotBlank() }.joinToString(" · ")
                if (sub.isNotEmpty()) {
                    Text(sub, color = PdrColors.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Tag(KnowledgeKind.fromKey(k.kind).label, color = knowledgeColor(k.kind))
        }
    }
}

// ============================ جزئیات ============================

@Composable
fun KnowledgeDetailScreen(
    entry: KnowledgeEntry?,
    onBack: () -> Unit,
    go: (Route) -> Unit,
    onDelete: (KnowledgeEntry) -> Unit
) {
    if (entry == null) {
        SubScreen("مطلب دانشنامه", onBack) { EmptyState("مطلب پیدا نشد", "ممکن است حذف شده باشد.") }
        return
    }
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    val kind = KnowledgeKind.fromKey(entry.kind)

    SubScreen(entry.title, onBack) {
        PeachCard {
            Column {
                Text(
                    listOf(kind.label, entry.category).filter { it.isNotBlank() }.joinToString(" · "),
                    color = PdrColors.PeachDark, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(entry.title, color = PdrColors.PeachDark, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text("ثبت: ${formatDate(entry.createdAt)}", color = PdrColors.PeachDark, fontSize = 13.sp)
            }
        }

        // یادآوری صریح: این مطلب از چه جنسی است.
        DarkCard {
            Row(verticalAlignment = Alignment.Top) {
                Dot(knowledgeColor(entry.kind), 14)
                Spacer(Modifier.width(10.dp))
                Text(kind.warning, color = PdrColors.Cream, fontSize = 14.sp)
            }
        }

        DarkCard {
            Column {
                DetailBlock("متن", entry.body)
                DetailBlock("منبع", entry.source)
                DetailBlock("قطعه", entry.carPart)
                DetailBlock("نوع آسیب", entry.damageType)
                if (entry.body.isBlank()) {
                    Text("هنوز متنی نوشته نشده. با «ویرایش» بنویسید.", color = PdrColors.Muted)
                }
                if (kind == KnowledgeKind.FACT && entry.source.isBlank()) {
                    Text("منبعی ثبت نشده؛ برای اصل فنی بهتر است منبع هم نوشته شود.", color = PdrColors.Muted, fontSize = 13.sp)
                }
            }
        }

        PillButton(
            "ارسال مطلب",
            onClick = {
                val text = buildString {
                    append(entry.title).append(" (").append(kind.label).append(")\n")
                    if (entry.body.isNotBlank()) append(entry.body.trim()).append('\n')
                    if (entry.source.isNotBlank()) append("منبع: ").append(entry.source.trim()).append('\n')
                    append(kind.warning)
                }
                shareText(context, entry.title, text)
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("ویرایش", onClick = { go(Route.KnowledgeEdit(entry.id)) }, primary = false)
            PillButton("حذف", onClick = { confirmDelete = true }, primary = false)
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            "حذف مطلب؟",
            "مطلب «${entry.title}» حذف می‌شود.",
            "حذف",
            onConfirm = { confirmDelete = false; onDelete(entry); onBack() },
            onDismiss = { confirmDelete = false }
        )
    }
}

// ============================ ایجاد/ویرایش ============================

@Composable
fun KnowledgeEditScreen(
    existing: KnowledgeEntry?,
    allEntries: List<KnowledgeEntry>,
    onBack: () -> Unit,
    onSave: (KnowledgeEntry, (Long) -> Unit) -> Unit,
    onSaved: (Long) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var category by remember { mutableStateOf(existing?.category.orEmpty()) }
    var kind by remember { mutableStateOf(KnowledgeKind.fromKey(existing?.kind)) }
    var body by remember { mutableStateOf(existing?.body.orEmpty()) }
    var source by remember { mutableStateOf(existing?.source.orEmpty()) }
    var carPart by remember { mutableStateOf(existing?.carPart.orEmpty()) }
    var damage by remember { mutableStateOf(existing?.damageType.orEmpty()) }
    var saving by remember { mutableStateOf(false) }

    SubScreen(if (existing == null) "مطلب جدید" else "ویرایش مطلب", onBack) {
        PdrField(title, { title = it }, "عنوان (الزامی)")

        SectionLabel("این مطلب از چه جنسی است؟")
        ChoiceRow(KnowledgeKind.entries, kind, { it.label }, { kind = it })
        Text(kind.warning, color = PdrColors.Muted, fontSize = 13.sp)

        PdrField(category, { category = it }, "دسته")
        SuggestionRow(KnowledgeLogic.categorySuggestions(allEntries)) { category = it }

        PdrField(body, { body = it }, "متن (توضیح، دلیل، شرایط درست‌بودن...)", minLines = 6)
        PdrField(source, { source = it }, "منبع (کتاب، استاد، آزمایش خودم...)")

        PdrField(carPart, { carPart = it }, "قطعه مرتبط (برای نمایش در پروژه‌ها)")
        SuggestionRow(Suggestions.carParts) { carPart = it }
        PdrField(damage, { damage = it }, "نوع آسیب مرتبط (برای نمایش در پروژه‌ها)")
        SuggestionRow(Suggestions.damageTypes) { damage = it }

        PillButton(
            if (saving) "در حال ذخیره..." else "ذخیره",
            onClick = {
                if (title.isNotBlank() && !saving) {
                    saving = true
                    val base = existing ?: KnowledgeEntry(title = "", createdAt = 0, updatedAt = 0)
                    onSave(
                        base.copy(
                            title = title.trim(), category = category.trim(), kind = kind.key,
                            body = body.trim(), source = source.trim(),
                            carPart = carPart.trim(), damageType = damage.trim()
                        ),
                        onSaved
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
        if (title.isBlank()) Text("برای ذخیره، عنوان را وارد کنید.", color = PdrColors.Muted, fontSize = 13.sp)
    }
}
