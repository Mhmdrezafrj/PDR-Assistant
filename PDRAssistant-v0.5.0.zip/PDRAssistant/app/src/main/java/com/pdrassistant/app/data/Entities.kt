package com.pdrassistant.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** پروژه تعمیراتی (یک خودرو / یک قطعه / یک آسیب). */
@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val vehicle: String = "",          // مثلاً «پژو ۲۰۶ - سفید»
    val plate: String = "",            // اختیاری
    val carPart: String = "",
    val damageType: String = "",
    val repairType: String = "PDR",
    val status: String = "PLANNED",
    val notes: String = "",
    val resultNotes: String = "",      // ارزیابی نتیجه بعد از پایان کار
    @ColumnInfo(defaultValue = "''") val outcome: String = "",        // "" = ارزیابی نشده | SUCCESS | PARTIAL | FAILED
    @ColumnInfo(defaultValue = "0") val timeSpentMinutes: Int = 0,
    @ColumnInfo(defaultValue = "''") val mistakes: String = "",       // اشتباهات و مشکلات
    @ColumnInfo(defaultValue = "''") val lessons: String = "",        // درس‌هایی که یاد گرفتم
    val createdAt: Long,
    val updatedAt: Long
)

/** تجربه/تکنیک ثبت‌شده استادکار؛ همه فیلدهای بخش ۶ مستند. */
@Entity(
    tableName = "experiences",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("projectId")]
)
data class Experience(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val repairType: String = "PDR",
    val carPart: String = "",
    val damageType: String = "",
    val tools: String = "",            // هر ابزار در یک خط
    val steps: String = "",            // هر مرحله در یک خط
    val conditions: String = "",       // شرایط استفاده
    val result: String = "",
    val possibleErrors: String = "",   // خطاهای احتمالی
    val mediaFiles: String = "",       // نام فایل‌های داخل حافظه برنامه، هر کدام در یک خط
    val source: String = "",           // منبع اطلاعات
    val confidence: String = "UNSURE",
    val masterNotes: String = "",      // یادداشت استادکار
    val projectId: Long? = null,
    val createdAt: Long,
    val updatedAt: Long
)

/** ابزار یا تجهیزات کارگاه (بانک ابزار). */
@Entity(tableName = "tools")
data class Tool(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String = "",
    val notes: String = "",
    val owned: Boolean = true,         // true = دارم، false = ندارم / باید تهیه شود
    val createdAt: Long,
    val updatedAt: Long
)

/** یک مرحله از چک‌لیست تعمیر یک پروژه. با حذف پروژه، مرحله‌هایش هم حذف می‌شوند. */
@Entity(
    tableName = "checklist_items",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class ChecklistItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val text: String,
    val done: Boolean = false,
    val position: Int = 0,
    val createdAt: Long
)

/** پروژه ساخت ابزار دست‌ساز: هدف، طرح/نقشه، عکس‌ها، مراحل ساخت. مواد اولیه در [ToolMaterial]. */
@Entity(tableName = "tool_builds")
data class ToolBuild(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val purpose: String = "",          // این ابزار برای چه کاری است
    val status: String = "IDEA",       // IDEA | BUILDING | DONE
    val design: String = "",           // توضیح طرح، ابعاد و اندازه‌ها
    val steps: String = "",            // مراحل ساخت، هر مرحله در یک خط
    val planFiles: String = "",        // تصاویر طرح/نقشه (نام فایل‌ها، هر کدام در یک خط)
    val photoFiles: String = "",       // عکس/ویدئوی مراحل ساخت و نتیجه
    val result: String = "",           // نتیجه، مشکلات و اصلاحات
    val toolId: Long? = null,          // ابزار ثبت‌شده در بانک ابزار (پس از ساخت)
    val createdAt: Long,
    val updatedAt: Long
)

/** یک ماده اولیه یا قطعه موردنیاز برای ساخت ابزار. */
@Entity(
    tableName = "tool_materials",
    foreignKeys = [
        ForeignKey(
            entity = ToolBuild::class,
            parentColumns = ["id"],
            childColumns = ["buildId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("buildId")]
)
data class ToolMaterial(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val buildId: Long,
    val name: String,
    val quantity: String = "",         // متن آزاد: «۲ متر»، «۴ عدد»، «۱۰ سانتی‌متر»
    val acquired: Boolean = false,     // تهیه شده؟
    val position: Int = 0,
    val createdAt: Long
)

/** منبع آموزشی: ویدئو، مقاله، کتاب، دوره و ... همراه با نکات کلیدی و نظر خودم. */
@Entity(tableName = "learning_resources")
data class LearningResource(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val kind: String = "VIDEO",         // VIDEO | ARTICLE | BOOK | COURSE | OTHER
    val url: String = "",               // لینک (اختیاری)
    val author: String = "",            // استاد / کانال / نویسنده
    val repairType: String = "PDR",
    val carPart: String = "",
    val damageType: String = "",
    val keyPoints: String = "",         // نکات کلیدی و زمان‌بندی (هر نکته در یک خط)
    val notes: String = "",             // نظر و یادداشت خودم
    val rating: Int = 0,                // 0 = بدون امتیاز، 1 تا 5 = مفید بودن
    val status: String = "TO_WATCH",    // TO_WATCH | WATCHED | TRIED
    val createdAt: Long,
    val updatedAt: Long
)

/**
 * مطلب دانشنامه‌ی شخصی. هر مطلب برچسب نوع دارد تا «اصل فنی»، «تجربه‌ی شخصی» و «فرضیه» با هم قاطی نشوند.
 * برنامه هیچ مطلب آماده‌ای ندارد؛ همه‌ی محتوا را خود استادکار می‌نویسد.
 */
@Entity(tableName = "knowledge_entries")
data class KnowledgeEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "",
    val kind: String = "PERSONAL",      // FACT | PERSONAL | HYPOTHESIS
    val body: String = "",
    val source: String = "",            // منبع (اختیاری؛ برای اصل فنی توصیه می‌شود)
    val carPart: String = "",
    val damageType: String = "",
    val createdAt: Long,
    val updatedAt: Long
)
