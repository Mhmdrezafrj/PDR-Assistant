package com.pdrassistant.app.domain

import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Tool

/** منطق خالص و آفلاین چک‌لیست و ابزارهای پیشنهادی (بدون وابستگی به اندروید). */
object ChecklistLogic {

    private val leadingNumber = Regex("^\\s*(?:[0-9\u06F0-\u06F9\u0660-\u0669]+\\s*[.\\-)\u060C:]|[-*\u2022])\\s*")

    /** شماره یا نشانه ابتدای خط («۱.»، «2-»، «- ») را برمی‌دارد. */
    fun cleanLine(line: String): String = line.replace(leadingNumber, "").trim()

    /**
     * مراحل یک تجربه را به متن‌های چک‌لیست تبدیل می‌کند.
     * خط‌های خالی و مواردی که از قبل در [existing] هستند (یا تکراری‌اند) نادیده گرفته می‌شوند.
     */
    fun stepsToItems(steps: String, existing: List<String>): List<String> {
        val seen = existing.map { RelatedExperiences.normalize(it) }.toMutableSet()
        val out = mutableListOf<String>()
        for (raw in steps.lines()) {
            val text = cleanLine(raw)
            if (text.isEmpty()) continue
            if (seen.add(RelatedExperiences.normalize(text))) out.add(text)
        }
        return out
    }

    data class SuggestedTool(val name: String, val inBank: Tool?) {
        /** true فقط وقتی ابزار در بانک ثبت شده و «دارم» است. */
        val available: Boolean get() = inBank?.owned == true
    }

    /**
     * ابزارهای ذکرشده در تجربه‌های مرتبط، بدون تکرار، همراه با وضعیت‌شان در بانک ابزار.
     * ابزارهایی که در بانک نیستند هم نشان داده می‌شوند تا کاربر بداند ثبت نکرده است.
     */
    fun suggestedTools(related: List<Experience>, bank: List<Tool>): List<SuggestedTool> {
        val byName = bank.associateBy { RelatedExperiences.normalize(it.name) }
        val seen = mutableSetOf<String>()
        val out = mutableListOf<SuggestedTool>()
        for (e in related) {
            for (raw in e.tools.lines()) {
                val name = cleanLine(raw)
                if (name.isEmpty()) continue
                val key = RelatedExperiences.normalize(name)
                if (seen.add(key)) out.add(SuggestedTool(name, byName[key]))
            }
        }
        return out
    }
}
