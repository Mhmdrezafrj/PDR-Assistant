package com.pdrassistant.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class Repository(private val context: Context, private val db: AppDatabase) {

    val projects: Flow<List<Project>> = db.projectDao().observeAll()
    val experiences: Flow<List<Experience>> = db.experienceDao().observeAll()
    val tools: Flow<List<Tool>> = db.toolDao().observeAll()
    val checklist: Flow<List<ChecklistItem>> = db.checklistDao().observeAll()
    val toolBuilds: Flow<List<ToolBuild>> = db.toolBuildDao().observeAll()
    val toolMaterials: Flow<List<ToolMaterial>> = db.toolMaterialDao().observeAll()
    val resources: Flow<List<LearningResource>> = db.learningResourceDao().observeAll()
    val knowledge: Flow<List<KnowledgeEntry>> = db.knowledgeEntryDao().observeAll()

    private val mediaDir: File
        get() = File(context.filesDir, "media").also { it.mkdirs() }

    fun mediaFile(name: String): File = File(mediaDir, File(name).name)

    // ---------- پروژه‌ها ----------
    suspend fun saveProject(p: Project): Long {
        val now = System.currentTimeMillis()
        return if (p.id == 0L) {
            db.projectDao().insert(p.copy(createdAt = now, updatedAt = now))
        } else {
            db.projectDao().update(p.copy(updatedAt = now))
            p.id
        }
    }

    suspend fun deleteProject(p: Project) = db.projectDao().delete(p)

    // ---------- ابزار ----------
    suspend fun saveTool(t: Tool): Long {
        val now = System.currentTimeMillis()
        return if (t.id == 0L) {
            db.toolDao().insert(t.copy(createdAt = now, updatedAt = now))
        } else {
            db.toolDao().update(t.copy(updatedAt = now))
            t.id
        }
    }

    suspend fun deleteTool(t: Tool) = db.toolDao().delete(t)

    // ---------- کتابخانه آموزش ----------
    suspend fun saveResource(r: LearningResource): Long {
        val now = System.currentTimeMillis()
        return if (r.id == 0L) {
            db.learningResourceDao().insert(r.copy(createdAt = now, updatedAt = now))
        } else {
            db.learningResourceDao().update(r.copy(updatedAt = now))
            r.id
        }
    }

    suspend fun deleteResource(r: LearningResource) = db.learningResourceDao().delete(r)

    // ---------- دانشنامه ----------
    suspend fun saveKnowledge(k: KnowledgeEntry): Long {
        val now = System.currentTimeMillis()
        return if (k.id == 0L) {
            db.knowledgeEntryDao().insert(k.copy(createdAt = now, updatedAt = now))
        } else {
            db.knowledgeEntryDao().update(k.copy(updatedAt = now))
            k.id
        }
    }

    suspend fun deleteKnowledge(k: KnowledgeEntry) = db.knowledgeEntryDao().delete(k)

    // ---------- ساخت ابزار ----------
    suspend fun saveToolBuild(b: ToolBuild): Long {
        val now = System.currentTimeMillis()
        return if (b.id == 0L) {
            db.toolBuildDao().insert(b.copy(createdAt = now, updatedAt = now))
        } else {
            db.toolBuildDao().update(b.copy(updatedAt = now))
            b.id
        }
    }

    /** ساخت ابزار و فایل‌های طرح/عکس آن را حذف می‌کند؛ مواد اولیه خودکار حذف می‌شوند. */
    suspend fun deleteToolBuild(b: ToolBuild) {
        db.toolBuildDao().delete(b)
        (b.planFiles.lines() + b.photoFiles.lines()).filter { it.isNotBlank() }.forEach { name ->
            withContext(Dispatchers.IO) { mediaFile(name).delete() }
        }
    }

    suspend fun addToolMaterial(buildId: Long, name: String, quantity: String) {
        val pos = db.toolMaterialDao().maxPosition(buildId) + 1
        db.toolMaterialDao().insert(
            ToolMaterial(
                buildId = buildId, name = name, quantity = quantity,
                position = pos, createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun setMaterialAcquired(id: Long, acquired: Boolean) =
        db.toolMaterialDao().setAcquired(id, acquired)

    suspend fun deleteToolMaterial(m: ToolMaterial) = db.toolMaterialDao().delete(m)

    // ---------- چک‌لیست ----------
    suspend fun addChecklistItems(projectId: Long, texts: List<String>) {
        if (texts.isEmpty()) return
        val now = System.currentTimeMillis()
        val start = db.checklistDao().maxPosition(projectId) + 1
        db.checklistDao().insertAll(
            texts.mapIndexed { i, t ->
                ChecklistItem(projectId = projectId, text = t, position = start + i, createdAt = now)
            }
        )
    }

    suspend fun setChecklistDone(id: Long, done: Boolean) = db.checklistDao().setDone(id, done)

    suspend fun deleteChecklistItem(item: ChecklistItem) = db.checklistDao().delete(item)

    // ---------- تجربه‌ها ----------
    suspend fun saveExperience(e: Experience): Long {
        val now = System.currentTimeMillis()
        return if (e.id == 0L) {
            db.experienceDao().insert(e.copy(createdAt = now, updatedAt = now))
        } else {
            db.experienceDao().update(e.copy(updatedAt = now))
            e.id
        }
    }

    suspend fun deleteExperience(e: Experience) {
        db.experienceDao().delete(e)
        e.mediaFiles.lines().filter { it.isNotBlank() }.forEach { name ->
            withContext(Dispatchers.IO) { mediaFile(name).delete() }
        }
    }

    // ---------- رسانه ----------
    /** فایل انتخاب‌شده را به حافظه داخلی برنامه کپی می‌کند و نام جدید را برمی‌گرداند (یا null). */
    suspend fun importMedia(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val mime = context.contentResolver.getType(uri).orEmpty()
            val ext = when {
                mime.contains("png") -> "png"
                mime.contains("webp") -> "webp"
                mime.startsWith("video/") -> "mp4"
                else -> "jpg"
            }
            val name = "${UUID.randomUUID()}.$ext"
            context.contentResolver.openInputStream(uri)?.use { input ->
                mediaFile(name).outputStream().use { out -> input.copyTo(out) }
            } ?: return@withContext null
            name
        } catch (e: Exception) {
            null
        }
    }

    suspend fun deleteMedia(name: String) = withContext(Dispatchers.IO) { mediaFile(name).delete() }

    // ---------- پشتیبان‌گیری ----------
    suspend fun exportBackup(target: Uri) = withContext(Dispatchers.IO) {
        val json = BackupCodec.encode(
            db.projectDao().getAll(),
            db.experienceDao().getAll(),
            System.currentTimeMillis(),
            db.toolDao().getAll(),
            db.checklistDao().getAll(),
            db.toolBuildDao().getAll(),
            db.toolMaterialDao().getAll(),
            db.learningResourceDao().getAll(),
            db.knowledgeEntryDao().getAll()
        )
        val out = context.contentResolver.openOutputStream(target, "wt")
            ?: throw BackupCodec.BackupException("امکان نوشتن فایل نیست.")
        out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
    }

    /** اطلاعات فعلی را کاملاً با محتوای پشتیبان جایگزین می‌کند (تراکنشی). تعداد را برمی‌گرداند. */
    suspend fun importBackup(source: Uri): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val text = context.contentResolver.openInputStream(source)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw BackupCodec.BackupException("امکان خواندن فایل نیست.")
        val snap = BackupCodec.decode(text)
        db.backupDao().replaceAll(snap)
        snap.projects.size to snap.experiences.size
    }
}
