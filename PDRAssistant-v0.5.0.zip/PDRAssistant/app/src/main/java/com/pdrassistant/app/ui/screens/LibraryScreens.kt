package com.pdrassistant.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.KnowledgeEntry
import com.pdrassistant.app.data.LearningResource
import com.pdrassistant.app.domain.RepairType
import com.pdrassistant.app.domain.ResourceKind
import com.pdrassistant.app.domain.ResourceLogic
import com.pdrassistant.app.domain.ResourceStatus
import com.pdrassistant.app.domain.Suggestions
import com.pdrassistant.app.ui.Route
import com.pdrassistant.app.ui.components.ChoiceRow
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.DetailBlock
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.EmptyState
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PeachCard
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.components.SuggestionRow
import com.pdrassistant.app.ui.components.Tag
import com.pdrassistant.app.ui.formatDate
import com.pdrassistant.app.ui.openUrl
import com.pdrassistant.app.ui.repairColor
import com.pdrassistant.app.ui.theme.PdrColors

// ============================ تب «تجربیات»: حافظه / کتابخانه آموزش ============================

enum class ExperiencesTab(val label: String) {
    MEMORY("حافظه تجربیات"),
    LIBRARY("کتابخانه آموزش"),
    KNOWLEDGE("دانشنامه")
}

@Composable
fun ExperiencesHost(
    selected: ExperiencesTab,
    onSelect: (ExperiencesTab) -> Unit,
    experiences: List<Experience>,
    resources: List<LearningResource>,
    knowledge: List<KnowledgeEntry>,
    go: (Route) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
            ChoiceRow(ExperiencesTab.entries, selected, { it.label }, onSelect)
        }
        Box(Modifier.weight(1f)) {
            when (selected) {
                ExperiencesTab.MEMORY -> ExperiencesScreen(experiences, go)
                ExperiencesTab.LIBRARY -> LibraryListScreen(resources, go)
                ExperiencesTab.KNOWLEDGE -> KnowledgeListScreen(knowledge, go)
            }
        }
    }
}

private fun stars(n: Int): String = if (n <= 0) "بدون امتیاز" else "★".repeat(n.coerceIn(1, 5)) + "☆".repeat(5 - n.coerceIn(1, 5))

// ============================ فهرست ============================

@Composable
fun LibraryListScreen(resources: List<LearningResource>, go: (Route) -> Unit) {
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<ResourceStatus?>(null) }
    val shown = ResourceLogic.search(resources, query).filter { status == null || it.status == status!!.key }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle("کتابخانه آموزش", "${resources.size} منبع", Modifier.weight(1f))
                PillButton("جدید", onClick = { go(Route.ResourceEdit(null)) })
            }
        }
        item { PdrField(query, { query = it }, "جستجو (عنوان، استاد، قطعه، نکات...)") }
        item {
            ChoiceRow(
                listOf<ResourceStatus?>(null) + ResourceStatus.entries, status,
                { it?.label ?: "همه" }, { status = it }
            )
        }
        if (shown.isEmpty()) {
            item {
                EmptyState(
                    if (resources.isEmpty()) "کتابخانه خالی است" else "نتیجه‌ای پیدا نشد",
                    if (resources.isEmpty()) "ویدئوها، مقاله‌ها و دوره‌هایی که می‌بینید را با نکات کلیدی‌شان اینجا ثبت کنید."
                    else "عبارت یا فیلتر را تغییر دهید."
                )
            }
        }
        items(shown, key = { it.id }) { r -> ResourceRow(r) { go(Route.ResourceDetail(r.id)) } }
    }
}

@Composable
fun ResourceRow(r: LearningResource, onClick: () -> Unit) {
    DarkCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Dot(repairColor(r.repairType), 18)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    r.title, color = PdrColors.Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                val sub = listOf(ResourceKind.fromKey(r.kind).label, r.author, r.carPart, r.damageType)
                    .filter { it.isNotBlank() }.joinToString(" · ")
                Text(sub, color = PdrColors.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (r.rating > 0) Text(stars(r.rating), color = PdrColors.Peach, fontSize = 13.sp)
            }
            Tag(ResourceStatus.fromKey(r.status).label, color = PdrColors.Peach)
        }
    }
}

// ============================ جزئیات ============================

@Composable
fun ResourceDetailScreen(
    resource: LearningResource?,
    onBack: () -> Unit,
    go: (Route) -> Unit,
    onSaveResource: (LearningResource) -> Unit,
    onDelete: (LearningResource) -> Unit
) {
    if (resource == null) {
        SubScreen("منبع آموزشی", onBack) { EmptyState("منبع پیدا نشد", "ممکن است حذف شده باشد.") }
        return
    }
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    var linkFailed by remember { mutableStateOf(false) }
    val status = ResourceStatus.fromKey(resource.status)

    SubScreen(resource.title, onBack) {
        PeachCard {
            Column {
                Text(
                    listOf(ResourceKind.fromKey(resource.kind).label, RepairType.labelOf(resource.repairType)).joinToString(" · "),
                    color = PdrColors.PeachDark, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(resource.title, color = PdrColors.PeachDark, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                if (resource.author.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(resource.author, color = PdrColors.PeachDark, fontSize = 14.sp)
                }
                Spacer(Modifier.height(4.dp))
                Text("ثبت: ${formatDate(resource.createdAt)}", color = PdrColors.PeachDark, fontSize = 13.sp)
            }
        }

        SectionLabel("وضعیت یادگیری")
        ChoiceRow(ResourceStatus.entries, status, { it.label }, { onSaveResource(resource.copy(status = it.key)) })

        SectionLabel("امتیاز مفید بودن: ${stars(resource.rating)}")
        ChoiceRow(
            listOf(0, 1, 2, 3, 4, 5), resource.rating,
            { if (it == 0) "بدون امتیاز" else "★$it" },
            { onSaveResource(resource.copy(rating = it)) }
        )

        if (resource.url.isNotBlank()) {
            PillButton(
                "باز کردن لینک",
                onClick = { linkFailed = !openUrl(context, ResourceLogic.normalizeUrl(resource.url)) },
                modifier = Modifier.fillMaxWidth()
            )
            Text(ResourceLogic.normalizeUrl(resource.url), color = PdrColors.Muted, fontSize = 12.sp)
            if (linkFailed) Text("باز کردن لینک ممکن نشد.", color = PdrColors.Danger, fontSize = 13.sp)
        }

        DarkCard {
            Column {
                DetailBlock("قطعه", resource.carPart)
                DetailBlock("نوع آسیب", resource.damageType)
                DetailBlock("نکات کلیدی", resource.keyPoints)
                DetailBlock("نظر و یادداشت من", resource.notes)
                if (listOf(resource.carPart, resource.damageType, resource.keyPoints, resource.notes).all { it.isBlank() }) {
                    Text("هنوز نکته‌ای ثبت نشده. با «ویرایش» نکات کلیدی را بنویسید.", color = PdrColors.Muted)
                }
            }
        }

        PillButton(
            "تبدیل به تجربه",
            onClick = { go(Route.ExperienceEdit(null, null, resource.id)) },
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "تجربه‌ی تازه با اطمینان «${if (status == ResourceStatus.TRIED) "یک‌بار انجام‌شده" else "شنیده/دیده‌شده"}» ساخته می‌شود؛ " +
                "هر چه خودتان آزمودید، بعداً اطمینانش را بالا ببرید.",
            color = PdrColors.Muted, fontSize = 13.sp
        )

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("ویرایش", onClick = { go(Route.ResourceEdit(resource.id)) }, primary = false)
            PillButton("حذف", onClick = { confirmDelete = true }, primary = false)
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            "حذف منبع؟",
            "منبع «${resource.title}» حذف می‌شود. تجربه‌هایی که از آن ساخته‌اید می‌مانند.",
            "حذف",
            onConfirm = { confirmDelete = false; onDelete(resource); onBack() },
            onDismiss = { confirmDelete = false }
        )
    }
}

// ============================ ایجاد/ویرایش ============================

@Composable
fun ResourceEditScreen(
    existing: LearningResource?,
    onBack: () -> Unit,
    onSave: (LearningResource, (Long) -> Unit) -> Unit,
    onSaved: (Long) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var kind by remember { mutableStateOf(ResourceKind.fromKey(existing?.kind)) }
    var url by remember { mutableStateOf(existing?.url.orEmpty()) }
    var author by remember { mutableStateOf(existing?.author.orEmpty()) }
    var repair by remember { mutableStateOf(RepairType.fromKey(existing?.repairType) ?: RepairType.PDR) }
    var carPart by remember { mutableStateOf(existing?.carPart.orEmpty()) }
    var damage by remember { mutableStateOf(existing?.damageType.orEmpty()) }
    var keyPoints by remember { mutableStateOf(existing?.keyPoints.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }
    var rating by remember { mutableStateOf(existing?.rating ?: 0) }
    var status by remember { mutableStateOf(ResourceStatus.fromKey(existing?.status)) }
    var saving by remember { mutableStateOf(false) }

    val urlOk = ResourceLogic.isValidUrl(url)

    SubScreen(if (existing == null) "منبع آموزشی جدید" else "ویرایش منبع", onBack) {
        PdrField(title, { title = it }, "عنوان (الزامی)")

        SectionLabel("نوع منبع")
        ChoiceRow(ResourceKind.entries, kind, { it.label }, { kind = it })

        PdrField(url, { url = it }, "لینک (اختیاری)")
        if (!urlOk) Text("لینک معتبر نیست (مثلاً youtu.be/abc یا https://aparat.com/v/xyz).", color = PdrColors.Danger, fontSize = 13.sp)
        PdrField(author, { author = it }, "استاد / کانال / نویسنده")

        SectionLabel("نوع تعمیر")
        ChoiceRow(RepairType.entries, repair, { it.label }, { repair = it })

        PdrField(carPart, { carPart = it }, "قطعه مرتبط")
        SuggestionRow(Suggestions.carParts) { carPart = it }
        PdrField(damage, { damage = it }, "نوع آسیب مرتبط")
        SuggestionRow(Suggestions.damageTypes) { damage = it }

        PdrField(keyPoints, { keyPoints = it }, "نکات کلیدی (هر نکته در یک خط؛ می‌توانید زمان ویدئو را هم بنویسید)", minLines = 5)
        PdrField(notes, { notes = it }, "نظر من (چه چیزش درست یا قابل‌اعتماد بود؟ چه چیزش نه؟)", minLines = 3)

        SectionLabel("وضعیت یادگیری")
        ChoiceRow(ResourceStatus.entries, status, { it.label }, { status = it })

        SectionLabel("امتیاز مفید بودن")
        ChoiceRow(listOf(0, 1, 2, 3, 4, 5), rating, { if (it == 0) "بدون امتیاز" else "★$it" }, { rating = it })

        PillButton(
            if (saving) "در حال ذخیره..." else "ذخیره",
            onClick = {
                if (title.isNotBlank() && urlOk && !saving) {
                    saving = true
                    val base = existing ?: LearningResource(title = "", createdAt = 0, updatedAt = 0)
                    onSave(
                        base.copy(
                            title = title.trim(), kind = kind.key, url = ResourceLogic.normalizeUrl(url),
                            author = author.trim(), repairType = repair.key, carPart = carPart.trim(),
                            damageType = damage.trim(), keyPoints = keyPoints.trim(), notes = notes.trim(),
                            rating = rating, status = status.key
                        ),
                        onSaved
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
        if (title.isBlank()) Text("برای ذخیره، عنوان را وارد کنید.", color = PdrColors.Muted, fontSize = 13.sp)
    }
}
