package com.pdrassistant.app.domain

import com.pdrassistant.app.data.Experience

/**
 * بازیابی تجربیات مرتبط با یک پروژه یا تجربه.
 * منطق کاملاً آفلاین و بدون هوش مصنوعی است: امتیازدهی بر اساس تطابق فیلدها.
 *
 * وزن‌ها: قطعه (۳) + نوع آسیب (۳) + نوع تعمیر (۲) + اعتماد (۰ تا ۱).
 * تطابق متنی با نادیده‌گرفتن فاصله‌های اضافی و تفاوت نوشتاری «ي/ی» و «ك/ک» انجام می‌شود.
 */
object RelatedExperiences {

    data class Scored(val experience: Experience, val score: Int)

    fun normalize(text: String?): String =
        (text ?: "")
            .replace('ي', 'ی')
            .replace('ك', 'ک')
            .replace('‌', ' ')
            .trim()
            .replace(Regex("\\s+"), " ")
            .lowercase()

    private fun sameText(a: String?, b: String?): Boolean {
        val na = normalize(a)
        val nb = normalize(b)
        return na.isNotEmpty() && na == nb
    }

    fun score(
        repairType: String?,
        carPart: String?,
        damageType: String?,
        candidate: Experience
    ): Int {
        var s = 0
        if (sameText(carPart, candidate.carPart)) s += 3
        if (sameText(damageType, candidate.damageType)) s += 3
        if (!repairType.isNullOrBlank() && repairType == candidate.repairType) s += 2
        // فقط وقتی حداقل یک تطابق واقعی هست، اعتماد به تجربه را به‌عنوان امتیاز تکمیلی بشمار.
        if (s > 0 && candidate.confidence == Confidence.TESTED.key) s += 1
        return s
    }

    /**
     * @param excludeId شناسه‌ای که باید حذف شود (مثلاً خود تجربه در حال نمایش).
     * @return حداکثر [limit] تجربه با امتیاز مثبت، مرتب از بیشترین امتیاز و سپس جدیدترین.
     */
    fun rank(
        repairType: String?,
        carPart: String?,
        damageType: String?,
        all: List<Experience>,
        excludeId: Long? = null,
        limit: Int = 5
    ): List<Scored> =
        all.asSequence()
            .filter { it.id != excludeId }
            .map { Scored(it, score(repairType, carPart, damageType, it)) }
            .filter { it.score > 0 }
            .sortedWith(compareByDescending<Scored> { it.score }.thenByDescending { it.experience.updatedAt })
            .take(limit)
            .toList()
}
