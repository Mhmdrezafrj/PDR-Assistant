package com.pdrassistant.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.ChecklistItem
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.domain.ChecklistLogic
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.components.Tag
import com.pdrassistant.app.ui.theme.PdrColors

/** چک‌لیست مراحل تعمیر یک پروژه: افزودن دستی یا از مراحل تجربه‌ها، تیک زدن، حذف. */
@Composable
fun ChecklistSection(
    items: List<ChecklistItem>,
    candidates: List<Experience>,
    onAddItems: (List<String>) -> Unit,
    onToggle: (ChecklistItem, Boolean) -> Unit,
    onDelete: (ChecklistItem) -> Unit
) {
    var newText by remember { mutableStateOf("") }
    var showImport by remember { mutableStateOf(false) }
    val done = items.count { it.done }

    SectionLabel("چک‌لیست تعمیر ($done از ${items.size})")

    if (items.isNotEmpty()) {
        Box(Modifier.fillMaxWidth().height(8.dp).background(PdrColors.SurfaceDeep, RoundedCornerShape(50))) {
            Box(
                Modifier
                    .fillMaxWidth(done.toFloat() / items.size)
                    .height(8.dp)
                    .background(PdrColors.Peach, RoundedCornerShape(50))
            )
        }
    } else {
        Text(
            "هنوز مرحله‌ای ندارد. دستی بنویسید یا از مراحل یک تجربه‌ی ثبت‌شده بیاورید.",
            color = PdrColors.Muted, fontSize = 14.sp
        )
    }

    items.forEach { item ->
        Row(
            Modifier
                .fillMaxWidth()
                .background(PdrColors.Surface, RoundedCornerShape(18.dp))
                .clickable { onToggle(item, !item.done) }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(26.dp)
                    .background(if (item.done) PdrColors.Peach else PdrColors.SurfaceDeep, RoundedCornerShape(8.dp))
                    .border(2.dp, PdrColors.Peach, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (item.done) Text("✓", color = PdrColors.PeachDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(Modifier.width(12.dp))
            Text(
                item.text,
                modifier = Modifier.weight(1f),
                color = if (item.done) PdrColors.Muted else PdrColors.Cream,
                textDecoration = if (item.done) TextDecoration.LineThrough else TextDecoration.None,
                fontSize = 16.sp
            )
            Box(
                Modifier.size(36.dp).clickable { onDelete(item) },
                contentAlignment = Alignment.Center
            ) { Text("✕", color = PdrColors.Muted, fontSize = 16.sp) }
        }
    }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PdrField(newText, { newText = it }, "مرحله جدید", modifier = Modifier.weight(1f))
        PillButton("افزودن", onClick = {
            val text = newText.trim()
            if (text.isNotEmpty()) {
                onAddItems(listOf(text))
                newText = ""
            }
        })
    }
    PillButton("افزودن مراحل از تجربه", onClick = { showImport = true }, primary = false)

    if (showImport) {
        val withSteps = candidates.filter { it.steps.isNotBlank() }
        val existing = items.map { it.text }
        AlertDialog(
            onDismissRequest = { showImport = false },
            containerColor = PdrColors.Surface,
            title = { Text("مراحل کدام تجربه؟", color = PdrColors.Cream, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (withSteps.isEmpty()) {
                        Text(
                            "تجربه‌ی مرتبطی با «مراحل اجرا» ثبت نشده. ابتدا یک تجربه با مراحل ثبت کنید.",
                            color = PdrColors.Muted
                        )
                    }
                    withSteps.forEach { e ->
                        val fresh = ChecklistLogic.stepsToItems(e.steps, existing)
                        DarkCard(onClick = if (fresh.isEmpty()) null else ({
                            onAddItems(fresh)
                            showImport = false
                        })) {
                            Column {
                                Text(e.title, color = PdrColors.Cream, fontWeight = FontWeight.Bold)
                                Text(
                                    if (fresh.isEmpty()) "همه‌ی مراحل قبلاً اضافه شده" else "${fresh.size} مرحله جدید",
                                    color = if (fresh.isEmpty()) PdrColors.Muted else PdrColors.Peach,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showImport = false }) { Text("بستن", color = PdrColors.Cream) }
            }
        )
    }
}

/** ابزارهای ذکرشده در تجربه‌های مرتبط، با وضعیتشان در بانک ابزار. */
@Composable
fun SuggestedToolsSection(
    suggested: List<ChecklistLogic.SuggestedTool>,
    onQuickAdd: (String) -> Unit
) {
    SectionLabel("ابزارهای مورد نیاز (از تجربه‌های مرتبط)")
    if (suggested.isEmpty()) {
        Text("در تجربه‌های مرتبط، ابزاری ثبت نشده است.", color = PdrColors.Muted, fontSize = 14.sp)
        return
    }
    suggested.forEach { s ->
        DarkCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(
                    when {
                        s.available -> PdrColors.Peach
                        s.inBank != null -> PdrColors.Danger
                        else -> PdrColors.Muted
                    }, 14
                )
                Spacer(Modifier.width(10.dp))
                Text(s.name, color = PdrColors.Cream, modifier = Modifier.weight(1f))
                when {
                    s.available -> Tag("دارم", color = PdrColors.Peach)
                    s.inBank != null -> Tag("ندارم", color = PdrColors.Danger)
                    else -> Tag("ثبت در بانک", color = PdrColors.Blue, onClick = { onQuickAdd(s.name) })
                }
            }
        }
    }
}
