package com.pdrassistant.app.domain

import com.pdrassistant.app.data.ChecklistItem
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Project

/** گزارش کار متنی (برای ارسال با پیام‌رسان‌ها) و ابزارهای زمان. بدون وابستگی به اندروید. */
object ProjectReport {

    /**
     * عدد دقیقه را از متن کاربر می‌خواند. ارقام فارسی و عربی هم پذیرفته می‌شود.
     * متن خالی = ۰، متن نامعتبر یا بزرگ‌تر از ۱۰۰٬۰۰۰ = null.
     */
    fun parseMinutes(text: String): Int? {
        val ascii = buildString {
            for (c in text.trim()) {
                when (c) {
                    in '۰'..'۹' -> append('0' + (c - '۰'))
                    in '٠'..'٩' -> append('0' + (c - '٠'))
                    else -> append(c)
                }
            }
        }
        if (ascii.isEmpty()) return 0
        if (!ascii.all { it in '0'..'9' } || ascii.length > 6) return null
        val n = ascii.toInt()
        return if (n > 100_000) null else n
    }

    fun formatDuration(minutes: Int): String {
        if (minutes <= 0) return "ثبت نشده"
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h > 0 && m > 0 -> "$h ساعت و $m دقیقه"
            h > 0 -> "$h ساعت"
            else -> "$m دقیقه"
        }
    }

    fun build(
        project: Project,
        checklist: List<ChecklistItem>,
        linkedExperiences: List<Experience>,
        dateText: String
    ): String {
        val sb = StringBuilder()
        fun line(label: String, value: String) { if (value.isNotBlank()) sb.append(label).append(": ").append(value.trim()).append('\n') }

        sb.append("گزارش کار — ").append(project.title).append('\n')
        sb.append("تاریخ ثبت: ").append(dateText).append("\n\n")
        line("خودرو", project.vehicle)
        line("پلاک / شناسه", project.plate)
        line("نوع تعمیر", RepairType.labelOf(project.repairType))
        line("قطعه", project.carPart)
        line("نوع آسیب", project.damageType)
        line("وضعیت", ProjectStatus.fromKey(project.status).label)
        line("نتیجه", Outcome.labelOf(project.outcome))
        if (project.timeSpentMinutes > 0) line("زمان صرف‌شده", formatDuration(project.timeSpentMinutes))
        line("یادداشت", project.notes)

        if (checklist.isNotEmpty()) {
            sb.append("\nچک‌لیست (").append(checklist.count { it.done }).append(" از ").append(checklist.size).append("):\n")
            checklist.forEach { sb.append(if (it.done) "[✓] " else "[ ] ").append(it.text).append('\n') }
        }

        val tools = ChecklistLogic.suggestedTools(linkedExperiences, emptyList()).map { it.name }
        if (tools.isNotEmpty()) {
            sb.append("\nابزارها:\n")
            tools.forEach { sb.append("- ").append(it).append('\n') }
        }

        fun block(title: String, text: String) {
            if (text.isNotBlank()) sb.append('\n').append(title).append(":\n").append(text.trim()).append('\n')
        }
        block("اشتباهات و مشکلات", project.mistakes)
        block("درس‌ها", project.lessons)
        block("توضیح نتیجه", project.resultNotes)
        return sb.toString().trimEnd() + "\n"
    }
}
