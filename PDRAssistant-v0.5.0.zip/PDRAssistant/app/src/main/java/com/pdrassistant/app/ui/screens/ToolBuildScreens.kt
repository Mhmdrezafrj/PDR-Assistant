package com.pdrassistant.app.ui.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.Tool
import com.pdrassistant.app.data.ToolBuild
import com.pdrassistant.app.data.ToolMaterial
import com.pdrassistant.app.domain.BuildStatus
import com.pdrassistant.app.domain.Suggestions
import com.pdrassistant.app.domain.ToolBuildLogic
import com.pdrassistant.app.ui.Route
import com.pdrassistant.app.ui.components.ChoiceRow
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.DetailBlock
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.EmptyState
import com.pdrassistant.app.ui.components.MediaField
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PeachCard
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.components.SuggestionRow
import com.pdrassistant.app.ui.components.Tag
import com.pdrassistant.app.ui.components.rememberMediaState
import com.pdrassistant.app.ui.formatDate
import com.pdrassistant.app.ui.shareText
import com.pdrassistant.app.ui.theme.PdrColors
import java.io.File

// ============================ تب «ابزار»: بانک ابزار / ساخت ابزار ============================

enum class ToolsTab(val label: String) {
    BANK("بانک ابزار"),
    BUILDS("ساخت ابزار")
}

@Composable
fun ToolsHost(
    selected: ToolsTab,
    onSelect: (ToolsTab) -> Unit,
    tools: List<Tool>,
    builds: List<ToolBuild>,
    materials: List<ToolMaterial>,
    go: (Route) -> Unit,
    onToggleOwned: (Tool) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp)) {
            ChoiceRow(ToolsTab.entries, selected, { it.label }, onSelect)
        }
        Box(Modifier.weight(1f)) {
            when (selected) {
                ToolsTab.BANK -> ToolsScreen(tools, go, onToggleOwned)
                ToolsTab.BUILDS -> ToolBuildsListScreen(builds, materials, go)
            }
        }
    }
}

private fun buildColor(status: String) = when (BuildStatus.fromKey(status)) {
    BuildStatus.IDEA -> PdrColors.Blue
    BuildStatus.BUILDING -> PdrColors.Pink
    BuildStatus.DONE -> PdrColors.Peach
}

// ============================ فهرست ============================

@Composable
fun ToolBuildsListScreen(builds: List<ToolBuild>, materials: List<ToolMaterial>, go: (Route) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle("ساخت ابزار", "${builds.size} طرح", Modifier.weight(1f))
                PillButton("جدید", onClick = { go(Route.ToolBuildEdit(null)) })
            }
        }
        if (builds.isEmpty()) {
            item {
                EmptyState(
                    "هنوز ابزاری برای ساخت ثبت نشده",
                    "طرح، نقشه، عکس و مواد اولیه‌ی ابزارهای دست‌ساز را اینجا نگه دارید."
                )
            }
        }
        items(builds, key = { it.id }) { b ->
            val (done, total) = ToolBuildLogic.progress(materials.filter { it.buildId == b.id })
            DarkCard(onClick = { go(Route.ToolBuildDetail(b.id)) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(buildColor(b.status), 18)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            b.name, color = PdrColors.Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        val sub = buildString {
                            if (b.purpose.isNotBlank()) append(b.purpose.lines().first())
                            if (total > 0) {
                                if (isNotEmpty()) append(" · ")
                                append("مواد: $done از $total")
                            }
                        }
                        if (sub.isNotBlank()) {
                            Text(sub, color = PdrColors.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Tag(BuildStatus.fromKey(b.status).label, color = PdrColors.Peach)
                }
            }
        }
    }
}

// ============================ جزئیات ============================

@Composable
fun ToolBuildDetailScreen(
    build: ToolBuild?,
    materials: List<ToolMaterial>,
    registeredTool: Tool?,
    mediaFile: (String) -> File,
    onBack: () -> Unit,
    go: (Route) -> Unit,
    onSaveBuild: (ToolBuild) -> Unit,
    onAddMaterial: (String, String) -> Unit,
    onToggleMaterial: (ToolMaterial, Boolean) -> Unit,
    onDeleteMaterial: (ToolMaterial) -> Unit,
    onRegisterTool: (ToolBuild) -> Unit,
    onDelete: (ToolBuild) -> Unit
) {
    if (build == null) {
        SubScreen("ساخت ابزار", onBack) { EmptyState("طرح پیدا نشد", "ممکن است حذف شده باشد.") }
        return
    }
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    var matName by remember(build.id) { mutableStateOf("") }
    var matQty by remember(build.id) { mutableStateOf("") }

    val status = BuildStatus.fromKey(build.status)
    val (done, total) = ToolBuildLogic.progress(materials)
    val plans = build.planFiles.lines().filter { it.isNotBlank() }
    val photos = build.photoFiles.lines().filter { it.isNotBlank() }

    SubScreen(build.name, onBack) {
        PeachCard {
            Column {
                Text(status.label, color = PdrColors.PeachDark, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(build.name, color = PdrColors.PeachDark, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text("ثبت: ${formatDate(build.createdAt)}", color = PdrColors.PeachDark, fontSize = 13.sp)
            }
        }

        SectionLabel("وضعیت ساخت")
        ChoiceRow(BuildStatus.entries, status, { it.label }, { onSaveBuild(build.copy(status = it.key)) })

        DarkCard {
            Column {
                DetailBlock("کاربرد", build.purpose)
                DetailBlock("طرح و ابعاد", build.design)
                DetailBlock("مراحل ساخت", build.steps)
                DetailBlock("نتیجه و اصلاحات", build.result)
                if (listOf(build.purpose, build.design, build.steps, build.result).all { it.isBlank() }) {
                    Text("هنوز توضیحی وارد نشده. با «ویرایش» طرح و مراحل را بنویسید.", color = PdrColors.Muted)
                }
            }
        }

        if (plans.isNotEmpty()) {
            SectionLabel("طرح و نقشه")
            MediaStrip(plans, mediaFile, onRemove = null)
        }
        if (photos.isNotEmpty()) {
            SectionLabel("عکس و ویدئو")
            MediaStrip(photos, mediaFile, onRemove = null)
        }

        // ---------- مواد اولیه ----------
        SectionLabel("مواد اولیه ($done از $total تهیه شده)")
        if (total > 0) {
            Box(Modifier.fillMaxWidth().height(8.dp).background(PdrColors.SurfaceDeep, RoundedCornerShape(50))) {
                Box(
                    Modifier
                        .fillMaxWidth(done.toFloat() / total)
                        .height(8.dp)
                        .background(PdrColors.Peach, RoundedCornerShape(50))
                )
            }
            if (ToolBuildLogic.allAcquired(materials) && status == BuildStatus.IDEA) {
                Text("همه‌ی مواد تهیه شده؛ می‌توانید وضعیت را «در حال ساخت» کنید.", color = PdrColors.Peach, fontSize = 13.sp)
            }
        } else {
            Text("ماده‌ای ثبت نشده. هر ماده یا قطعه‌ی لازم را با مقدارش اضافه کنید.", color = PdrColors.Muted, fontSize = 14.sp)
        }

        materials.forEach { m ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(PdrColors.Surface, RoundedCornerShape(18.dp))
                    .clickable { onToggleMaterial(m, !m.acquired) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(26.dp)
                        .background(if (m.acquired) PdrColors.Peach else PdrColors.SurfaceDeep, RoundedCornerShape(8.dp))
                        .border(2.dp, PdrColors.Peach, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (m.acquired) Text("✓", color = PdrColors.PeachDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        m.name, fontSize = 16.sp,
                        color = if (m.acquired) PdrColors.Muted else PdrColors.Cream,
                        textDecoration = if (m.acquired) TextDecoration.LineThrough else TextDecoration.None
                    )
                    if (m.quantity.isNotBlank()) Text(m.quantity, color = PdrColors.Muted, fontSize = 13.sp)
                }
                Box(Modifier.size(36.dp).clickable { onDeleteMaterial(m) }, contentAlignment = Alignment.Center) {
                    Text("✕", color = PdrColors.Muted, fontSize = 16.sp)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PdrField(matName, { matName = it }, "ماده / قطعه", modifier = Modifier.weight(2f))
            PdrField(matQty, { matQty = it }, "مقدار", modifier = Modifier.weight(1f))
        }
        SuggestionRow(Suggestions.materials) { matName = it }
        PillButton("افزودن ماده", onClick = {
            val n = matName.trim()
            if (n.isNotEmpty()) {
                onAddMaterial(n, matQty.trim())
                matName = ""
                matQty = ""
            }
        }, modifier = Modifier.fillMaxWidth())
        if (total > 0) {
            PillButton(
                "ارسال فهرست خرید",
                onClick = { shareText(context, "فهرست خرید — ${build.name}", ToolBuildLogic.shoppingList(build, materials)) },
                primary = false, modifier = Modifier.fillMaxWidth()
            )
        }

        // ---------- ثبت در بانک ابزار ----------
        if (registeredTool != null) {
            DarkCard {
                Text("✓ در بانک ابزار ثبت شده: ${registeredTool.name}", color = PdrColors.Peach)
            }
        } else if (status == BuildStatus.DONE) {
            PillButton(
                "ثبت به‌عنوان ابزار در بانک ابزار",
                // اگر ابزار قبلاً از بانک حذف شده، پیوند قدیمی نادیده گرفته می‌شود
                onClick = { onRegisterTool(build.copy(toolId = null)) },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(Modifier.height(8.dp))
        PillButton(
            "ارسال گزارش ساخت",
            onClick = { shareText(context, "ساخت ابزار — ${build.name}", ToolBuildLogic.report(build, materials)) },
            primary = false, modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("ویرایش", onClick = { go(Route.ToolBuildEdit(build.id)) }, primary = false)
            PillButton("حذف", onClick = { confirmDelete = true }, primary = false)
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            "حذف این طرح؟",
            "طرح «${build.name}» به‌همراه مواد، طرح‌ها و عکس‌هایش حذف می‌شود. ابزار ثبت‌شده در بانک ابزار (اگر باشد) می‌ماند.",
            "حذف",
            onConfirm = { confirmDelete = false; onDelete(build); onBack() },
            onDismiss = { confirmDelete = false }
        )
    }
}

// ============================ ایجاد/ویرایش ============================

@Composable
fun ToolBuildEditScreen(
    existing: ToolBuild?,
    mediaFile: (String) -> File,
    onBack: () -> Unit,
    onSave: (ToolBuild, (Long) -> Unit) -> Unit,
    onSaved: (Long) -> Unit,
    onImportMedia: (Uri, (String?) -> Unit) -> Unit,
    onDeleteMedia: (String) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name.orEmpty()) }
    var purpose by remember { mutableStateOf(existing?.purpose.orEmpty()) }
    var status by remember { mutableStateOf(BuildStatus.fromKey(existing?.status)) }
    var design by remember { mutableStateOf(existing?.design.orEmpty()) }
    var steps by remember { mutableStateOf(existing?.steps.orEmpty()) }
    var result by remember { mutableStateOf(existing?.result.orEmpty()) }
    val plans = rememberMediaState(existing?.planFiles)
    val photos = rememberMediaState(existing?.photoFiles)
    var saving by remember { mutableStateOf(false) }

    SubScreen(if (existing == null) "ابزار جدید برای ساخت" else "ویرایش طرح ابزار", onBack) {
        PdrField(name, { name = it }, "نام ابزار (الزامی)")
        PdrField(purpose, { purpose = it }, "کاربرد: این ابزار برای چه کاری است؟", minLines = 2)

        SectionLabel("وضعیت ساخت")
        ChoiceRow(BuildStatus.entries, status, { it.label }, { status = it })

        PdrField(design, { design = it }, "طرح و ابعاد (اندازه‌ها، جنس، شکل)", minLines = 4)

        MediaField(
            label = "تصاویر طرح و نقشه (عکس از نقشه‌ی دست‌کشیده، اسکرین‌شات طراحی ...)",
            addLabel = "افزودن تصویر طرح / نقشه",
            state = plans, mediaFile = mediaFile,
            onImportMedia = onImportMedia, onDeleteMedia = onDeleteMedia, allowVideo = false
        )

        PdrField(steps, { steps = it }, "مراحل ساخت (هر مرحله در یک خط)", minLines = 4)

        MediaField(
            label = "عکس و ویدئوی مراحل ساخت و نتیجه",
            addLabel = "افزودن عکس / ویدئو",
            state = photos, mediaFile = mediaFile,
            onImportMedia = onImportMedia, onDeleteMedia = onDeleteMedia, allowVideo = true
        )

        PdrField(result, { result = it }, "نتیجه، مشکلات و اصلاحات", minLines = 3)

        if (existing == null) {
            Text("مواد اولیه را بعد از ذخیره، در صفحه‌ی همین طرح اضافه می‌کنید.", color = PdrColors.Muted, fontSize = 13.sp)
        }

        PillButton(
            if (saving) "در حال ذخیره..." else "ذخیره",
            onClick = {
                if (name.isNotBlank() && !saving) {
                    saving = true
                    plans.committed = true
                    photos.committed = true
                    val removedOld = plans.removedOld() + photos.removedOld()
                    val base = existing ?: ToolBuild(name = "", createdAt = 0, updatedAt = 0)
                    onSave(
                        base.copy(
                            name = name.trim(), purpose = purpose.trim(), status = status.key,
                            design = design.trim(), steps = steps.trim(), result = result.trim(),
                            planFiles = plans.asText(), photoFiles = photos.asText()
                        )
                    ) { id ->
                        removedOld.forEach { onDeleteMedia(it) }
                        onSaved(id)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
        if (name.isBlank()) Text("برای ذخیره، نام ابزار را وارد کنید.", color = PdrColors.Muted, fontSize = 13.sp)
    }
}
