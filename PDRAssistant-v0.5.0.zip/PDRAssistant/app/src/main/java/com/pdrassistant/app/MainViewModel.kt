package com.pdrassistant.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pdrassistant.app.data.BackupCodec
import com.pdrassistant.app.data.ChecklistItem
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.KnowledgeEntry
import com.pdrassistant.app.data.LearningResource
import com.pdrassistant.app.data.Project
import com.pdrassistant.app.data.Repository
import com.pdrassistant.app.data.Tool
import com.pdrassistant.app.data.ToolBuild
import com.pdrassistant.app.data.ToolMaterial
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo: Repository = (app as PdrApp).repository

    val projects: StateFlow<List<Project>?> =
        repo.projects.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val experiences: StateFlow<List<Experience>?> =
        repo.experiences.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val tools: StateFlow<List<Tool>?> =
        repo.tools.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val checklist: StateFlow<List<ChecklistItem>?> =
        repo.checklist.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val toolBuilds: StateFlow<List<ToolBuild>?> =
        repo.toolBuilds.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val toolMaterials: StateFlow<List<ToolMaterial>?> =
        repo.toolMaterials.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val resources: StateFlow<List<LearningResource>?> =
        repo.resources.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val knowledge: StateFlow<List<KnowledgeEntry>?> =
        repo.knowledge.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** پیام کوتاه برای کاربر (Toast-مانند). */
    val message = MutableStateFlow<String?>(null)

    fun saveProject(p: Project, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveProject(p)
        onDone(id)
    }

    fun deleteProject(p: Project) = viewModelScope.launch { repo.deleteProject(p) }

    fun saveExperience(e: Experience, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveExperience(e)
        onDone(id)
    }

    fun deleteExperience(e: Experience) = viewModelScope.launch { repo.deleteExperience(e) }

    fun saveTool(t: Tool, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveTool(t)
        onDone(id)
    }

    fun deleteTool(t: Tool) = viewModelScope.launch { repo.deleteTool(t) }

    fun addChecklistItems(projectId: Long, texts: List<String>) = viewModelScope.launch {
        repo.addChecklistItems(projectId, texts)
    }

    fun setChecklistDone(id: Long, done: Boolean) = viewModelScope.launch { repo.setChecklistDone(id, done) }

    fun deleteChecklistItem(item: ChecklistItem) = viewModelScope.launch { repo.deleteChecklistItem(item) }

    fun saveResource(r: LearningResource, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveResource(r)
        onDone(id)
    }

    fun deleteResource(r: LearningResource) = viewModelScope.launch { repo.deleteResource(r) }

    fun saveKnowledge(k: KnowledgeEntry, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveKnowledge(k)
        onDone(id)
    }

    fun deleteKnowledge(k: KnowledgeEntry) = viewModelScope.launch { repo.deleteKnowledge(k) }

    fun saveToolBuild(b: ToolBuild, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveToolBuild(b)
        onDone(id)
    }

    fun deleteToolBuild(b: ToolBuild) = viewModelScope.launch { repo.deleteToolBuild(b) }

    fun addToolMaterial(buildId: Long, name: String, quantity: String) = viewModelScope.launch {
        repo.addToolMaterial(buildId, name, quantity)
    }

    fun setMaterialAcquired(id: Long, acquired: Boolean) = viewModelScope.launch {
        repo.setMaterialAcquired(id, acquired)
    }

    fun deleteToolMaterial(m: ToolMaterial) = viewModelScope.launch { repo.deleteToolMaterial(m) }

    /**
     * ابزار ساخته‌شده را در بانک ابزار ثبت می‌کند و به ساخت ابزار پیوند می‌دهد.
     * اگر قبلاً ثبت شده باشد کاری نمی‌کند.
     */
    fun registerBuiltTool(b: ToolBuild) = viewModelScope.launch {
        if (b.toolId != null) return@launch
        val toolId = repo.saveTool(
            Tool(
                name = b.name, category = "دست‌ساز", notes = b.purpose, owned = true,
                createdAt = 0, updatedAt = 0
            )
        )
        repo.saveToolBuild(b.copy(toolId = toolId))
        message.value = "ابزار در بانک ابزار ثبت شد."
    }

    fun importMedia(uri: Uri, onResult: (String?) -> Unit) = viewModelScope.launch {
        val name = repo.importMedia(uri)
        if (name == null) message.value = "افزودن فایل ناموفق بود."
        onResult(name)
    }

    fun deleteMedia(name: String) = viewModelScope.launch { repo.deleteMedia(name) }

    fun exportBackup(uri: Uri) = viewModelScope.launch {
        message.value = try {
            repo.exportBackup(uri)
            "پشتیبان با موفقیت ذخیره شد."
        } catch (e: Exception) {
            "ذخیره پشتیبان ناموفق بود: ${e.message ?: "خطای نامشخص"}"
        }
    }

    fun importBackup(uri: Uri) = viewModelScope.launch {
        message.value = try {
            val (p, e) = repo.importBackup(uri)
            "بازیابی انجام شد: $p پروژه و $e تجربه."
        } catch (e: BackupCodec.BackupException) {
            e.message
        } catch (e: Exception) {
            "بازیابی ناموفق بود؛ اطلاعات فعلی دست‌نخورده ماند."
        }
    }
}
