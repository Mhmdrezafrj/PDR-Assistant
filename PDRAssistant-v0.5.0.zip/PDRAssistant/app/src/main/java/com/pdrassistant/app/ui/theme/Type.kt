package com.pdrassistant.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.pdrassistant.app.R

/**
 * فونت‌های برنامه (Digi):
 * - [Body]: «همیشه» برای همه متن‌ها (دارای نیم‌فاصله و ارقام فارسی)
 * - [Title]: «لاله‌زار پلاس» فقط برای عنوان صفحه‌ها
 */
object PdrFonts {
    val Body = FontFamily(
        Font(R.font.digi_hamishe_regular, FontWeight.Normal),
        Font(R.font.digi_hamishe_bold, FontWeight.Bold)
    )
    val Title = FontFamily(
        Font(R.font.digi_lalezar_plus, FontWeight.Normal)
    )
}

/** همه سبک‌های Material با فونت برنامه (برای فیلدهای متنی، دیالوگ‌ها و ...). */
fun pdrTypography(): Typography {
    val d = Typography()
    val f = PdrFonts.Body
    return Typography(
        displayLarge = d.displayLarge.copy(fontFamily = f),
        displayMedium = d.displayMedium.copy(fontFamily = f),
        displaySmall = d.displaySmall.copy(fontFamily = f),
        headlineLarge = d.headlineLarge.copy(fontFamily = f),
        headlineMedium = d.headlineMedium.copy(fontFamily = f),
        headlineSmall = d.headlineSmall.copy(fontFamily = f),
        titleLarge = d.titleLarge.copy(fontFamily = f),
        titleMedium = d.titleMedium.copy(fontFamily = f),
        titleSmall = d.titleSmall.copy(fontFamily = f),
        bodyLarge = d.bodyLarge.copy(fontFamily = f),
        bodyMedium = d.bodyMedium.copy(fontFamily = f),
        bodySmall = d.bodySmall.copy(fontFamily = f),
        labelLarge = d.labelLarge.copy(fontFamily = f),
        labelMedium = d.labelMedium.copy(fontFamily = f),
        labelSmall = d.labelSmall.copy(fontFamily = f)
    )
}
