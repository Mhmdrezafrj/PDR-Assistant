package com.pdrassistant.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.PeachCard
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.theme.PdrColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupScreen(
    projectCount: Int,
    experienceCount: Int,
    versionName: String,
    onExport: (Uri) -> Unit,
    onImport: (Uri) -> Unit
) {
    var pendingImport by remember { mutableStateOf<Uri?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> if (uri != null) onExport(uri) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> if (uri != null) pendingImport = uri }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("پشتیبان‌گیری", "اطلاعات شما فقط روی همین گوشی است")

        PeachCard {
            Column {
                Text("اطلاعات فعلی", color = PdrColors.PeachDark, fontSize = 14.sp)
                Text(
                    "$projectCount پروژه · $experienceCount تجربه",
                    color = PdrColors.PeachDark, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
                )
            }
        }

        DarkCard {
            Column {
                Text("ذخیره پشتیبان", color = PdrColors.Cream, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "یک فایل پشتیبان می‌سازد. آن را در جای امن (حافظه گوشی، Google Drive، تلگرام «Saved Messages») نگه دارید. " +
                        "نکته: تصاویر و ویدئوها (از جمله تصاویر طرح و نقشه‌ی ساخت ابزار) داخل فایل پشتیبان نیستند؛ فقط متن‌ها، ابزارها، چک‌لیست‌ها و مواد اولیه ذخیره می‌شوند.",
                    color = PdrColors.Muted, fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                PillButton(
                    "ذخیره پشتیبان",
                    onClick = {
                        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
                        exportLauncher.launch("pdr-backup-$stamp.json")
                    }
                )
            }
        }

        DarkCard {
            Column {
                Text("بازیابی از پشتیبان", color = PdrColors.Cream, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "هشدار: بازیابی، تمام پروژه‌ها و تجربه‌های فعلی را با محتوای فایل جایگزین می‌کند. " +
                        "اگر فایل خراب باشد، اطلاعات فعلی دست‌نخورده می‌ماند.",
                    color = PdrColors.Muted, fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                PillButton(
                    "انتخاب فایل پشتیبان",
                    onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) },
                    primary = false
                )
            }
        }

        Text("دستیار PDR · نسخه $versionName", color = PdrColors.Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
    }

    pendingImport?.let { uri ->
        ConfirmDialog(
            "جایگزینی اطلاعات؟",
            "تمام اطلاعات فعلی حذف و با فایل پشتیبان جایگزین می‌شود. ادامه می‌دهید؟",
            "بازیابی",
            onConfirm = { pendingImport = null; onImport(uri) },
            onDismiss = { pendingImport = null }
        )
    }
}
