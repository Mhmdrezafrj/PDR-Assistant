package com.pdrassistant.app

import android.app.Application
import com.pdrassistant.app.data.AppDatabase
import com.pdrassistant.app.data.Repository

class PdrApp : Application() {
    val repository: Repository by lazy { Repository(this, AppDatabase.get(this)) }
}
