package com.pdrassistant.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdrassistant.app.BuildConfig
import com.pdrassistant.app.MainViewModel
import com.pdrassistant.app.ui.screens.BackupScreen
import com.pdrassistant.app.ui.screens.DashboardScreen
import com.pdrassistant.app.ui.screens.ExperienceDetailScreen
import com.pdrassistant.app.ui.screens.ExperienceEditScreen
import com.pdrassistant.app.ui.screens.ExperiencesScreen
import com.pdrassistant.app.ui.screens.ProjectDetailScreen
import com.pdrassistant.app.ui.screens.ProjectEditScreen
import com.pdrassistant.app.ui.screens.ProjectsScreen
import com.pdrassistant.app.ui.screens.ExperiencesHost
import com.pdrassistant.app.ui.screens.ExperiencesTab
import com.pdrassistant.app.ui.screens.KnowledgeDetailScreen
import com.pdrassistant.app.ui.screens.KnowledgeEditScreen
import com.pdrassistant.app.ui.screens.ResourceDetailScreen
import com.pdrassistant.app.ui.screens.ResourceEditScreen
import com.pdrassistant.app.ui.screens.ToolBuildDetailScreen
import com.pdrassistant.app.ui.screens.ToolBuildEditScreen
import com.pdrassistant.app.ui.screens.ToolEditScreen
import com.pdrassistant.app.ui.screens.ToolsHost
import com.pdrassistant.app.ui.screens.ToolsTab
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.pdrassistant.app.ui.screens.ToolsScreen
import com.pdrassistant.app.data.Tool
import com.pdrassistant.app.ui.theme.PdrColors

private val tabs = listOf(
    Route.Dashboard to "خانه",
    Route.Projects to "پروژه‌ها",
    Route.Experiences to "تجربیات",
    Route.Tools to "ابزار",
    Route.Backup to "پشتیبان"
)

@Composable
fun AppRoot(vm: MainViewModel) {
    val projects by vm.projects.collectAsStateWithLifecycle()
    val experiences by vm.experiences.collectAsStateWithLifecycle()
    val tools by vm.tools.collectAsStateWithLifecycle()
    val checklist by vm.checklist.collectAsStateWithLifecycle()
    val toolBuilds by vm.toolBuilds.collectAsStateWithLifecycle()
    val toolMaterials by vm.toolMaterials.collectAsStateWithLifecycle()
    // بخش انتخاب‌شده در تب «ابزار» با رفت‌وآمد بین صفحه‌ها حفظ شود
    var toolsTab by remember { mutableStateOf(ToolsTab.BANK) }
    val resources by vm.resources.collectAsStateWithLifecycle()
    val knowledge by vm.knowledge.collectAsStateWithLifecycle()
    var experiencesTab by remember { mutableStateOf(ExperiencesTab.MEMORY) }
    val message by vm.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.message.value = null
        }
    }

    val stack = remember { mutableStateListOf<Route>(Route.Dashboard) }
    val current = stack.last()
    val isTab = tabs.any { it.first == current }

    fun push(r: Route) { stack.add(r) }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    fun goTab(r: Route) { stack.clear(); stack.add(r) }
    /** بعد از ذخیره: صفحه ویرایش را با صفحه جزئیات جایگزین می‌کند. */
    fun replaceTop(r: Route) {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
        // اگر همین صفحه درست زیر آن بود (ویرایش از داخل جزئیات)، فقط برگرد تا صفحه تکراری نماند.
        if (stack.last() != r) stack.add(r)
    }

    BackHandler(enabled = stack.size > 1) { pop() }

    Scaffold(
        containerColor = PdrColors.Bg,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { if (isTab) BottomBar(current, ::goTab) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            val ps = projects
            val es = experiences
            val ts = tools
            val cl = checklist
            val tb = toolBuilds
            val tm = toolMaterials
            val rs = resources
            val kn = knowledge
            if (ps == null || es == null || ts == null || cl == null || tb == null || tm == null || rs == null || kn == null) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = PdrColors.Peach)
                return@Box
            }
            when (val r = current) {
                Route.Dashboard -> DashboardScreen(ps, es, ::push)
                Route.Projects -> ProjectsScreen(ps, ::push)
                Route.Experiences -> ExperiencesHost(
                    selected = experiencesTab, onSelect = { experiencesTab = it },
                    experiences = es, resources = rs, knowledge = kn, go = ::push
                )
                is Route.KnowledgeDetail -> KnowledgeDetailScreen(
                    entry = kn.firstOrNull { it.id == r.id },
                    onBack = ::pop, go = ::push,
                    onDelete = { vm.deleteKnowledge(it) }
                )
                is Route.KnowledgeEdit -> KnowledgeEditScreen(
                    existing = r.id?.let { id -> kn.firstOrNull { it.id == id } },
                    allEntries = kn,
                    onBack = ::pop,
                    onSave = { x, done -> vm.saveKnowledge(x, done) },
                    onSaved = { id -> replaceTop(Route.KnowledgeDetail(id)) }
                )
                is Route.ResourceDetail -> ResourceDetailScreen(
                    resource = rs.firstOrNull { it.id == r.id },
                    onBack = ::pop, go = ::push,
                    onSaveResource = { vm.saveResource(it) },
                    onDelete = { vm.deleteResource(it) }
                )
                is Route.ResourceEdit -> ResourceEditScreen(
                    existing = r.id?.let { id -> rs.firstOrNull { it.id == id } },
                    onBack = ::pop,
                    onSave = { x, done -> vm.saveResource(x, done) },
                    onSaved = { id -> replaceTop(Route.ResourceDetail(id)) }
                )
                Route.Tools -> ToolsHost(
                    selected = toolsTab, onSelect = { toolsTab = it },
                    tools = ts, builds = tb, materials = tm, go = ::push,
                    onToggleOwned = { vm.saveTool(it.copy(owned = !it.owned)) }
                )
                is Route.ToolBuildDetail -> {
                    val b = tb.firstOrNull { it.id == r.id }
                    ToolBuildDetailScreen(
                        build = b,
                        materials = tm.filter { it.buildId == r.id },
                        registeredTool = b?.toolId?.let { tid -> ts.firstOrNull { it.id == tid } },
                        mediaFile = vm.repo::mediaFile,
                        onBack = ::pop, go = ::push,
                        onSaveBuild = { vm.saveToolBuild(it) },
                        onAddMaterial = { name, qty -> vm.addToolMaterial(r.id, name, qty) },
                        onToggleMaterial = { m, acquired -> vm.setMaterialAcquired(m.id, acquired) },
                        onDeleteMaterial = { vm.deleteToolMaterial(it) },
                        onRegisterTool = { vm.registerBuiltTool(it) },
                        onDelete = { vm.deleteToolBuild(it) }
                    )
                }
                is Route.ToolBuildEdit -> ToolBuildEditScreen(
                    existing = r.id?.let { id -> tb.firstOrNull { it.id == id } },
                    mediaFile = vm.repo::mediaFile,
                    onBack = ::pop,
                    onSave = { b, done -> vm.saveToolBuild(b, done) },
                    onSaved = { id -> replaceTop(Route.ToolBuildDetail(id)) },
                    onImportMedia = { uri, cb -> vm.importMedia(uri, cb) },
                    onDeleteMedia = { vm.deleteMedia(it) }
                )
                is Route.ToolEdit -> ToolEditScreen(
                    existing = r.id?.let { id -> ts.firstOrNull { it.id == id } },
                    allTools = ts,
                    onBack = ::pop,
                    onSave = { t, done -> vm.saveTool(t, done) },
                    onDelete = { vm.deleteTool(it) }
                )
                Route.Backup -> BackupScreen(
                    ps.size, es.size, BuildConfig.VERSION_NAME,
                    onExport = { vm.exportBackup(it) },
                    onImport = { vm.importBackup(it); goTab(Route.Dashboard) }
                )
                is Route.ProjectDetail -> ProjectDetailScreen(
                    project = ps.firstOrNull { it.id == r.id },
                    allProjects = ps,
                    allExperiences = es,
                    allResources = rs,
                    allKnowledge = kn,
                    checklist = cl.filter { it.projectId == r.id },
                    tools = ts,
                    onBack = ::pop, go = ::push,
                    onSaveProject = { vm.saveProject(it) },
                    onDelete = { vm.deleteProject(it) },
                    onAddItems = { vm.addChecklistItems(r.id, it) },
                    onToggleItem = { item, done -> vm.setChecklistDone(item.id, done) },
                    onDeleteItem = { vm.deleteChecklistItem(it) },
                    onQuickAddTool = { name ->
                        vm.saveTool(Tool(name = name, owned = true, createdAt = 0, updatedAt = 0))
                    }
                )
                is Route.ProjectEdit -> ProjectEditScreen(
                    existing = r.id?.let { id -> ps.firstOrNull { it.id == id } },
                    onBack = ::pop,
                    onSave = { p, done -> vm.saveProject(p, done) },
                    onSaved = { id -> replaceTop(Route.ProjectDetail(id)) }
                )
                is Route.ExperienceDetail -> {
                    val e = es.firstOrNull { it.id == r.id }
                    ExperienceDetailScreen(
                        experience = e,
                        project = e?.projectId?.let { pid -> ps.firstOrNull { it.id == pid } },
                        allExperiences = es,
                        mediaFile = vm.repo::mediaFile,
                        onBack = ::pop, go = ::push,
                        onDelete = { vm.deleteExperience(it) }
                    )
                }
                is Route.ExperienceEdit -> ExperienceEditScreen(
                    existing = r.id?.let { id -> es.firstOrNull { it.id == id } },
                    fromProject = r.fromProjectId?.let { pid -> ps.firstOrNull { it.id == pid } },
                    fromResource = r.fromResourceId?.let { rid -> rs.firstOrNull { it.id == rid } },
                    mediaFile = vm.repo::mediaFile,
                    onBack = ::pop,
                    onSave = { e, done -> vm.saveExperience(e, done) },
                    onSaved = { id -> replaceTop(Route.ExperienceDetail(id)) },
                    onImportMedia = { uri, cb -> vm.importMedia(uri, cb) },
                    onDeleteMedia = { vm.deleteMedia(it) }
                )
            }
        }
    }
}

/** نوار پایین قرص‌شکل و تیره (الهام از نوار «Confirm Split / Cancel»). */
@Composable
private fun BottomBar(current: Route, onSelect: (Route) -> Unit) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(PdrColors.SurfaceDeep, RoundedCornerShape(30.dp))
                .padding(6.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEach { (route, label) ->
                val sel = route == current
                Box(
                    Modifier
                        .weight(1f)
                        .background(if (sel) PdrColors.Surface else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(24.dp))
                        .clickable { onSelect(route) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        color = if (sel) PdrColors.Peach else PdrColors.Muted,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
