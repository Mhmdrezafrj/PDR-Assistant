package com.pdrassistant.app.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import com.pdrassistant.app.ui.screens.MediaStrip
import java.io.File

/**
 * وضعیت یک فهرست تصویر/ویدئو در صفحه ویرایش.
 * - [names]: فایل‌های فعلی. [addedThisSession]: فایل‌هایی که در همین جلسه اضافه شده‌اند.
 * - اگر کاربر بدون ذخیره برگردد، فایل‌های تازه اضافه‌شده پاک می‌شوند ([committed] = false).
 * - بعد از ذخیره، [removedOld] فایل‌های قدیمی حذف‌شده را می‌دهد تا پاک شوند.
 */
class MediaState(private val initial: List<String>) {
    val names = mutableStateListOf<String>().also { it.addAll(initial) }
    val addedThisSession = mutableStateListOf<String>()
    var committed = false

    fun removedOld(): List<String> = initial.filter { it !in names }
    fun asText(): String = names.joinToString("\n")

    companion object {
        fun fromText(text: String?): MediaState =
            MediaState(text.orEmpty().lines().filter { it.isNotBlank() })
    }
}

@Composable
fun rememberMediaState(text: String?): MediaState = remember { MediaState.fromText(text) }

/** انتخاب و نمایش تصویر (و در صورت [allowVideo] ویدئو) با ذخیره در حافظه داخلی برنامه. */
@Composable
fun MediaField(
    label: String,
    addLabel: String,
    state: MediaState,
    mediaFile: (String) -> File,
    onImportMedia: (Uri, (String?) -> Unit) -> Unit,
    onDeleteMedia: (String) -> Unit,
    allowVideo: Boolean
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        uris.forEach { uri ->
            onImportMedia(uri) { name ->
                if (name != null) {
                    state.names.add(name)
                    state.addedThisSession.add(name)
                }
            }
        }
    }

    DisposableEffect(state) {
        onDispose { if (!state.committed) state.addedThisSession.forEach { onDeleteMedia(it) } }
    }

    SectionLabel(label)
    if (state.names.isNotEmpty()) {
        MediaStrip(state.names.toList(), mediaFile, onRemove = { name ->
            state.names.remove(name)
            // فایل تازه‌اضافه‌شده فوراً پاک می‌شود؛ فایل قدیمی بعد از ذخیره پاک می‌شود.
            if (state.addedThisSession.remove(name)) onDeleteMedia(name)
        })
    }
    PillButton(
        addLabel,
        onClick = {
            picker.launch(
                PickVisualMediaRequest(
                    if (allowVideo) ActivityResultContracts.PickVisualMedia.ImageAndVideo
                    else ActivityResultContracts.PickVisualMedia.ImageOnly
                )
            )
        },
        primary = false
    )
}
