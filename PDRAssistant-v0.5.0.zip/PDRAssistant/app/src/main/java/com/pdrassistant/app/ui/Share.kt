package com.pdrassistant.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri

/** متن را با برنامه‌های نصب‌شده (تلگرام، واتس‌اپ، یادداشت و ...) به اشتراک می‌گذارد. */
fun shareText(context: Context, subject: String, text: String) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        // برنامه‌ای برای دریافت متن نصب نیست؛ کاری نمی‌شود کرد.
    }
}

/** لینک را در مرورگر یا برنامه مناسب (یوتیوب، آپارات ...) باز می‌کند. فقط http/https. */
fun openUrl(context: Context, url: String): Boolean {
    val u = url.trim()
    if (!(u.startsWith("http://", ignoreCase = true) || u.startsWith("https://", ignoreCase = true))) return false
    return try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }
}
