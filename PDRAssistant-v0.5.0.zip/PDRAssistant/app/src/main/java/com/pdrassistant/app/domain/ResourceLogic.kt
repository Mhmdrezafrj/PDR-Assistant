package com.pdrassistant.app.domain

import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.LearningResource

/** منطق خالص کتابخانه آموزش‌ها: لینک، جستجو، آموزش‌های مرتبط و تبدیل به تجربه. */
object ResourceLogic {

    private val urlPattern = Regex(
        "^https?://([A-Za-z0-9\\u0080-\\uFFFF-]+\\.)+[A-Za-z0-9\\u0080-\\uFFFF-]{2,}(:\\d+)?(/\\S*)?$"
    )

    /**
     * لینک را مرتب می‌کند: فاصله‌های اطراف حذف و اگر پروتکل ندارد «https://» اضافه می‌شود.
     * متن خالی خالی می‌ماند؛ متنی که فاصله داخلش دارد دست‌نخورده برمی‌گردد (تا نامعتبر شناخته شود).
     */
    fun normalizeUrl(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return ""
        if (t.startsWith("http://", ignoreCase = true) || t.startsWith("https://", ignoreCase = true)) return t
        if (t.any { it.isWhitespace() }) return t
        return "https://$t"
    }

    /** لینک خالی مجاز است (منبع بدون لینک، مثلاً کتاب یا کلاس حضوری)؛ غیرخالی باید معتبر باشد. */
    fun isValidUrl(input: String): Boolean {
        val u = normalizeUrl(input)
        return u.isEmpty() || urlPattern.matches(u)
    }

    fun search(resources: List<LearningResource>, query: String): List<LearningResource> {
        val q = RelatedExperiences.normalize(query)
        if (q.isEmpty()) return resources
        return resources.filter { r ->
            RelatedExperiences.normalize(
                listOf(r.title, r.author, r.url, r.carPart, r.damageType, r.keyPoints, r.notes).joinToString(" ")
            ).contains(q)
        }
    }

    private fun same(a: String?, b: String?): Boolean {
        val na = RelatedExperiences.normalize(a)
        return na.isNotEmpty() && na == RelatedExperiences.normalize(b)
    }

    /**
     * آموزش‌های مرتبط با یک قطعه/آسیب: قطعه یکسان (۳) + آسیب یکسان (۳)؛
     * فقط وقتی حداقل یکی برقرار است، نوع تعمیر یکسان (۲) و امتیاز ۴ یا ۵ (۱) هم حساب می‌شود.
     */
    fun related(
        repairType: String?,
        carPart: String?,
        damageType: String?,
        all: List<LearningResource>,
        limit: Int = 5
    ): List<LearningResource> =
        all.asSequence()
            .map { r ->
                var s = 0
                if (same(carPart, r.carPart)) s += 3
                if (same(damageType, r.damageType)) s += 3
                if (s > 0) {
                    if (!repairType.isNullOrBlank() && repairType == r.repairType) s += 2
                    if (r.rating >= 4) s += 1
                }
                r to s
            }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<LearningResource, Int>> { it.second }
                .thenByDescending { it.first.updatedAt })
            .take(limit)
            .map { it.first }
            .toList()

    /**
     * پیش‌نویس یک تجربه از روی منبع آموزشی (هنوز ذخیره نشده، id = 0).
     * اطمینان: «آزموده شد» ⇒ یک‌بار انجام‌شده؛ در غیر این صورت «شنیده/دیده‌شده».
     */
    fun toExperienceDraft(r: LearningResource): Experience {
        val source = buildString {
            append(ResourceKind.fromKey(r.kind).label).append(": ").append(r.title.trim())
            if (r.author.isNotBlank()) append(" — ").append(r.author.trim())
            if (r.url.isNotBlank()) append('\n').append(normalizeUrl(r.url))
        }
        return Experience(
            title = r.title.trim(),
            repairType = r.repairType,
            carPart = r.carPart,
            damageType = r.damageType,
            steps = r.keyPoints.trim(),
            source = source,
            confidence = if (ResourceStatus.fromKey(r.status) == ResourceStatus.TRIED)
                Confidence.ONCE.key else Confidence.HEARD.key,
            masterNotes = r.notes.trim(),
            createdAt = 0,
            updatedAt = 0
        )
    }
}
