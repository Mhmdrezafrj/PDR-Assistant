package com.pdrassistant.app.domain

import com.pdrassistant.app.data.KnowledgeEntry

/** منطق خالص دانشنامه: جستجو، فیلتر، گروه‌بندی و مطالب مرتبط با پروژه. */
object KnowledgeLogic {

    val defaultCategories = listOf(
        "رفتار فلز", "ورق و آلیاژ", "ابزار و تکنیک", "رنگ و پرداخت", "ایمنی", "اصطلاحات"
    )

    fun search(entries: List<KnowledgeEntry>, query: String): List<KnowledgeEntry> {
        val q = RelatedExperiences.normalize(query)
        if (q.isEmpty()) return entries
        return entries.filter { k ->
            RelatedExperiences.normalize(
                listOf(k.title, k.category, k.body, k.source, k.carPart, k.damageType).joinToString(" ")
            ).contains(q)
        }
    }

    /** kind یا category خالی/null یعنی «همه». */
    fun filter(entries: List<KnowledgeEntry>, kind: String?, category: String?): List<KnowledgeEntry> {
        val cat = RelatedExperiences.normalize(category)
        return entries.filter { k ->
            (kind.isNullOrBlank() || k.kind == kind) &&
                (cat.isEmpty() || RelatedExperiences.normalize(k.category) == cat)
        }
    }

    /** دسته‌های موجود (بدون تکرار، بر اساس متن مرتب‌شده)؛ دسته‌ی خالی نادیده گرفته می‌شود. */
    fun categoriesIn(entries: List<KnowledgeEntry>): List<String> {
        val seen = LinkedHashMap<String, String>()
        entries.forEach { k ->
            val n = RelatedExperiences.normalize(k.category)
            if (n.isNotEmpty() && n !in seen) seen[n] = k.category.trim()
        }
        return seen.values.sorted()
    }

    /** پیشنهاد دسته در فرم: دسته‌های پیش‌فرض + دسته‌هایی که خود کاربر ساخته، بدون تکرار. */
    fun categorySuggestions(entries: List<KnowledgeEntry>): List<String> {
        val seen = LinkedHashSet<String>()
        val out = ArrayList<String>()
        (defaultCategories + categoriesIn(entries)).forEach {
            if (seen.add(RelatedExperiences.normalize(it))) out.add(it)
        }
        return out
    }

    /** گروه‌بندی بر اساس دسته؛ مطالب بدون دسته در گروه «بدون دسته» و همیشه آخر می‌آیند. */
    fun groupByCategory(entries: List<KnowledgeEntry>, uncategorized: String = "بدون دسته"): List<Pair<String, List<KnowledgeEntry>>> {
        val groups = LinkedHashMap<String, MutableList<KnowledgeEntry>>()
        val labels = HashMap<String, String>()
        val none = ArrayList<KnowledgeEntry>()
        entries.forEach { k ->
            val n = RelatedExperiences.normalize(k.category)
            if (n.isEmpty()) none.add(k)
            else {
                labels.putIfAbsent(n, k.category.trim())
                groups.getOrPut(n) { ArrayList() }.add(k)
            }
        }
        val result = groups.entries.sortedBy { labels[it.key] }.map { labels[it.key]!! to it.value.toList() }
        return if (none.isEmpty()) result else result + (uncategorized to none.toList())
    }

    private fun same(a: String?, b: String?): Boolean {
        val na = RelatedExperiences.normalize(a)
        return na.isNotEmpty() && na == RelatedExperiences.normalize(b)
    }

    /**
     * دانش مرتبط با پروژه: قطعه یکسان (۳) + آسیب یکسان (۳). اصل فنی کمی جلوتر می‌آید (۱) چون قابل‌اتکاتر است
     * (فقط وقتی حداقل یکی از دو شرط برقرار است). مطلب بدون قطعه و آسیب هرگز مرتبط حساب نمی‌شود.
     */
    fun related(carPart: String?, damageType: String?, all: List<KnowledgeEntry>, limit: Int = 5): List<KnowledgeEntry> =
        all.asSequence()
            .map { k ->
                var s = 0
                if (same(carPart, k.carPart)) s += 3
                if (same(damageType, k.damageType)) s += 3
                if (s > 0 && k.kind == KnowledgeKind.FACT.key) s += 1
                k to s
            }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<KnowledgeEntry, Int>> { it.second }
                .thenByDescending { it.first.updatedAt })
            .take(limit)
            .map { it.first }
            .toList()

    /** شمارش هر نوع برای خلاصه‌ی بالای فهرست. */
    fun countByKind(entries: List<KnowledgeEntry>): Map<KnowledgeKind, Int> =
        KnowledgeKind.entries.associateWith { kind -> entries.count { it.kind == kind.key } }
}
