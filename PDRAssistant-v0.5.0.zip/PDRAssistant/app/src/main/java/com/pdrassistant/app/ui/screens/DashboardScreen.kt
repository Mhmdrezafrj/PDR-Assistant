package com.pdrassistant.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Project
import com.pdrassistant.app.domain.ProjectStatus
import com.pdrassistant.app.domain.RepairType
import com.pdrassistant.app.ui.Route
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.PeachCard
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.repairColor
import com.pdrassistant.app.ui.theme.PdrColors

@Composable
fun DashboardScreen(
    projects: List<Project>,
    experiences: List<Experience>,
    go: (Route) -> Unit
) {
    val active = projects.filter { it.status != ProjectStatus.DONE.key }
    val lastDone = projects.firstOrNull { it.status == ProjectStatus.DONE.key }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ScreenTitle(title = "دستیار PDR", subtitle = "سلام استادکار")
        }

        // کارت اصلی هلویی + ستون سفید قرص‌شکل (الهام از «Total Bill / Split with»)
        item {
            PeachCard(onClick = { go(Route.Projects) }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("پروژه‌های فعال", color = PdrColors.PeachDark, fontSize = 14.sp)
                        Text(
                            active.size.toString(),
                            color = PdrColors.PeachDark,
                            fontSize = 40.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(Modifier.height(10.dp))
                        PillButton("پروژه جدید", onClick = { go(Route.ProjectEdit(null)) }, primary = false)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(
                        Modifier
                            .background(androidx.compose.ui.graphics.Color.White, RoundedCornerShape(26.dp))
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RepairType.entries.forEach { t ->
                            val n = projects.count { it.repairType == t.key }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Dot(repairColor(t.key), 16)
                                Spacer(Modifier.width(6.dp))
                                Text(n.toString(), color = PdrColors.PeachDark, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // آخرین کار انجام‌شده (الهام از «Your previous split»)
        item {
            DarkCard(onClick = lastDone?.let { { go(Route.ProjectDetail(it.id)) } }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).background(PdrColors.SurfaceDeep, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text("✓", color = PdrColors.Peach, fontSize = 20.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("آخرین کار انجام‌شده", color = PdrColors.Muted, fontSize = 13.sp)
                        Text(
                            lastDone?.title ?: "هنوز کاری به پایان نرسیده",
                            color = PdrColors.Cream,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // تجربیات اخیر (الهام از «Nearby Friends»)
        item {
            DarkCard {
                Column {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("تجربیات اخیر", color = PdrColors.Cream, fontWeight = FontWeight.Bold)
                        Text(
                            "همه",
                            color = PdrColors.Peach,
                            modifier = Modifier.clickable { go(Route.Experiences) }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    if (experiences.isEmpty()) {
                        Text(
                            "هنوز تجربه‌ای ثبت نشده. اولین تکنیک را ثبت کنید تا دستیار شروع به یادگیری کند.",
                            color = PdrColors.Muted,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        PillButton("ثبت تجربه", onClick = { go(Route.ExperienceEdit(null)) })
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(experiences.take(8), key = { it.id }) { e ->
                                ExperiencePill(e) { go(Route.ExperienceDetail(e.id)) }
                            }
                        }
                    }
                }
            }
        }

        // پروژه‌های اخیر (الهام از «Recently Split»)
        item {
            SectionLabel("پروژه‌های اخیر")
            if (projects.isEmpty()) {
                Text("پروژه‌ای ثبت نشده است.", color = PdrColors.Muted, fontSize = 14.sp)
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    items(projects.take(8), key = { it.id }) { p ->
                        Column(
                            Modifier.width(72.dp).clickable { go(Route.ProjectDetail(p.id)) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(56.dp).background(repairColor(p.repairType), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    p.title.take(1),
                                    color = PdrColors.PeachDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                p.title,
                                color = PdrColors.Cream,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun ExperiencePill(e: Experience, onClick: () -> Unit) {
    Column(
        Modifier
            .width(92.dp)
            .background(PdrColors.SurfaceDeep, RoundedCornerShape(40.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(44.dp).background(repairColor(e.repairType), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(e.title.take(1), color = PdrColors.PeachDark, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(6.dp))
        Text(e.title, color = PdrColors.Cream, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(6.dp))
        Box(Modifier.size(10.dp).background(PdrColors.Peach, CircleShape))
    }
}
