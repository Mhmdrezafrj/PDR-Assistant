package com.pdrassistant.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.ChecklistItem
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.KnowledgeEntry
import com.pdrassistant.app.data.LearningResource
import com.pdrassistant.app.data.Project
import com.pdrassistant.app.domain.KnowledgeLogic
import com.pdrassistant.app.domain.ResourceLogic
import com.pdrassistant.app.data.Tool
import androidx.compose.ui.platform.LocalContext
import com.pdrassistant.app.domain.ChecklistLogic
import com.pdrassistant.app.domain.Outcome
import com.pdrassistant.app.domain.PastLessons
import com.pdrassistant.app.domain.ProjectReport
import com.pdrassistant.app.ui.shareText
import com.pdrassistant.app.domain.ProjectStatus
import com.pdrassistant.app.domain.RelatedExperiences
import com.pdrassistant.app.domain.RepairType
import com.pdrassistant.app.domain.Suggestions
import com.pdrassistant.app.ui.Route
import com.pdrassistant.app.ui.components.ChoiceRow
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.DetailBlock
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.EmptyState
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PeachCard
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.components.SuggestionRow
import com.pdrassistant.app.ui.components.Tag
import com.pdrassistant.app.ui.formatDate
import com.pdrassistant.app.ui.repairColor
import com.pdrassistant.app.ui.theme.PdrColors

// ============================ فهرست ============================

@Composable
fun ProjectsScreen(projects: List<Project>, go: (Route) -> Unit) {
    var filter by remember { mutableStateOf<RepairType?>(null) }
    val shown = if (filter == null) projects else projects.filter { it.repairType == filter!!.key }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle("پروژه‌ها", "${projects.size} مورد", Modifier.weight(1f))
                PillButton("جدید", onClick = { go(Route.ProjectEdit(null)) })
            }
        }
        item {
            ChoiceRow(
                options = listOf<RepairType?>(null) + RepairType.entries,
                selected = filter,
                label = { it?.label ?: "همه" },
                onSelect = { filter = it }
            )
        }
        if (shown.isEmpty()) {
            item {
                EmptyState(
                    if (projects.isEmpty()) "هنوز پروژه‌ای ثبت نشده" else "پروژه‌ای با این فیلتر نیست",
                    "با دکمه «جدید» اولین پروژه را بسازید."
                )
            }
        }
        items(shown, key = { it.id }) { p -> ProjectRow(p) { go(Route.ProjectDetail(p.id)) } }
    }
}

@Composable
private fun ProjectRow(p: Project, onClick: () -> Unit) {
    DarkCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Dot(repairColor(p.repairType), 18)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    p.title, color = PdrColors.Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                val sub = listOf(p.vehicle, p.carPart, p.damageType).filter { it.isNotBlank() }.joinToString(" · ")
                if (sub.isNotBlank()) {
                    Text(sub, color = PdrColors.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Tag(ProjectStatus.fromKey(p.status).label, color = PdrColors.Peach)
        }
    }
}

// ============================ جزئیات ============================

@Composable
fun ProjectDetailScreen(
    project: Project?,
    allProjects: List<Project>,
    allExperiences: List<Experience>,
    allResources: List<LearningResource>,
    allKnowledge: List<KnowledgeEntry>,
    checklist: List<ChecklistItem>,
    tools: List<Tool>,
    onBack: () -> Unit,
    go: (Route) -> Unit,
    onSaveProject: (Project) -> Unit,
    onDelete: (Project) -> Unit,
    onAddItems: (List<String>) -> Unit,
    onToggleItem: (ChecklistItem, Boolean) -> Unit,
    onDeleteItem: (ChecklistItem) -> Unit,
    onQuickAddTool: (String) -> Unit
) {
    if (project == null) {
        SubScreen("پروژه", onBack) { EmptyState("پروژه پیدا نشد", "ممکن است حذف شده باشد.") }
        return
    }
    var confirmDelete by remember { mutableStateOf(false) }
    val context = LocalContext.current
    // فرم ارزیابی: فقط با عوض شدن پروژه از نو پر می‌شود تا با لمس «وضعیت» متن ننوشته‌شده پاک نشود.
    var outcome by remember(project.id) { mutableStateOf(Outcome.fromKey(project.outcome)) }
    var timeText by remember(project.id) {
        mutableStateOf(if (project.timeSpentMinutes > 0) project.timeSpentMinutes.toString() else "")
    }
    var mistakesText by remember(project.id) { mutableStateOf(project.mistakes) }
    var lessonsText by remember(project.id) { mutableStateOf(project.lessons) }
    var resultText by remember(project.id) { mutableStateOf(project.resultNotes) }
    val minutes = ProjectReport.parseMinutes(timeText)
    val pastLessons = PastLessons.find(project, allProjects)

    val linked = allExperiences.filter { it.projectId == project.id }
    val related = RelatedExperiences.rank(
        project.repairType, project.carPart, project.damageType, allExperiences
    ).filter { r -> linked.none { it.id == r.experience.id } }
    // منبع مراحل و ابزارهای پیشنهادی: تجربه‌های همین پروژه + مشابه‌ها
    val candidates = (linked + related.map { it.experience }).distinctBy { it.id }

    SubScreen(project.title, onBack) {
        PeachCard {
            Column {
                Text(RepairType.labelOf(project.repairType), color = PdrColors.PeachDark, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(project.title, color = PdrColors.PeachDark, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text("ثبت: ${formatDate(project.createdAt)}", color = PdrColors.PeachDark, fontSize = 13.sp)
            }
        }

        SectionLabel("وضعیت")
        ChoiceRow(
            ProjectStatus.entries, ProjectStatus.fromKey(project.status), { it.label },
            { onSaveProject(project.copy(status = it.key)) }
        )

        DarkCard {
            Column {
                DetailBlock("خودرو", project.vehicle)
                DetailBlock("پلاک / شناسه", project.plate)
                DetailBlock("قطعه", project.carPart)
                DetailBlock("نوع آسیب", project.damageType)
                DetailBlock("یادداشت", project.notes)
                if (listOf(project.vehicle, project.plate, project.carPart, project.damageType, project.notes)
                        .all { it.isBlank() }
                ) Text("جزئیاتی وارد نشده.", color = PdrColors.Muted)
            }
        }

        ChecklistSection(checklist, candidates, onAddItems, onToggleItem, onDeleteItem)
        SuggestedToolsSection(ChecklistLogic.suggestedTools(candidates, tools), onQuickAddTool)

        // هشدار از حافظه: پروژه‌های قبلی مشابه که ناموفق بوده‌اند یا اشتباه/درس ثبت شده دارند
        if (pastLessons.isNotEmpty()) {
            SectionLabel("یادآوری از کارهای قبلی مشابه")
            pastLessons.forEach { l ->
                val pr = l.project
                DarkCard(onClick = { go(Route.ProjectDetail(pr.id)) }) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(pr.title, color = PdrColors.Cream, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Tag(
                                Outcome.labelOf(pr.outcome),
                                color = if (pr.outcome == Outcome.FAILED.key) PdrColors.Danger else PdrColors.Peach,
                                selected = pr.outcome.isNotEmpty()
                            )
                        }
                        if (pr.mistakes.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text("اشتباه: ${pr.mistakes}", color = PdrColors.Cream, fontSize = 14.sp)
                        }
                        if (pr.lessons.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text("درس: ${pr.lessons}", color = PdrColors.Peach, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        SectionLabel("ارزیابی نتیجه")
        ChoiceRow(
            listOf<Outcome?>(null) + Outcome.entries, outcome,
            { it?.label ?: "ارزیابی نشده" }, { outcome = it }
        )
        PdrField(timeText, { timeText = it }, "زمان صرف‌شده (دقیقه)")
        if (minutes == null) {
            Text("فقط عدد وارد کنید (مثلاً 90).", color = PdrColors.Danger, fontSize = 13.sp)
        } else if (minutes > 0) {
            Text(ProjectReport.formatDuration(minutes), color = PdrColors.Muted, fontSize = 13.sp)
        }
        PdrField(mistakesText, { mistakesText = it }, "اشتباهات و مشکلات این کار", minLines = 2)
        PdrField(lessonsText, { lessonsText = it }, "درسی که یاد گرفتم (دفعه بعد چه کنم)", minLines = 2)
        PdrField(resultText, { resultText = it }, "توضیح نتیجه", minLines = 3)
        PillButton(
            "ذخیره ارزیابی",
            onClick = {
                if (minutes != null) {
                    onSaveProject(
                        project.copy(
                            outcome = outcome?.key.orEmpty(), timeSpentMinutes = minutes,
                            mistakes = mistakesText.trim(), lessons = lessonsText.trim(),
                            resultNotes = resultText.trim()
                        )
                    )
                }
            },
            primary = false
        )

        SectionLabel("تجربه‌های ثبت‌شده از این پروژه (${linked.size})")
        if (linked.isEmpty()) Text("هنوز تجربه‌ای از این پروژه ثبت نشده.", color = PdrColors.Muted, fontSize = 14.sp)
        linked.forEach { ExperienceRow(it) { go(Route.ExperienceDetail(it.id)) } }
        PillButton("ثبت تجربه از این پروژه", onClick = { go(Route.ExperienceEdit(null, project.id)) })

        SectionLabel("تجربه‌های مرتبط از حافظه")
        if (related.isEmpty()) {
            Text(
                "تجربه‌ای با قطعه/آسیب مشابه پیدا نشد. هرچه تجربه بیشتری ثبت کنید، پیشنهادها دقیق‌تر می‌شود.",
                color = PdrColors.Muted, fontSize = 14.sp
            )
        }
        related.forEach { r -> ExperienceRow(r.experience) { go(Route.ExperienceDetail(r.experience.id)) } }

        val relatedResources = ResourceLogic.related(project.repairType, project.carPart, project.damageType, allResources)
        if (relatedResources.isNotEmpty()) {
            SectionLabel("آموزش‌های مرتبط از کتابخانه")
            relatedResources.forEach { r -> ResourceRow(r) { go(Route.ResourceDetail(r.id)) } }
        }

        val relatedKnowledge = KnowledgeLogic.related(project.carPart, project.damageType, allKnowledge)
        if (relatedKnowledge.isNotEmpty()) {
            SectionLabel("دانش مرتبط از دانشنامه")
            relatedKnowledge.forEach { k -> KnowledgeRow(k) { go(Route.KnowledgeDetail(k.id)) } }
        }

        Spacer(Modifier.height(8.dp))
        PillButton(
            "ارسال گزارش کار",
            onClick = {
                val text = ProjectReport.build(project, checklist, linked, formatDate(System.currentTimeMillis()))
                shareText(context, "گزارش کار — ${project.title}", text)
            },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("ویرایش", onClick = { go(Route.ProjectEdit(project.id)) }, primary = false)
            PillButton("حذف", onClick = { confirmDelete = true }, primary = false)
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            "حذف پروژه؟",
            "پروژه «${project.title}» حذف می‌شود. تجربه‌های ثبت‌شده از آن باقی می‌مانند.",
            "حذف",
            onConfirm = { confirmDelete = false; onDelete(project); onBack() },
            onDismiss = { confirmDelete = false }
        )
    }
}

// ============================ ایجاد/ویرایش ============================

@Composable
fun ProjectEditScreen(
    existing: Project?,
    onBack: () -> Unit,
    onSave: (Project, (Long) -> Unit) -> Unit,
    onSaved: (Long) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var vehicle by remember { mutableStateOf(existing?.vehicle.orEmpty()) }
    var plate by remember { mutableStateOf(existing?.plate.orEmpty()) }
    var carPart by remember { mutableStateOf(existing?.carPart.orEmpty()) }
    var damage by remember { mutableStateOf(existing?.damageType.orEmpty()) }
    var repair by remember { mutableStateOf(RepairType.fromKey(existing?.repairType) ?: RepairType.PDR) }
    var status by remember { mutableStateOf(ProjectStatus.fromKey(existing?.status)) }
    var notes by remember { mutableStateOf(existing?.notes.orEmpty()) }
    var saving by remember { mutableStateOf(false) }

    SubScreen(if (existing == null) "پروژه جدید" else "ویرایش پروژه", onBack) {
        PdrField(title, { title = it }, "عنوان پروژه (الزامی)")
        PdrField(vehicle, { vehicle = it }, "خودرو (مثلاً پژو ۲۰۶ سفید)")
        PdrField(plate, { plate = it }, "پلاک / شناسه (اختیاری)")

        SectionLabel("نوع تعمیر")
        ChoiceRow(RepairType.entries, repair, { it.label }, { repair = it })

        PdrField(carPart, { carPart = it }, "قطعه")
        SuggestionRow(Suggestions.carParts) { carPart = it }
        PdrField(damage, { damage = it }, "نوع آسیب")
        SuggestionRow(Suggestions.damageTypes) { damage = it }

        SectionLabel("وضعیت")
        ChoiceRow(ProjectStatus.entries, status, { it.label }, { status = it })

        PdrField(notes, { notes = it }, "یادداشت", minLines = 3)

        PillButton(
            if (saving) "در حال ذخیره..." else "ذخیره",
            onClick = {
                if (title.isNotBlank() && !saving) {
                    saving = true
                    val base = existing ?: Project(title = "", createdAt = 0, updatedAt = 0)
                    onSave(
                        base.copy(
                            title = title.trim(), vehicle = vehicle.trim(), plate = plate.trim(),
                            carPart = carPart.trim(), damageType = damage.trim(),
                            repairType = repair.key, status = status.key, notes = notes.trim()
                        ),
                        onSaved
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
        if (title.isBlank()) Text("برای ذخیره، عنوان را وارد کنید.", color = PdrColors.Muted, fontSize = 13.sp)
    }
}
