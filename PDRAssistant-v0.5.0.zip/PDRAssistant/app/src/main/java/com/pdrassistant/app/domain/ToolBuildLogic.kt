package com.pdrassistant.app.domain

import com.pdrassistant.app.data.ToolBuild
import com.pdrassistant.app.data.ToolMaterial

/** منطق خالص بخش «ساخت ابزار»: پیشرفت تهیه مواد، فهرست خرید و گزارش متنی. */
object ToolBuildLogic {

    /** (تهیه‌شده، کل) */
    fun progress(materials: List<ToolMaterial>): Pair<Int, Int> =
        materials.count { it.acquired } to materials.size

    /** همه مواد تهیه شده و لااقل یک ماده ثبت شده است. */
    fun allAcquired(materials: List<ToolMaterial>): Boolean =
        materials.isNotEmpty() && materials.all { it.acquired }

    private fun materialLine(m: ToolMaterial): String =
        if (m.quantity.isBlank()) m.name.trim() else "${m.name.trim()} — ${m.quantity.trim()}"

    /** فهرست خرید: فقط موادی که هنوز تهیه نشده‌اند. */
    fun shoppingList(build: ToolBuild, materials: List<ToolMaterial>): String {
        val missing = materials.filter { !it.acquired }
        val sb = StringBuilder("فهرست خرید برای ساخت «${build.name}»\n\n")
        if (materials.isEmpty()) return sb.append("هنوز ماده‌ای ثبت نشده است.\n").toString()
        if (missing.isEmpty()) return sb.append("همه‌ی مواد تهیه شده است.\n").toString()
        missing.forEach { sb.append("[ ] ").append(materialLine(it)).append('\n') }
        return sb.toString()
    }

    fun report(build: ToolBuild, materials: List<ToolMaterial>): String {
        val sb = StringBuilder("ساخت ابزار — ${build.name}\n")
        sb.append("وضعیت: ").append(BuildStatus.fromKey(build.status).label).append("\n\n")
        fun block(title: String, text: String) {
            if (text.isNotBlank()) sb.append(title).append(":\n").append(text.trim()).append("\n\n")
        }
        block("کاربرد", build.purpose)
        block("طرح و ابعاد", build.design)
        if (materials.isNotEmpty()) {
            val (done, total) = progress(materials)
            sb.append("مواد اولیه (").append(done).append(" از ").append(total).append(" تهیه شده):\n")
            materials.forEach { sb.append(if (it.acquired) "[✓] " else "[ ] ").append(materialLine(it)).append('\n') }
            sb.append('\n')
        }
        block("مراحل ساخت", build.steps)
        block("نتیجه و اصلاحات", build.result)
        return sb.toString().trimEnd() + "\n"
    }
}
