package com.pdrassistant.app.domain

import com.pdrassistant.app.data.Project

/**
 * «حافظه اشتباهات»: پروژه‌های قبلی با قطعه یا آسیب مشابه که نتیجه‌شان کامل موفق نبوده
 * یا اشتباه/درسی برایشان ثبت شده است. کاملاً آفلاین و بدون هوش مصنوعی.
 */
object PastLessons {

    data class Lesson(val project: Project, val score: Int)

    /** آیا این پروژه چیزی برای یادآوری دارد؟ */
    fun hasLesson(p: Project): Boolean =
        p.mistakes.isNotBlank() || p.lessons.isNotBlank() ||
            p.outcome == Outcome.PARTIAL.key || p.outcome == Outcome.FAILED.key

    private fun severity(p: Project): Int = when (p.outcome) {
        Outcome.FAILED.key -> 2
        Outcome.PARTIAL.key -> 1
        else -> 0
    }

    private fun same(a: String, b: String): Boolean {
        val na = RelatedExperiences.normalize(a)
        return na.isNotEmpty() && na == RelatedExperiences.normalize(b)
    }

    /**
     * امتیاز: قطعه یکسان (۱) + آسیب یکسان (۱) + نوع تعمیر یکسان (۱، فقط اگر حداقل یکی از دو مورد قبل برقرار باشد).
     * مرتب‌سازی: امتیاز، سپس شدت نتیجه (ناموفق اول)، سپس جدیدتر.
     */
    fun find(current: Project, all: List<Project>, limit: Int = 5): List<Lesson> =
        all.asSequence()
            .filter { it.id != current.id && hasLesson(it) }
            .map { p ->
                var s = 0
                if (same(current.carPart, p.carPart)) s++
                if (same(current.damageType, p.damageType)) s++
                if (s > 0 && current.repairType == p.repairType) s++
                Lesson(p, s)
            }
            .filter { it.score > 0 }
            .sortedWith(
                compareByDescending<Lesson> { it.score }
                    .thenByDescending { severity(it.project) }
                    .thenByDescending { it.project.updatedAt }
            )
            .take(limit)
            .toList()
}
