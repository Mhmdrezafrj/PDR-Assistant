# Release minification is disabled in 0.1.0, so no custom rules are needed yet.
