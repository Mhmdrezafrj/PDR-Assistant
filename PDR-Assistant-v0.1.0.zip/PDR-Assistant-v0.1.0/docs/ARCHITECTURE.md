# Architecture — PDR Assistant

## Architectural decisions

1. **Flutter Android client:** one codebase, Persian-first UI.
2. **Offline-first:** the local database is the primary working copy. Core workflows must not require network access.
3. **Local persistence:** SQLite managed through Drift. Schema migrations are mandatory once persistent tables are introduced.
4. **AI through a gateway:** the app talks to a backend owned/controlled by the project. Provider credentials never ship in the APK.
5. **Sync is separate from domain logic:** local writes are committed first; a durable outbox records operations for later synchronization.
6. **Media is stored as files:** database rows store metadata and local relative paths, not large image/video blobs.

## Proposed module boundaries

- `core/`: configuration, errors, networking, storage primitives.
- `features/projects/`: repair jobs and vehicle/part details.
- `features/checklists/`: templates and per-job steps.
- `features/tools/`: personal tool inventory.
- `features/knowledge/`: techniques, sources and personal observations.
- `features/assistant/`: prompts, retrieval, gateway client and AI responses.
- `features/sync/`: outbox, conflict handling and backup coordination.

## Data flow

User action → domain validation → local transaction → UI update → outbox entry → optional sync worker.

AI request → local context selection → gateway request over HTTPS → validated response → source/confidence display. If offline, show relevant local knowledge and clearly state that online reasoning is unavailable.

## Security baseline

- No model-provider API key in Flutter assets, source, build args embedded in the app, or remote config readable by all users.
- TLS for network traffic.
- Authentication and rate limits belong on the gateway.
- Keep user data private by default; cloud backup must be opt-in and documented.
- Backups should be encrypted before upload where feasible.

## Decisions intentionally deferred

- Gateway hosting provider and model provider.
- Cloud database/object storage vendor.
- Account/login method.
- End-to-end encryption and key recovery design.
- Local small language model feasibility and supported device baseline.
