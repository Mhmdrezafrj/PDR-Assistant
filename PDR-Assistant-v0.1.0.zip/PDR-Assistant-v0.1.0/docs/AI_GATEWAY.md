# AI Gateway — initial contract

The mobile app must call a project-controlled gateway. The gateway will authenticate the user, apply rate limits, select the model, and keep provider secrets server-side.

## Proposed endpoints

- `GET /health` — service health, no secrets.
- `POST /v1/assistant/respond` — assistant request.

## Proposed request shape

```json
{
  "conversation_id": "uuid",
  "message": "شرح مسئله فنی",
  "context": {
    "vehicle": {"make": "...", "model": "...", "year": 0},
    "panel": "...",
    "damage": "...",
    "available_tools": [],
    "relevant_experiences": []
  },
  "locale": "fa-IR"
}
```

## Proposed response shape

```json
{
  "answer": "پاسخ فارسی",
  "hypotheses": [],
  "recommended_checks": [],
  "options": [],
  "risks": [],
  "missing_information": [],
  "confidence": "low|medium|high",
  "sources": []
}
```

These are design contracts, not a live API. The backend, authentication scheme, request validation, model selection, observability and privacy policy must be implemented before enabling online AI.

## Required assistant behavior

- Separate verified mechanics/materials knowledge from trade practice and user-specific experience.
- State uncertainty and ask for missing inspection details.
- Never claim that a photo proves hidden damage, metal stretch, alloy or thickness.
- Explain why a tool or method is recommended and list risks/alternatives.
- Prefer reversible inspection steps before forceful repair actions.
