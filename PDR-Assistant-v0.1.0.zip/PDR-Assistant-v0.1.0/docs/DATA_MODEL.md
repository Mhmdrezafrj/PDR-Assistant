# Proposed local data model

This is the logical model for Phase 2. It is not yet a migrated or production database schema.

## Entities

### RepairProject
- id (UUID)
- vehicle_make, vehicle_model, model_year
- panel_name
- repair_type (PDR, painted_bodywork, mixed)
- damage_description
- created_at, updated_at
- status

### DamageAssessment
- id, project_id
- damage_type, approximate_size, location_on_panel
- paint_condition, access_condition
- geometry_notes, uncertainty_notes
- photo_ids

### Tool
- id, name, category
- use_cases, limitations, safety_notes
- owned_quantity, condition, personal_notes

### Technique
- id, title, category
- prerequisites, steps, suitable_conditions
- contraindications, risks
- source_type (verified_reference, trade_practice, personal_experience)
- source_reference, confidence_level

### ExperienceRecord
- id, project_id (nullable), technique_id (nullable)
- problem, hypothesis, tools_used, steps_taken
- outcome, mistakes, lesson_learned
- created_at, media_ids

### ChecklistTemplate / ChecklistRun / ChecklistItem
Reusable workflow templates and project-specific completion state. Each item may include rationale, required tools and a verification criterion.

### MediaAsset
- id, local_relative_path, media_type
- captured_at, caption, related_entity_type, related_entity_id

### SyncOutbox
- id, entity_type, entity_id, operation
- payload_version, created_at, retry_count, last_error

## Data quality rules

- Distinguish measured facts from estimates and assumptions.
- Record source and confidence for technical claims.
- Do not infer steel grade, panel thickness, adhesive suitability or repairability from a photo alone.
- Preserve original experience records; corrections should be versioned or appended.
