# Delivery roadmap

- Phase 0 — architecture, repository scaffold, CI workflow and baseline UI.
- Phase 1 — app navigation, design system, settings and local app shell.
- Phase 2 — Drift database, projects, tools and experience memory.
- Phase 3 — repair workflow templates and adaptive checklists.
- Phase 4 — structured technical knowledge for sheet metal, panels and PDR.
- Phase 5 — secure AI gateway, retrieval and image-assisted diagnosis.
- Phase 6 — sync queue, cloud backup, restore and conflict policy.
- Phase 7 — device testing, security review, release signing and stable APK.

A phase is complete only after code review, automated checks, a user-visible test and documented limitations.
