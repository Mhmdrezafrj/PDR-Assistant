# PDR Assistant

دستیار فارسی و آفلاین‌محور برای صافکاری سنتی و PDR.

## وضعیت فعلی

نسخه `0.1.0` زیرساخت اولیه پروژه است. داشبورد فارسی و ساختار اولیه کد آماده شده‌اند؛ قابلیت‌های تعمیراتی، دیتابیس عملیاتی و اتصال هوش مصنوعی هنوز پیاده‌سازی نشده‌اند.

## فناوری‌ها

- Flutter / Dart
- Material 3 و رابط فارسی RTL
- SQLite + Drift (برای لایه داده در مراحل بعد)
- REST AI Gateway (قرارداد اولیه)
- GitHub Actions برای تحلیل، تست و ساخت APK

## اجرای محلی با Flutter

نیازمند Flutter stable و Android SDK سازگار هستید.

```bash
flutter create --platforms=android --org com.pdrassistant --project-name pdr_assistant .
flutter pub get
flutter analyze
flutter test
flutter run
```

## ساخت APK

```bash
flutter build apk --release
```

خروجی معمولاً در مسیر زیر ساخته می‌شود:

`build/app/outputs/flutter-apk/app-release.apk`

## ساخت APK با GitHub

1. فایل‌های این پروژه را در ریشه یک repository در GitHub بارگذاری کنید.
2. شاخه اصلی را `main` یا `master` قرار دهید.
3. وارد زبانه Actions شوید.
4. Workflow با نام **Android APK Build** را اجرا کنید یا یک commit به شاخه اصلی بفرستید.
5. پس از موفقیت، از بخش Artifacts فایل APK را دریافت کنید.

## تنظیم Gateway

آدرس Gateway در زمان build از طریق `--dart-define` قابل تنظیم است:

```bash
flutter build apk --release --dart-define=AI_GATEWAY_URL=https://api.example.com
```

این مقدار فقط آدرس عمومی سرویس است. کلید خصوصی مدل باید فقط روی سرور Gateway نگهداری شود.

## مستندات

- `docs/ARCHITECTURE.md`: معماری کلان
- `docs/DATA_MODEL.md`: مدل داده پیشنهادی
- `docs/AI_GATEWAY.md`: قرارداد اولیه اتصال هوش مصنوعی
- `docs/PHASES.md`: نقشه راه

## امنیت و داده

در این نسخه هیچ حساب کاربری، سرویس ابری یا Gateway واقعی متصل نیست. اطلاعات واقعی تعمیرات را تا زمان تکمیل و تست پشتیبان‌گیری در یک محل امن دیگر نیز نگهداری کنید.
