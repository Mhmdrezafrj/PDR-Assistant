# Changelog

## 0.1.0+1 — Phase 0
- Created Flutter project scaffold and Persian RTL dashboard.
- Added architecture, data model and AI gateway design documents.
- Added GitHub Actions workflow for analyze, test and release APK artifact.
- No production database, cloud sync or live AI gateway is connected yet.
