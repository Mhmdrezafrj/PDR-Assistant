import 'package:flutter_test/flutter_test.dart';
import 'package:pdr_assistant/app/app.dart';

void main() {
  testWidgets('dashboard shows the Persian app title and core sections', (
    tester,
  ) async {
    await tester.pumpWidget(const PdrAssistantApp());

    expect(find.text('دستیار صافکاری'), findsOneWidget);
    expect(find.text('پروژه‌های تعمیراتی'), findsOneWidget);
    expect(find.text('حافظه تجربیات'), findsOneWidget);
  });
}
