/// Contract placeholder for the future secure AI Gateway integration.
/// The Android app must call our own backend, never a model provider directly
/// with a private API key embedded in the APK.
class GatewayContract {
  GatewayContract._();

  static const String assistantEndpoint = '/v1/assistant/respond';
  static const String healthEndpoint = '/health';
}
