/// Runtime configuration supplied at build time.
/// Never place private API keys in this file or in the Android application.
class AppConfig {
  AppConfig._();

  static const String aiGatewayUrl = String.fromEnvironment(
    'AI_GATEWAY_URL',
    defaultValue: '',
  );

  static bool get hasAiGateway => aiGatewayUrl.trim().isNotEmpty;
}
