import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'دستیار صافکاری',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
          actions: [
            IconButton(
              tooltip: 'وضعیت اتصال',
              onPressed: () {},
              icon: const Icon(Icons.cloud_queue_rounded),
            ),
          ],
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
            children: [
              _WelcomeCard(),
              const SizedBox(height: 18),
              Text(
                'کارگاه من',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 12),
              const _FeatureTile(
                icon: Icons.car_repair_rounded,
                title: 'پروژه‌های تعمیراتی',
                subtitle: 'ثبت خودرو، قطعه، آسیب و نتیجه تعمیر',
              ),
              const _FeatureTile(
                icon: Icons.checklist_rounded,
                title: 'مراحل انجام کار',
                subtitle: 'چک‌لیست آماده‌سازی تا کنترل نهایی',
              ),
              const _FeatureTile(
                icon: Icons.handyman_rounded,
                title: 'بانک ابزارها',
                subtitle: 'ابزارهای موجود و کاربرد هرکدام',
              ),
              const _FeatureTile(
                icon: Icons.psychology_alt_rounded,
                title: 'مربی هوشمند',
                subtitle: 'تحلیل مسئله و پیشنهاد روش تعمیر',
              ),
              const _FeatureTile(
                icon: Icons.auto_stories_rounded,
                title: 'حافظه تجربیات',
                subtitle: 'تکنیک‌ها، نکته‌ها و تجربه‌های شخصی',
              ),
              const SizedBox(height: 12),
              const _StageNotice(),
            ],
          ),
        ),
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF176B62), Color(0xFF124B48)],
        ),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.build_circle_outlined, color: Colors.white, size: 30),
          SizedBox(height: 14),
          Text(
            'تجربه‌هایت را فراموش نکن',
            style: TextStyle(
              color: Colors.white,
              fontSize: 21,
              fontWeight: FontWeight.w800,
            ),
          ),
          SizedBox(height: 6),
          Text(
            'ابزارها، روش‌ها و مراحل تعمیر را در یک دستیار تخصصی مدیریت کن.',
            style: TextStyle(color: Color(0xFFE0F2EF), height: 1.7),
          ),
        ],
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).colorScheme.primaryContainer,
          child: Icon(icon, color: Theme.of(context).colorScheme.primary),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: () {},
      ),
    );
  }
}

class _StageNotice extends StatelessWidget {
  const _StageNotice();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFEAF2F0),
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Row(
        children: [
          Icon(Icons.info_outline_rounded, color: Color(0xFF176B62)),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'نسخه زیرساختی ۰.۱.۰ — قابلیت‌های عملیاتی در مراحل بعد اضافه می‌شوند.',
              style: TextStyle(height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}
