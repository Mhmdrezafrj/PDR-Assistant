package com.pdrassistant.app.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.appwidget.lazy.items
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.updateAll
import androidx.glance.background
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextDecoration
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.pdrassistant.app.MainActivity
import com.pdrassistant.app.data.AppDatabase
import com.pdrassistant.app.data.QuickItem
import com.pdrassistant.app.domain.QuickKind
import com.pdrassistant.app.domain.QuickListLogic

private val Bg = Color(0xFF4B4177)
private val Cream = Color(0xFFFBE9D6)
private val Peach = Color(0xFFF4C38C)
private val Muted = Color(0xFFB8AEDB)

/** ویجت صفحه‌ی اصلی: همان فهرست «چک‌لیست کار»؛ با لمس هر مورد تیک می‌خورد/برداشته می‌شود. */
class QuickListWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val items = AppDatabase.get(context).quickItemDao().getAll()
        provideContent { Content(items) }
    }

    /** ردیف نمایشی: سرتیتر (itemId منفی) یا یک مورد. */
    private data class WRow(val id: Long, val header: String?, val item: QuickItem?)

    @Composable
    private fun Content(items: List<QuickItem>) {
        val rows = ArrayList<WRow>()
        QuickKind.entries.forEachIndexed { index, kind ->
            val list = QuickListLogic.ofKind(items, kind)
            if (list.isNotEmpty()) {
                rows.add(WRow(-(index + 1).toLong(), kind.label, null))
                list.forEach { rows.add(WRow(it.id, null, it)) }
            }
        }
        val (done, total) = QuickListLogic.progress(items)

        Column(
            GlanceModifier
                .fillMaxSize()
                .background(Bg)
                .cornerRadius(20.dp)
                .padding(10.dp)
        ) {
            Text(
                if (total == 0) "چک‌لیست کار" else "چک‌لیست کار — $done از $total",
                modifier = GlanceModifier.fillMaxWidth().padding(bottom = 6.dp)
                    .clickable(actionStartActivity<MainActivity>()),
                style = TextStyle(color = ColorProvider(Peach), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            )
            if (rows.isEmpty()) {
                Text(
                    "فهرست خالی است. برنامه را باز کنید و ابزارها و مراحل را بنویسید.",
                    modifier = GlanceModifier.clickable(actionStartActivity<MainActivity>()),
                    style = TextStyle(color = ColorProvider(Muted), fontSize = 13.sp)
                )
            } else {
                LazyColumn {
                    items(rows, itemId = { it.id }) { r ->
                        val item = r.item
                        if (item == null) {
                            Text(
                                r.header.orEmpty(),
                                modifier = GlanceModifier.fillMaxWidth().padding(top = 6.dp, bottom = 2.dp),
                                style = TextStyle(color = ColorProvider(Muted), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            )
                        } else {
                            Text(
                                (if (item.done) "☑  " else "☐  ") + item.text,
                                modifier = GlanceModifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clickable(
                                        actionRunCallback<ToggleQuickItemAction>(
                                            actionParametersOf(ItemIdKey to item.id)
                                        )
                                    ),
                                style = TextStyle(
                                    color = ColorProvider(if (item.done) Muted else Cream),
                                    fontSize = 15.sp,
                                    textDecoration = if (item.done) TextDecoration.LineThrough else TextDecoration.None
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    companion object {
        val ItemIdKey = ActionParameters.Key<Long>("quickItemId")
    }
}

/** لمس یک مورد در ویجت: تیک را برعکس می‌کند و ویجت را تازه می‌کند (بدون باز شدن برنامه). */
class ToggleQuickItemAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val id = parameters[QuickListWidget.ItemIdKey] ?: return
        AppDatabase.get(context).quickItemDao().toggle(id)
        QuickListWidget().updateAll(context)
    }
}

class QuickListWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = QuickListWidget()
}
