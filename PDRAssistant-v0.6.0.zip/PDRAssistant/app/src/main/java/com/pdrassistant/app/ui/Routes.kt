package com.pdrassistant.app.ui

import androidx.compose.ui.graphics.Color
import com.pdrassistant.app.domain.RepairType
import com.pdrassistant.app.ui.theme.PdrColors

sealed interface Route {
    data object QuickList : Route
    data object Dashboard : Route
    data object Projects : Route
    data object Experiences : Route
    data object Backup : Route
    data object Tools : Route
    data class ToolEdit(val id: Long?) : Route
    data class ToolBuildDetail(val id: Long) : Route
    data class ToolBuildEdit(val id: Long?) : Route
    data class ProjectDetail(val id: Long) : Route
    data class ProjectEdit(val id: Long?) : Route
    data class ExperienceDetail(val id: Long) : Route
    /** [fromProjectId]: ثبت تجربه جدید از داخل یک پروژه؛ فیلدها از پروژه پر می‌شوند. */
    data class ExperienceEdit(
        val id: Long?,
        val fromProjectId: Long? = null,
        /** ثبت تجربه از یک منبع آموزشی کتابخانه؛ فیلدها از منبع پر می‌شوند. */
        val fromResourceId: Long? = null
    ) : Route
    data class ResourceDetail(val id: Long) : Route
    data class ResourceEdit(val id: Long?) : Route
    data class KnowledgeDetail(val id: Long) : Route
    data class KnowledgeEdit(val id: Long?) : Route
}

fun repairColor(key: String?): Color = when (RepairType.fromKey(key)) {
    RepairType.TRADITIONAL -> PdrColors.Blue
    RepairType.PAINT -> PdrColors.Pink
    RepairType.PDR -> PdrColors.Lavender
    null -> PdrColors.Muted
}

fun formatDate(millis: Long): String {
    // تاریخ میلادی ساده؛ تقویم شمسی در نسخه‌های بعد (نیازمند کتابخانه/الگوریتم تبدیل تست‌شده).
    val c = java.util.Calendar.getInstance().apply { timeInMillis = millis }
    return "%04d/%02d/%02d".format(
        c.get(java.util.Calendar.YEAR),
        c.get(java.util.Calendar.MONTH) + 1,
        c.get(java.util.Calendar.DAY_OF_MONTH)
    )
}
