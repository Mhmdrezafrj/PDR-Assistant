package com.pdrassistant.app.domain

import com.pdrassistant.app.data.QuickItem

/** منطق خالص فهرست کار سریع (ابزارها و مراحل دستی + تیک). */
object QuickListLogic {

    /** موارد یک نوع، به ترتیب نوشتن. */
    fun ofKind(items: List<QuickItem>, kind: QuickKind): List<QuickItem> =
        items.filter { it.kind == kind.key }.sortedWith(compareBy({ it.position }, { it.id }))

    /**
     * متن چندخطی را به موردهای تازه تبدیل می‌کند: هر خط یک مورد، شماره/نشانه‌ی ابتدای خط برداشته می‌شود،
     * خط خالی و موردی که از قبل در همان نوع هست (یا تکراری است) نادیده گرفته می‌شود.
     * position بعد از آخرین مورد موجود شروع می‌شود تا ترتیب نوشتن حفظ شود.
     */
    fun newItems(kind: QuickKind, input: String, existing: List<QuickItem>, now: Long): List<QuickItem> {
        val same = existing.filter { it.kind == kind.key }
        val texts = ChecklistLogic.stepsToItems(input, same.map { it.text })
        val start = (existing.maxOfOrNull { it.position } ?: -1) + 1
        return texts.mapIndexed { i, t ->
            QuickItem(kind = kind.key, text = t, done = false, position = start + i, createdAt = now)
        }
    }

    /** (انجام‌شده، کل). */
    fun progress(items: List<QuickItem>): Pair<Int, Int> = items.count { it.done } to items.size

    fun allDone(items: List<QuickItem>): Boolean = items.isNotEmpty() && items.all { it.done }
}
