package com.pdrassistant.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * نسخه ۶ دیتابیس (0.6.0): جدول quick_items (فهرست کار سریع و ویجت).
 * نسخه ۵ دیتابیس (0.5.0): جدول knowledge_entries (دانشنامه‌ی شخصی).
 * نسخه ۴ دیتابیس (0.4.0): جدول learning_resources (کتابخانه آموزش‌ها).
 * نسخه ۳ دیتابیس (0.3.0): ستون‌های ارزیابی در projects + جدول‌های tool_builds و tool_materials.
 * نسخه ۲ (0.2.0): جدول tools و checklist_items.
 * قانون: هر تغییر در Entityها => version بالا برود + یک Migration نوشته شود (هرگز fallbackToDestructiveMigration نه).
 * طرح‌های دیتابیس در app/schemas ذخیره می‌شوند تا مهاجرت‌های بعدی قابل بررسی باشند.
 */
@Database(
    entities = [
        Project::class, Experience::class, Tool::class, ChecklistItem::class,
        ToolBuild::class, ToolMaterial::class, LearningResource::class, KnowledgeEntry::class,
        QuickItem::class
    ],
    version = 6,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun experienceDao(): ExperienceDao
    abstract fun toolDao(): ToolDao
    abstract fun checklistDao(): ChecklistDao
    abstract fun toolBuildDao(): ToolBuildDao
    abstract fun toolMaterialDao(): ToolMaterialDao
    abstract fun learningResourceDao(): LearningResourceDao
    abstract fun knowledgeEntryDao(): KnowledgeEntryDao
    abstract fun quickItemDao(): QuickItemDao
    abstract fun backupDao(): BackupDao

    companion object {
        /** 1 → 2: فقط دو جدول جدید اضافه می‌شود؛ داده‌های قبلی دست نمی‌خورد. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tools` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, `category` TEXT NOT NULL, `notes` TEXT NOT NULL, " +
                        "`owned` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `checklist_items` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`projectId` INTEGER NOT NULL, `text` TEXT NOT NULL, `done` INTEGER NOT NULL, " +
                        "`position` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_checklist_items_projectId` ON `checklist_items` (`projectId`)"
                )
            }
        }

        /** 2 → 3: چهار ستون جدید با مقدار پیش‌فرض (داده‌های قبلی دست نمی‌خورد) + دو جدول جدید. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE `projects` ADD COLUMN `outcome` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `projects` ADD COLUMN `timeSpentMinutes` INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE `projects` ADD COLUMN `mistakes` TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE `projects` ADD COLUMN `lessons` TEXT NOT NULL DEFAULT ''")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tool_builds` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`name` TEXT NOT NULL, `purpose` TEXT NOT NULL, `status` TEXT NOT NULL, " +
                        "`design` TEXT NOT NULL, `steps` TEXT NOT NULL, `planFiles` TEXT NOT NULL, " +
                        "`photoFiles` TEXT NOT NULL, `result` TEXT NOT NULL, `toolId` INTEGER, " +
                        "`createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tool_materials` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`buildId` INTEGER NOT NULL, `name` TEXT NOT NULL, `quantity` TEXT NOT NULL, " +
                        "`acquired` INTEGER NOT NULL, `position` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`buildId`) REFERENCES `tool_builds`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_tool_materials_buildId` ON `tool_materials` (`buildId`)"
                )
            }
        }

        /** 3 → 4: فقط یک جدول جدید؛ داده‌های قبلی دست نمی‌خورد. */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `learning_resources` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`title` TEXT NOT NULL, `kind` TEXT NOT NULL, `url` TEXT NOT NULL, " +
                        "`author` TEXT NOT NULL, `repairType` TEXT NOT NULL, `carPart` TEXT NOT NULL, " +
                        "`damageType` TEXT NOT NULL, `keyPoints` TEXT NOT NULL, `notes` TEXT NOT NULL, " +
                        "`rating` INTEGER NOT NULL, `status` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)"
                )
            }
        }

        /** 4 → 5: فقط یک جدول جدید؛ داده‌های قبلی دست نمی‌خورد. */
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `knowledge_entries` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`title` TEXT NOT NULL, `category` TEXT NOT NULL, `kind` TEXT NOT NULL, " +
                        "`body` TEXT NOT NULL, `source` TEXT NOT NULL, `carPart` TEXT NOT NULL, " +
                        "`damageType` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL)"
                )
            }
        }

        /** 5 → 6: فقط یک جدول جدید؛ داده‌های قبلی دست نمی‌خورد. */
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `quick_items` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`kind` TEXT NOT NULL, `text` TEXT NOT NULL, `done` INTEGER NOT NULL, " +
                        "`position` INTEGER NOT NULL, `createdAt` INTEGER NOT NULL)"
                )
            }
        }

        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pdr_assistant.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                    .build()
                    .also { instance = it }
            }
    }
}
