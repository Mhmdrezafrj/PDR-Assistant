package com.pdrassistant.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<Project>>

    @Query("SELECT * FROM projects ORDER BY id")
    suspend fun getAll(): List<Project>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun get(id: Long): Project?

    @Insert
    suspend fun insert(project: Project): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(projects: List<Project>)

    @Update
    suspend fun update(project: Project)

    @Delete
    suspend fun delete(project: Project)

    @Query("DELETE FROM projects")
    suspend fun deleteAll()
}

@Dao
interface ExperienceDao {
    @Query("SELECT * FROM experiences ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<Experience>>

    @Query("SELECT * FROM experiences ORDER BY id")
    suspend fun getAll(): List<Experience>

    @Query("SELECT * FROM experiences WHERE id = :id")
    suspend fun get(id: Long): Experience?

    @Insert
    suspend fun insert(experience: Experience): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(experiences: List<Experience>)

    @Update
    suspend fun update(experience: Experience)

    @Delete
    suspend fun delete(experience: Experience)

    @Query("DELETE FROM experiences")
    suspend fun deleteAll()
}

@Dao
interface ToolDao {
    @Query("SELECT * FROM tools ORDER BY name")
    fun observeAll(): Flow<List<Tool>>

    @Query("SELECT * FROM tools ORDER BY id")
    suspend fun getAll(): List<Tool>

    @Insert
    suspend fun insert(tool: Tool): Long

    @Update
    suspend fun update(tool: Tool)

    @Delete
    suspend fun delete(tool: Tool)
}

@Dao
interface ChecklistDao {
    @Query("SELECT * FROM checklist_items ORDER BY projectId, position, id")
    fun observeAll(): Flow<List<ChecklistItem>>

    @Query("SELECT * FROM checklist_items ORDER BY id")
    suspend fun getAll(): List<ChecklistItem>

    @Query("SELECT COALESCE(MAX(position), -1) FROM checklist_items WHERE projectId = :projectId")
    suspend fun maxPosition(projectId: Long): Int

    @Insert
    suspend fun insert(item: ChecklistItem): Long

    @Insert
    suspend fun insertAll(items: List<ChecklistItem>)

    @Query("UPDATE checklist_items SET done = :done WHERE id = :id")
    suspend fun setDone(id: Long, done: Boolean)

    @Delete
    suspend fun delete(item: ChecklistItem)
}

@Dao
interface ToolBuildDao {
    @Query("SELECT * FROM tool_builds ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ToolBuild>>

    @Query("SELECT * FROM tool_builds ORDER BY id")
    suspend fun getAll(): List<ToolBuild>

    @Insert
    suspend fun insert(build: ToolBuild): Long

    @Update
    suspend fun update(build: ToolBuild)

    @Delete
    suspend fun delete(build: ToolBuild)
}

@Dao
interface ToolMaterialDao {
    @Query("SELECT * FROM tool_materials ORDER BY buildId, position, id")
    fun observeAll(): Flow<List<ToolMaterial>>

    @Query("SELECT * FROM tool_materials ORDER BY id")
    suspend fun getAll(): List<ToolMaterial>

    @Query("SELECT COALESCE(MAX(position), -1) FROM tool_materials WHERE buildId = :buildId")
    suspend fun maxPosition(buildId: Long): Int

    @Insert
    suspend fun insert(material: ToolMaterial): Long

    @Query("UPDATE tool_materials SET acquired = :acquired WHERE id = :id")
    suspend fun setAcquired(id: Long, acquired: Boolean)

    @Delete
    suspend fun delete(material: ToolMaterial)
}

@Dao
interface LearningResourceDao {
    @Query("SELECT * FROM learning_resources ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<LearningResource>>

    @Query("SELECT * FROM learning_resources ORDER BY id")
    suspend fun getAll(): List<LearningResource>

    @Insert
    suspend fun insert(resource: LearningResource): Long

    @Update
    suspend fun update(resource: LearningResource)

    @Delete
    suspend fun delete(resource: LearningResource)
}

@Dao
interface KnowledgeEntryDao {
    @Query("SELECT * FROM knowledge_entries ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<KnowledgeEntry>>

    @Query("SELECT * FROM knowledge_entries ORDER BY id")
    suspend fun getAll(): List<KnowledgeEntry>

    @Insert
    suspend fun insert(entry: KnowledgeEntry): Long

    @Update
    suspend fun update(entry: KnowledgeEntry)

    @Delete
    suspend fun delete(entry: KnowledgeEntry)
}

@Dao
interface QuickItemDao {
    @Query("SELECT * FROM quick_items ORDER BY position, id")
    fun observeAll(): Flow<List<QuickItem>>

    @Query("SELECT * FROM quick_items ORDER BY position, id")
    suspend fun getAll(): List<QuickItem>

    @Insert
    suspend fun insertAll(items: List<QuickItem>)

    @Query("UPDATE quick_items SET done = 1 - done WHERE id = :id")
    suspend fun toggle(id: Long)

    @Query("UPDATE quick_items SET done = 0")
    suspend fun resetAll()

    @Query("DELETE FROM quick_items")
    suspend fun deleteAll()

    @Delete
    suspend fun delete(item: QuickItem)
}

@Dao
abstract class BackupDao {
    @Query("DELETE FROM quick_items")
    abstract suspend fun clearQuick()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putQuick(items: List<QuickItem>)

    @Query("DELETE FROM knowledge_entries")
    abstract suspend fun clearKnowledge()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putKnowledge(entries: List<KnowledgeEntry>)

    @Query("DELETE FROM learning_resources")
    abstract suspend fun clearResources()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putResources(resources: List<LearningResource>)

    @Query("DELETE FROM tool_materials")
    abstract suspend fun clearToolMaterials()

    @Query("DELETE FROM tool_builds")
    abstract suspend fun clearToolBuilds()

    @Query("DELETE FROM checklist_items")
    abstract suspend fun clearChecklist()

    @Query("DELETE FROM experiences")
    abstract suspend fun clearExperiences()

    @Query("DELETE FROM projects")
    abstract suspend fun clearProjects()

    @Query("DELETE FROM tools")
    abstract suspend fun clearTools()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putProjects(projects: List<Project>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putExperiences(experiences: List<Experience>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putTools(tools: List<Tool>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putChecklist(items: List<ChecklistItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putToolBuilds(builds: List<ToolBuild>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putToolMaterials(materials: List<ToolMaterial>)

    /** جایگزینی کامل اطلاعات در یک تراکنش: یا همه انجام می‌شود یا هیچ. */
    @Transaction
    open suspend fun replaceAll(snapshot: BackupCodec.Snapshot) {
        clearQuick()
        clearKnowledge()
        clearResources()
        clearToolMaterials()
        clearToolBuilds()
        clearChecklist()
        clearExperiences()
        clearProjects()
        clearTools()
        putProjects(snapshot.projects)
        putExperiences(snapshot.experiences)
        putTools(snapshot.tools)
        putChecklist(snapshot.checklist)
        putToolBuilds(snapshot.toolBuilds)
        putToolMaterials(snapshot.toolMaterials)
        putResources(snapshot.resources)
        putKnowledge(snapshot.knowledge)
        putQuick(snapshot.quickItems)
    }
}
