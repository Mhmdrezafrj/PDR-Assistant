package com.pdrassistant.app.domain

/** نوع تعمیر. کلید (key) در دیتابیس ذخیره می‌شود و هرگز نباید تغییر کند. */
enum class RepairType(val key: String, val label: String) {
    TRADITIONAL("TRADITIONAL", "صافکاری سنتی"),
    PAINT("PAINT", "صافکاری با رنگ"),
    PDR("PDR", "PDR (بدون رنگ)");

    companion object {
        fun fromKey(key: String?): RepairType? = entries.firstOrNull { it.key == key }
        fun labelOf(key: String?): String = fromKey(key)?.label ?: "نامشخص"
    }
}

/** وضعیت پروژه تعمیراتی. */
enum class ProjectStatus(val key: String, val label: String) {
    PLANNED("PLANNED", "برنامه‌ریزی"),
    IN_PROGRESS("IN_PROGRESS", "در حال انجام"),
    DONE("DONE", "انجام‌شده");

    companion object {
        fun fromKey(key: String?): ProjectStatus = entries.firstOrNull { it.key == key } ?: PLANNED
    }
}

/** میزان اطمینان استادکار به یک تجربه. */
enum class Confidence(val key: String, val label: String, val hint: String) {
    TESTED("TESTED", "آزموده‌شده", "خودم چندبار اجرا کرده‌ام"),
    ONCE("ONCE", "یک‌بار انجام‌شده", "یک‌بار نتیجه داده، هنوز تکرار نشده"),
    HEARD("HEARD", "شنیده/دیده‌شده", "از ویدئو یا دیگران؛ خودم نیازموده‌ام"),
    UNSURE("UNSURE", "نامطمئن", "نیاز به آزمایش دارد");

    companion object {
        fun fromKey(key: String?): Confidence = entries.firstOrNull { it.key == key } ?: UNSURE
    }
}

/** ارزیابی نهایی نتیجه یک پروژه. کلید خالی یعنی هنوز ارزیابی نشده. */
enum class Outcome(val key: String, val label: String) {
    SUCCESS("SUCCESS", "موفق"),
    PARTIAL("PARTIAL", "نسبتاً موفق"),
    FAILED("FAILED", "ناموفق");

    companion object {
        fun fromKey(key: String?): Outcome? = entries.firstOrNull { it.key == key }
        fun labelOf(key: String?): String = fromKey(key)?.label ?: "ارزیابی نشده"
    }
}

/** وضعیت ساخت یک ابزار دست‌ساز. */
enum class BuildStatus(val key: String, val label: String) {
    IDEA("IDEA", "ایده / طراحی"),
    BUILDING("BUILDING", "در حال ساخت"),
    DONE("DONE", "ساخته شد");

    companion object {
        fun fromKey(key: String?): BuildStatus = entries.firstOrNull { it.key == key } ?: IDEA
    }
}

/** نوع منبع آموزشی. */
enum class ResourceKind(val key: String, val label: String) {
    VIDEO("VIDEO", "ویدئو"),
    ARTICLE("ARTICLE", "مقاله"),
    BOOK("BOOK", "کتاب"),
    COURSE("COURSE", "دوره"),
    OTHER("OTHER", "دیگر");

    companion object {
        fun fromKey(key: String?): ResourceKind = entries.firstOrNull { it.key == key } ?: OTHER
    }
}

/** وضعیت یادگیری از یک منبع. */
enum class ResourceStatus(val key: String, val label: String) {
    TO_WATCH("TO_WATCH", "در صف"),
    WATCHED("WATCHED", "دیده شد"),
    TRIED("TRIED", "آزموده شد");

    companion object {
        fun fromKey(key: String?): ResourceStatus = entries.firstOrNull { it.key == key } ?: TO_WATCH
    }
}

/** پیشنهادهای سریع؛ فیلدها متن آزاد هستند و کاربر می‌تواند هر مقدار دیگری بنویسد. */
object Suggestions {
    val carParts = listOf(
        "درب جلو", "درب عقب", "گلگیر جلو", "گلگیر عقب", "کاپوت", "صندوق عقب",
        "سقف", "ستون", "رکاب", "سپر"
    )
    val damageTypes = listOf(
        "فرورفتگی ساده", "فرورفتگی با خط تیز", "چروک", "تا خوردگی", "فشردگی لبه",
        "تگرگ‌زدگی", "کشیدگی ورق", "ضربه با رنگ‌پریدگی"
    )
    val toolCategories = listOf(
        "PDR", "صافکاری", "رنگ و پرداخت", "اندازه‌گیری", "برقی/گرمایی", "مصرفی", "ایمنی"
    )
    val tools = listOf(
        "میله PDR", "چراغ PDR", "گلوپلر (Glue puller)", "چکش صافکاری", "دالی",
        "پتک لاستیکی", "اسپیلر", "تب (Tap down)", "سنباده", "گرمکن"
    )
    val materials = listOf(
        "میله فولادی", "لوله", "ورق", "چوب", "لاستیک", "پیچ و مهره", "چسب", "رنگ", "نمد / پارچه", "نوار"
    )
}

/**
 * نوع مطلب دانشنامه. هدف: تجربه‌ی شخصی و فرضیه هرگز به‌جای اصل فنی/علمی جا زده نشود.
 * پیش‌فرض «تجربه‌ی شخصی» است؛ «اصل فنی» را فقط خود استادکار آگاهانه انتخاب می‌کند.
 */
enum class KnowledgeKind(val key: String, val label: String, val warning: String) {
    FACT("FACT", "اصل فنی/علمی", "این مطلب را خودتان «اصل فنی» ثبت کرده‌اید؛ اگر منبع معتبر دارد، در فیلد منبع بنویسید."),
    PERSONAL("PERSONAL", "تجربه‌ی شخصی", "تجربه‌ی شخصی است؛ ممکن است برای هر خودرو، ورق یا شرایطی صدق نکند و قانون علمی نیست."),
    HYPOTHESIS("HYPOTHESIS", "فرضیه / نیاز به بررسی", "فرضیه است و هنوز اثبات یا آزموده نشده؛ پیش از تکیه بر آن روی قطعه‌ی آزمایشی امتحانش کنید.");

    companion object {
        fun fromKey(key: String?): KnowledgeKind = entries.firstOrNull { it.key == key } ?: PERSONAL
    }
}

/** نوع مورد در فهرست کار سریع. */
enum class QuickKind(val key: String, val label: String) {
    TOOL("TOOL", "ابزارها"),
    STEP("STEP", "مراحل کار");

    companion object {
        fun fromKey(key: String?): QuickKind = entries.firstOrNull { it.key == key } ?: STEP
    }
}
