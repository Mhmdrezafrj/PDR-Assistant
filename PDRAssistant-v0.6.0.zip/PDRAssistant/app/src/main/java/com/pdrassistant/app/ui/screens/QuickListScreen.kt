package com.pdrassistant.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.data.QuickItem
import com.pdrassistant.app.domain.QuickKind
import com.pdrassistant.app.domain.QuickListLogic
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.theme.PdrColors

/**
 * فهرست کار سریع: ابزارها و مراحل را دستی می‌نویسید و موقع کار تیک می‌زنید.
 * همین فهرست در ویجت صفحه‌ی اصلی گوشی هم هست و تیک‌ها بین این صفحه و ویجت یکی است.
 */
@Composable
fun QuickListScreen(
    items: List<QuickItem>,
    onAdd: (QuickKind, String) -> Unit,
    onToggle: (QuickItem) -> Unit,
    onDelete: (QuickItem) -> Unit,
    onReset: () -> Unit,
    onClear: () -> Unit
) {
    var confirmClear by remember { mutableStateOf(false) }
    val (done, total) = QuickListLogic.progress(items)

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            ScreenTitle(
                "چک‌لیست کار",
                if (total == 0) "ابزارها و مراحل کار را بنویسید"
                else if (QuickListLogic.allDone(items)) "همه انجام شد ✓" else "$done از $total انجام شد"
            )
        }
        if (total > 0) {
            item {
                Box(Modifier.fillMaxWidth().height(8.dp).background(PdrColors.SurfaceDeep, RoundedCornerShape(50))) {
                    Box(
                        Modifier
                            .fillMaxWidth(done.toFloat() / total)
                            .height(8.dp)
                            .background(PdrColors.Peach, RoundedCornerShape(50))
                    )
                }
            }
        }

        QuickKind.entries.forEach { kind ->
            val list = QuickListLogic.ofKind(items, kind)
            item(key = "h-${kind.key}") { SectionLabel("${kind.label} (${list.count { it.done }} از ${list.size})") }
            items(list, key = { it.id }) { item -> QuickRow(item, { onToggle(item) }, { onDelete(item) }) }
            item(key = "add-${kind.key}") { QuickAdd(kind, onAdd) }
        }

        item {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("شروع دوباره (تیک‌ها پاک شود)", onClick = onReset, primary = false)
                PillButton("پاک کردن همه", onClick = { confirmClear = true }, primary = false)
            }
        }
        item {
            Text(
                "ویجت: روی صفحه‌ی اصلی گوشی جای خالی را نگه دارید، «ویجت‌ها» را بزنید و «دستیار PDR» را بیاورید. " +
                    "تیک‌های ویجت و این صفحه یکی هستند.",
                color = PdrColors.Muted, fontSize = 13.sp
            )
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            "پاک کردن همه؟",
            "همه‌ی ابزارها و مراحل این فهرست حذف می‌شود.",
            "پاک کن",
            onConfirm = { confirmClear = false; onClear() },
            onDismiss = { confirmClear = false }
        )
    }
}

@Composable
private fun QuickRow(item: QuickItem, onToggle: () -> Unit, onDelete: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(PdrColors.Surface, RoundedCornerShape(18.dp))
            .clickable(onClick = onToggle)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(26.dp)
                .background(if (item.done) PdrColors.Peach else PdrColors.SurfaceDeep, RoundedCornerShape(8.dp))
                .border(2.dp, PdrColors.Peach, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (item.done) Text("✓", color = PdrColors.PeachDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(Modifier.width(12.dp))
        Text(
            item.text,
            modifier = Modifier.weight(1f),
            color = if (item.done) PdrColors.Muted else PdrColors.Cream,
            textDecoration = if (item.done) TextDecoration.LineThrough else TextDecoration.None,
            fontSize = 16.sp
        )
        Box(Modifier.size(36.dp).clickable(onClick = onDelete), contentAlignment = Alignment.Center) {
            Text("✕", color = PdrColors.Muted, fontSize = 16.sp)
        }
    }
}

@Composable
private fun QuickAdd(kind: QuickKind, onAdd: (QuickKind, String) -> Unit) {
    var text by remember { mutableStateOf("") }
    PdrField(
        text, { text = it },
        if (kind == QuickKind.TOOL) "ابزار جدید (هر خط یک ابزار)" else "مرحله‌ی جدید (هر خط یک مرحله)",
        minLines = 2
    )
    PillButton(
        "افزودن",
        onClick = {
            if (text.isNotBlank()) {
                onAdd(kind, text)
                text = ""
            }
        },
        primary = false
    )
}
