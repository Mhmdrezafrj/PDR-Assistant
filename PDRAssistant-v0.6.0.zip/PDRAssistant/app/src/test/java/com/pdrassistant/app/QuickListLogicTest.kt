package com.pdrassistant.app

import com.pdrassistant.app.data.QuickItem
import com.pdrassistant.app.domain.QuickKind
import com.pdrassistant.app.domain.QuickListLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuickListLogicTest {
    private fun q(id: Long, text: String, kind: String = "STEP", pos: Int = 0, done: Boolean = false) =
        QuickItem(id = id, kind = kind, text = text, done = done, position = pos, createdAt = 0)

    @Test fun newItemsSplitsLinesAndStripsNumbers() {
        val r = QuickListLogic.newItems(QuickKind.STEP, "۱. شستشو\n\n2- گرم کردن\n- چکش", emptyList(), 5)
        assertEquals(listOf("شستشو", "گرم کردن", "چکش"), r.map { it.text })
        assertEquals(listOf(0, 1, 2), r.map { it.position })
        assertTrue(r.all { it.kind == "STEP" && !it.done && it.createdAt == 5L })
    }

    @Test fun newItemsSkipsDuplicatesOnlyWithinSameKind() {
        val existing = listOf(q(1, "گلوپلر", kind = "TOOL", pos = 4))
        assertTrue(QuickListLogic.newItems(QuickKind.TOOL, "گلوپلر\n گلوپلر ", existing, 0).isEmpty())
        val steps = QuickListLogic.newItems(QuickKind.STEP, "گلوپلر", existing, 0)
        assertEquals(1, steps.size)
        assertEquals(5, steps[0].position)
    }

    @Test fun blankInputGivesNothing() {
        assertTrue(QuickListLogic.newItems(QuickKind.TOOL, "  \n \n", emptyList(), 0).isEmpty())
    }

    @Test fun ofKindFiltersAndOrders() {
        val l = listOf(q(1, "b", pos = 2), q(2, "t", kind = "TOOL"), q(3, "a", pos = 1), q(4, "c", pos = 2))
        assertEquals(listOf(3L, 1L, 4L), QuickListLogic.ofKind(l, QuickKind.STEP).map { it.id })
        assertEquals(listOf(2L), QuickListLogic.ofKind(l, QuickKind.TOOL).map { it.id })
    }

    @Test fun progressAndAllDone() {
        val l = listOf(q(1, "a", done = true), q(2, "b"))
        assertEquals(1 to 2, QuickListLogic.progress(l))
        assertFalse(QuickListLogic.allDone(l))
        assertTrue(QuickListLogic.allDone(listOf(q(1, "a", done = true))))
        assertFalse(QuickListLogic.allDone(emptyList()))
    }

    @Test fun unknownKindIsStep() {
        assertEquals(QuickKind.STEP, QuickKind.fromKey("x"))
        assertEquals(QuickKind.TOOL, QuickKind.fromKey("TOOL"))
    }
}
