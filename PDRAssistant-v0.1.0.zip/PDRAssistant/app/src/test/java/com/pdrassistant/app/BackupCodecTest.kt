package com.pdrassistant.app

import com.pdrassistant.app.data.BackupCodec
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Project
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.fail
import org.junit.Test

class BackupCodecTest {

    private val project = Project(
        id = 7, title = "پژو ۲۰۶", vehicle = "سفید", plate = "", carPart = "درب جلو",
        damageType = "فرورفتگی", repairType = "PDR", status = "DONE", notes = "خط «تیز» و \"نقل‌قول\"\nخط دوم",
        resultNotes = "خوب شد", createdAt = 1000, updatedAt = 2000
    )
    private val experience = Experience(
        id = 3, title = "بادگیری با گلوپلر", repairType = "PDR", carPart = "درب جلو",
        damageType = "فرورفتگی", tools = "گلوپلر\nچراغ", steps = "۱\n۲\n۳", conditions = "ورق آلومینیوم",
        result = "عالی", possibleErrors = "بالاآمدگی", mediaFiles = "a.jpg\nb.mp4", source = "ویدئو",
        confidence = "TESTED", masterNotes = "حتماً گرم نشود", projectId = 7, createdAt = 10, updatedAt = 20
    )

    @Test fun roundTripKeepsEveryField() {
        val text = BackupCodec.encode(listOf(project), listOf(experience), now = 99)
        val snap = BackupCodec.decode(text)
        assertEquals(listOf(project), snap.projects)
        assertEquals(listOf(experience), snap.experiences)
    }

    @Test fun nullProjectIdSurvives() {
        val e = experience.copy(projectId = null)
        val snap = BackupCodec.decode(BackupCodec.encode(listOf(project), listOf(e), 1))
        assertNull(snap.experiences.single().projectId)
    }

    @Test fun danglingProjectReferenceIsCleared() {
        val e = experience.copy(projectId = 999)
        val snap = BackupCodec.decode(BackupCodec.encode(listOf(project), listOf(e), 1))
        assertNull(snap.experiences.single().projectId)
    }

    @Test fun emptyBackupIsValid() {
        val snap = BackupCodec.decode(BackupCodec.encode(emptyList(), emptyList(), 1))
        assertEquals(0, snap.projects.size + snap.experiences.size)
    }

    private fun assertRejected(text: String) {
        try {
            BackupCodec.decode(text)
            fail("باید رد می‌شد: $text")
        } catch (e: BackupCodec.BackupException) {
            // درست
        }
    }

    @Test fun rejectsGarbageAndForeignJson() {
        assertRejected("این JSON نیست")
        assertRejected("{}")
        assertRejected("""{"magic":"something-else","formatVersion":1}""")
    }

    @Test fun rejectsNewerFormat() {
        assertRejected("""{"magic":"pdr-assistant-backup","formatVersion":99,"projects":[],"experiences":[]}""")
    }

    @Test fun rejectsTruncatedStructure() {
        assertRejected("""{"magic":"pdr-assistant-backup","formatVersion":1,"projects":[]}""")
    }

    @Test fun rejectsDuplicateIds() {
        val text = BackupCodec.encode(listOf(project, project), emptyList(), 1)
        assertRejected(text)
    }
}
