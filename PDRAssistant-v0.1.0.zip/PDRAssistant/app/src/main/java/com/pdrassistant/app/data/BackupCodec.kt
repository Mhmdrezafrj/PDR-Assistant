package com.pdrassistant.app.data

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * تبدیل کل اطلاعات به JSON و بالعکس (پشتیبان‌گیری/بازیابی).
 * - نسخه فرمت در فایل ثبت می‌شود؛ فایل جدیدتر از نسخه پشتیبانی‌شده رد می‌شود.
 * - فایل‌های تصویر/ویدئو در 0.1.0 داخل پشتیبان نیستند (فقط نام آن‌ها).
 */
object BackupCodec {
    const val FORMAT_VERSION = 1
    private const val MAGIC = "pdr-assistant-backup"

    class BackupException(message: String) : Exception(message)

    data class Snapshot(val projects: List<Project>, val experiences: List<Experience>)

    fun encode(projects: List<Project>, experiences: List<Experience>, now: Long): String {
        val root = JSONObject()
        root.put("magic", MAGIC)
        root.put("formatVersion", FORMAT_VERSION)
        root.put("createdAt", now)
        root.put("projects", JSONArray().also { arr -> projects.forEach { arr.put(projectToJson(it)) } })
        root.put("experiences", JSONArray().also { arr -> experiences.forEach { arr.put(experienceToJson(it)) } })
        return root.toString(2)
    }

    fun decode(text: String): Snapshot {
        val root = try {
            JSONObject(text)
        } catch (e: JSONException) {
            throw BackupException("این فایل پشتیبان معتبر نیست.")
        }
        if (root.optString("magic") != MAGIC) {
            throw BackupException("این فایل، پشتیبان دستیار PDR نیست.")
        }
        val version = root.optInt("formatVersion", -1)
        if (version < 1) throw BackupException("نسخه فایل پشتیبان نامعتبر است.")
        if (version > FORMAT_VERSION) {
            throw BackupException("این پشتیبان با نسخه جدیدتری از برنامه ساخته شده؛ ابتدا برنامه را به‌روزرسانی کنید.")
        }
        try {
            val projects = root.getJSONArray("projects").let { a ->
                (0 until a.length()).map { projectFromJson(a.getJSONObject(it)) }
            }
            val experiences = root.getJSONArray("experiences").let { a ->
                (0 until a.length()).map { experienceFromJson(a.getJSONObject(it)) }
            }
            // جلوگیری از شناسه تکراری و ارجاع به پروژه‌ای که وجود ندارد
            if (projects.map { it.id }.toSet().size != projects.size ||
                experiences.map { it.id }.toSet().size != experiences.size
            ) throw BackupException("فایل پشتیبان شناسه‌های تکراری دارد.")
            val projectIds = projects.map { it.id }.toSet()
            val fixed = experiences.map {
                if (it.projectId != null && it.projectId !in projectIds) it.copy(projectId = null) else it
            }
            return Snapshot(projects, fixed)
        } catch (e: JSONException) {
            throw BackupException("ساختار فایل پشتیبان ناقص است.")
        }
    }

    private fun projectToJson(p: Project) = JSONObject().apply {
        put("id", p.id); put("title", p.title); put("vehicle", p.vehicle); put("plate", p.plate)
        put("carPart", p.carPart); put("damageType", p.damageType); put("repairType", p.repairType)
        put("status", p.status); put("notes", p.notes); put("resultNotes", p.resultNotes)
        put("createdAt", p.createdAt); put("updatedAt", p.updatedAt)
    }

    private fun projectFromJson(o: JSONObject) = Project(
        id = o.getLong("id"),
        title = o.getString("title"),
        vehicle = o.optString("vehicle"),
        plate = o.optString("plate"),
        carPart = o.optString("carPart"),
        damageType = o.optString("damageType"),
        repairType = o.optString("repairType", "PDR"),
        status = o.optString("status", "PLANNED"),
        notes = o.optString("notes"),
        resultNotes = o.optString("resultNotes"),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )

    private fun experienceToJson(e: Experience) = JSONObject().apply {
        put("id", e.id); put("title", e.title); put("repairType", e.repairType)
        put("carPart", e.carPart); put("damageType", e.damageType); put("tools", e.tools)
        put("steps", e.steps); put("conditions", e.conditions); put("result", e.result)
        put("possibleErrors", e.possibleErrors); put("mediaFiles", e.mediaFiles)
        put("source", e.source); put("confidence", e.confidence); put("masterNotes", e.masterNotes)
        put("projectId", e.projectId ?: JSONObject.NULL)
        put("createdAt", e.createdAt); put("updatedAt", e.updatedAt)
    }

    private fun experienceFromJson(o: JSONObject) = Experience(
        id = o.getLong("id"),
        title = o.getString("title"),
        repairType = o.optString("repairType", "PDR"),
        carPart = o.optString("carPart"),
        damageType = o.optString("damageType"),
        tools = o.optString("tools"),
        steps = o.optString("steps"),
        conditions = o.optString("conditions"),
        result = o.optString("result"),
        possibleErrors = o.optString("possibleErrors"),
        mediaFiles = o.optString("mediaFiles"),
        source = o.optString("source"),
        confidence = o.optString("confidence", "UNSURE"),
        masterNotes = o.optString("masterNotes"),
        projectId = if (o.isNull("projectId")) null else o.getLong("projectId"),
        createdAt = o.getLong("createdAt"),
        updatedAt = o.getLong("updatedAt")
    )
}
