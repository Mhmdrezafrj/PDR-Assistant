package com.pdrassistant.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<Project>>

    @Query("SELECT * FROM projects ORDER BY id")
    suspend fun getAll(): List<Project>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun get(id: Long): Project?

    @Insert
    suspend fun insert(project: Project): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(projects: List<Project>)

    @Update
    suspend fun update(project: Project)

    @Delete
    suspend fun delete(project: Project)

    @Query("DELETE FROM projects")
    suspend fun deleteAll()
}

@Dao
interface ExperienceDao {
    @Query("SELECT * FROM experiences ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<Experience>>

    @Query("SELECT * FROM experiences ORDER BY id")
    suspend fun getAll(): List<Experience>

    @Query("SELECT * FROM experiences WHERE id = :id")
    suspend fun get(id: Long): Experience?

    @Insert
    suspend fun insert(experience: Experience): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(experiences: List<Experience>)

    @Update
    suspend fun update(experience: Experience)

    @Delete
    suspend fun delete(experience: Experience)

    @Query("DELETE FROM experiences")
    suspend fun deleteAll()
}

@Dao
abstract class BackupDao {
    @Query("DELETE FROM experiences")
    abstract suspend fun clearExperiences()

    @Query("DELETE FROM projects")
    abstract suspend fun clearProjects()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putProjects(projects: List<Project>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun putExperiences(experiences: List<Experience>)

    /** جایگزینی کامل اطلاعات در یک تراکنش: یا همه انجام می‌شود یا هیچ. */
    @Transaction
    open suspend fun replaceAll(projects: List<Project>, experiences: List<Experience>) {
        clearExperiences()
        clearProjects()
        putProjects(projects)
        putExperiences(experiences)
    }
}
