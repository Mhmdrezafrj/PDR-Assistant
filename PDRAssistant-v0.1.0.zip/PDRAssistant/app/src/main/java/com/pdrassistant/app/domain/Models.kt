package com.pdrassistant.app.domain

/** نوع تعمیر. کلید (key) در دیتابیس ذخیره می‌شود و هرگز نباید تغییر کند. */
enum class RepairType(val key: String, val label: String) {
    TRADITIONAL("TRADITIONAL", "صافکاری سنتی"),
    PAINT("PAINT", "صافکاری با رنگ"),
    PDR("PDR", "PDR (بدون رنگ)");

    companion object {
        fun fromKey(key: String?): RepairType? = entries.firstOrNull { it.key == key }
        fun labelOf(key: String?): String = fromKey(key)?.label ?: "نامشخص"
    }
}

/** وضعیت پروژه تعمیراتی. */
enum class ProjectStatus(val key: String, val label: String) {
    PLANNED("PLANNED", "برنامه‌ریزی"),
    IN_PROGRESS("IN_PROGRESS", "در حال انجام"),
    DONE("DONE", "انجام‌شده");

    companion object {
        fun fromKey(key: String?): ProjectStatus = entries.firstOrNull { it.key == key } ?: PLANNED
    }
}

/** میزان اطمینان استادکار به یک تجربه. */
enum class Confidence(val key: String, val label: String, val hint: String) {
    TESTED("TESTED", "آزموده‌شده", "خودم چندبار اجرا کرده‌ام"),
    ONCE("ONCE", "یک‌بار انجام‌شده", "یک‌بار نتیجه داده، هنوز تکرار نشده"),
    HEARD("HEARD", "شنیده/دیده‌شده", "از ویدئو یا دیگران؛ خودم نیازموده‌ام"),
    UNSURE("UNSURE", "نامطمئن", "نیاز به آزمایش دارد");

    companion object {
        fun fromKey(key: String?): Confidence = entries.firstOrNull { it.key == key } ?: UNSURE
    }
}

/** پیشنهادهای سریع؛ فیلدها متن آزاد هستند و کاربر می‌تواند هر مقدار دیگری بنویسد. */
object Suggestions {
    val carParts = listOf(
        "درب جلو", "درب عقب", "گلگیر جلو", "گلگیر عقب", "کاپوت", "صندوق عقب",
        "سقف", "ستون", "رکاب", "سپر"
    )
    val damageTypes = listOf(
        "فرورفتگی ساده", "فرورفتگی با خط تیز", "چروک", "تا خوردگی", "فشردگی لبه",
        "تگرگ‌زدگی", "کشیدگی ورق", "ضربه با رنگ‌پریدگی"
    )
    val tools = listOf(
        "میله PDR", "چراغ PDR", "گلوپلر (Glue puller)", "چکش صافکاری", "دالی",
        "پتک لاستیکی", "اسپیلر", "تب (Tap down)", "سنباده", "گرمکن"
    )
}
