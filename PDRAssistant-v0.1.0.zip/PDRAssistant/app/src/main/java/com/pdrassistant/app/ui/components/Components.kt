package com.pdrassistant.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pdrassistant.app.ui.theme.PdrColors

/** کارت هلویی برجسته (مثل کارت «Total Bill» در طرح مرجع). */
@Composable
fun PeachCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val base = modifier
        .fillMaxWidth()
        .shadow(8.dp, RoundedCornerShape(28.dp), clip = false)
        .background(PdrColors.Peach, RoundedCornerShape(28.dp))
    Box(
        (if (onClick != null) base.clickable(onClick = onClick) else base).padding(18.dp)
    ) { content() }
}

/** کارت تیره (مثل «Your previous split» و «Nearby Friends»). */
@Composable
fun DarkCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val base = modifier
        .fillMaxWidth()
        .background(PdrColors.Surface, RoundedCornerShape(24.dp))
    Box(
        (if (onClick != null) base.clickable(onClick = onClick) else base).padding(16.dp)
    ) { content() }
}

/** دکمه قرص‌شکل؛ [primary] یعنی هلویی، در غیر این صورت تیره. */
@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = true,
    danger: Boolean = false
) {
    val bg = when {
        danger -> PdrColors.Danger
        primary -> PdrColors.Peach
        else -> PdrColors.SurfaceDeep
    }
    val fg = if (primary || danger) PdrColors.PeachDark else PdrColors.Cream
    Box(
        modifier
            .shadow(if (primary) 6.dp else 0.dp, RoundedCornerShape(20.dp), clip = false)
            .background(bg, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

/** دکمه مربع گرد با آیکن (مثل دکمه برگشت در طرح مرجع). */
@Composable
fun SquareIconButton(icon: ImageVector, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(48.dp)
            .background(PdrColors.Surface, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = PdrColors.Cream)
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    Column(modifier) {
        if (subtitle != null) {
            Text(subtitle, color = PdrColors.Muted, fontSize = 15.sp)
        }
        Text(title, color = PdrColors.Cream, fontSize = 26.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        color = PdrColors.Muted,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        modifier = modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

/** نقطه رنگی کوچک (جایگزین آواتار در طرح مرجع). */
@Composable
fun Dot(color: Color, size: Int = 12) {
    Box(Modifier.size(size.dp).background(color, CircleShape))
}

/** برچسب کوچک قرص‌شکل. */
@Composable
fun Tag(text: String, color: Color = PdrColors.Lavender, onClick: (() -> Unit)? = null, selected: Boolean = false) {
    val base = Modifier
        .background(if (selected) color else color.copy(alpha = 0.22f), RoundedCornerShape(50))
    Box(
        (if (onClick != null) base.clickable(onClick = onClick) else base)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text,
            color = if (selected) PdrColors.PeachDark else PdrColors.Cream,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/** ردیف انتخاب یکی از چند گزینه (برای نوع تعمیر، وضعیت و ...). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> ChoiceRow(
    options: List<T>,
    selected: T?,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { opt ->
            Tag(label(opt), color = PdrColors.Peach, selected = opt == selected, onClick = { onSelect(opt) })
        }
    }
}

/** پیشنهادهای سریع زیر یک فیلد متنی. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SuggestionRow(items: List<String>, onPick: (String) -> Unit) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.padding(top = 6.dp, bottom = 4.dp)
    ) {
        items.forEach { Tag(it, color = PdrColors.Blue, onClick = { onPick(it) }) }
    }
}

@Composable
fun PdrField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    minLines: Int = 1,
    singleLine: Boolean = minLines == 1
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        minLines = minLines,
        singleLine = singleLine,
        shape = RoundedCornerShape(18.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = PdrColors.Peach,
            unfocusedBorderColor = PdrColors.Muted.copy(alpha = 0.5f),
            focusedLabelColor = PdrColors.Peach,
            unfocusedLabelColor = PdrColors.Muted,
            focusedTextColor = PdrColors.Cream,
            unfocusedTextColor = PdrColors.Cream,
            cursorColor = PdrColors.Peach,
            focusedContainerColor = PdrColors.SurfaceDeep.copy(alpha = 0.5f),
            unfocusedContainerColor = PdrColors.SurfaceDeep.copy(alpha = 0.35f)
        ),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun EmptyState(title: String, hint: String) {
    DarkCard {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = PdrColors.Cream, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(6.dp))
            Text(hint, color = PdrColors.Muted, fontSize = 14.sp)
        }
    }
}

/** ردیف «برچسب: مقدار» در صفحه جزئیات؛ اگر مقدار خالی باشد چیزی نشان نمی‌دهد. */
@Composable
fun DetailBlock(label: String, value: String) {
    if (value.isBlank()) return
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(label, color = PdrColors.Muted, fontSize = 13.sp)
        Text(value, color = PdrColors.Cream, fontSize = 16.sp)
    }
}

@Composable
fun Row2(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        content()
    }
}
