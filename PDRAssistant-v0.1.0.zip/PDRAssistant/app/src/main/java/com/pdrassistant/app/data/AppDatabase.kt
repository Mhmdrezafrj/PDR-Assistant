package com.pdrassistant.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/**
 * نسخه ۱ دیتابیس.
 * قانون: هر تغییر در Entityها => version بالا برود + یک Migration نوشته شود (هرگز fallbackToDestructiveMigration نه).
 * طرح‌های دیتابیس در app/schemas ذخیره می‌شوند تا مهاجرت‌های بعدی قابل بررسی باشند.
 */
@Database(entities = [Project::class, Experience::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun experienceDao(): ExperienceDao
    abstract fun backupDao(): BackupDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pdr_assistant.db"
                )
                    // .addMigrations(MIGRATION_1_2) را در نسخه‌های بعدی اینجا اضافه کن
                    .build()
                    .also { instance = it }
            }
    }
}
