package com.pdrassistant.app.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class Repository(private val context: Context, private val db: AppDatabase) {

    val projects: Flow<List<Project>> = db.projectDao().observeAll()
    val experiences: Flow<List<Experience>> = db.experienceDao().observeAll()

    private val mediaDir: File
        get() = File(context.filesDir, "media").also { it.mkdirs() }

    fun mediaFile(name: String): File = File(mediaDir, File(name).name)

    // ---------- پروژه‌ها ----------
    suspend fun saveProject(p: Project): Long {
        val now = System.currentTimeMillis()
        return if (p.id == 0L) {
            db.projectDao().insert(p.copy(createdAt = now, updatedAt = now))
        } else {
            db.projectDao().update(p.copy(updatedAt = now))
            p.id
        }
    }

    suspend fun deleteProject(p: Project) = db.projectDao().delete(p)

    // ---------- تجربه‌ها ----------
    suspend fun saveExperience(e: Experience): Long {
        val now = System.currentTimeMillis()
        return if (e.id == 0L) {
            db.experienceDao().insert(e.copy(createdAt = now, updatedAt = now))
        } else {
            db.experienceDao().update(e.copy(updatedAt = now))
            e.id
        }
    }

    suspend fun deleteExperience(e: Experience) {
        db.experienceDao().delete(e)
        e.mediaFiles.lines().filter { it.isNotBlank() }.forEach { name ->
            withContext(Dispatchers.IO) { mediaFile(name).delete() }
        }
    }

    // ---------- رسانه ----------
    /** فایل انتخاب‌شده را به حافظه داخلی برنامه کپی می‌کند و نام جدید را برمی‌گرداند (یا null). */
    suspend fun importMedia(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val mime = context.contentResolver.getType(uri).orEmpty()
            val ext = when {
                mime.contains("png") -> "png"
                mime.contains("webp") -> "webp"
                mime.startsWith("video/") -> "mp4"
                else -> "jpg"
            }
            val name = "${UUID.randomUUID()}.$ext"
            context.contentResolver.openInputStream(uri)?.use { input ->
                mediaFile(name).outputStream().use { out -> input.copyTo(out) }
            } ?: return@withContext null
            name
        } catch (e: Exception) {
            null
        }
    }

    suspend fun deleteMedia(name: String) = withContext(Dispatchers.IO) { mediaFile(name).delete() }

    // ---------- پشتیبان‌گیری ----------
    suspend fun exportBackup(target: Uri) = withContext(Dispatchers.IO) {
        val json = BackupCodec.encode(
            db.projectDao().getAll(),
            db.experienceDao().getAll(),
            System.currentTimeMillis()
        )
        val out = context.contentResolver.openOutputStream(target, "wt")
            ?: throw BackupCodec.BackupException("امکان نوشتن فایل نیست.")
        out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
    }

    /** اطلاعات فعلی را کاملاً با محتوای پشتیبان جایگزین می‌کند (تراکنشی). تعداد را برمی‌گرداند. */
    suspend fun importBackup(source: Uri): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val text = context.contentResolver.openInputStream(source)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw BackupCodec.BackupException("امکان خواندن فایل نیست.")
        val snap = BackupCodec.decode(text)
        db.backupDao().replaceAll(snap.projects, snap.experiences)
        snap.projects.size to snap.experiences.size
    }
}
