package com.pdrassistant.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

/** پالت برگرفته از طرح مرجع: بنفش تیره، کارت هلویی، تأکیدهای صورتی/آبی/یاسی. */
object PdrColors {
    val Bg = Color(0xFF4B4177)          // پس‌زمینه اصلی
    val Surface = Color(0xFF3E3566)     // کارت‌های تیره
    val SurfaceDeep = Color(0xFF322A57) // نوار پایین، ورودی‌ها
    val Peach = Color(0xFFF4C38C)       // کارت‌های برجسته
    val PeachDark = Color(0xFF3B2F63)   // متن روی کارت هلویی
    val Cream = Color(0xFFFBE9D6)       // متن روی بنفش
    val Pink = Color(0xFFF2A39B)
    val Blue = Color(0xFF8EC5F0)
    val Lavender = Color(0xFFB49CF2)
    val Muted = Color(0xFFB8AEDB)       // متن کم‌اهمیت
    val Danger = Color(0xFFFF8A80)
}

private val scheme = darkColorScheme(
    primary = PdrColors.Peach,
    onPrimary = PdrColors.PeachDark,
    secondary = PdrColors.Lavender,
    onSecondary = PdrColors.PeachDark,
    tertiary = PdrColors.Pink,
    background = PdrColors.Bg,
    onBackground = PdrColors.Cream,
    surface = PdrColors.Surface,
    onSurface = PdrColors.Cream,
    surfaceVariant = PdrColors.SurfaceDeep,
    onSurfaceVariant = PdrColors.Muted,
    error = PdrColors.Danger,
    outline = PdrColors.Muted
)

/** برنامه برای کار در تعمیرگاه فقط یک تم (بنفش تیره) دارد؛ همیشه راست‌به‌چپ. */
@Composable
fun PdrTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            content()
        }
    }
}
