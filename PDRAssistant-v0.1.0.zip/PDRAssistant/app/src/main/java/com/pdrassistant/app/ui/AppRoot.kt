package com.pdrassistant.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.pdrassistant.app.BuildConfig
import com.pdrassistant.app.MainViewModel
import com.pdrassistant.app.ui.screens.BackupScreen
import com.pdrassistant.app.ui.screens.DashboardScreen
import com.pdrassistant.app.ui.screens.ExperienceDetailScreen
import com.pdrassistant.app.ui.screens.ExperienceEditScreen
import com.pdrassistant.app.ui.screens.ExperiencesScreen
import com.pdrassistant.app.ui.screens.ProjectDetailScreen
import com.pdrassistant.app.ui.screens.ProjectEditScreen
import com.pdrassistant.app.ui.screens.ProjectsScreen
import com.pdrassistant.app.ui.theme.PdrColors

private val tabs = listOf(
    Route.Dashboard to "خانه",
    Route.Projects to "پروژه‌ها",
    Route.Experiences to "تجربیات",
    Route.Backup to "پشتیبان"
)

@Composable
fun AppRoot(vm: MainViewModel) {
    val projects by vm.projects.collectAsStateWithLifecycle()
    val experiences by vm.experiences.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.message.value = null
        }
    }

    val stack = remember { mutableStateListOf<Route>(Route.Dashboard) }
    val current = stack.last()
    val isTab = tabs.any { it.first == current }

    fun push(r: Route) { stack.add(r) }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    fun goTab(r: Route) { stack.clear(); stack.add(r) }
    /** بعد از ذخیره: صفحه ویرایش را با صفحه جزئیات جایگزین می‌کند. */
    fun replaceTop(r: Route) {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
        // اگر همین صفحه درست زیر آن بود (ویرایش از داخل جزئیات)، فقط برگرد تا صفحه تکراری نماند.
        if (stack.last() != r) stack.add(r)
    }

    BackHandler(enabled = stack.size > 1) { pop() }

    Scaffold(
        containerColor = PdrColors.Bg,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { if (isTab) BottomBar(current, ::goTab) }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            val ps = projects
            val es = experiences
            if (ps == null || es == null) {
                CircularProgressIndicator(Modifier.align(Alignment.Center), color = PdrColors.Peach)
                return@Box
            }
            when (val r = current) {
                Route.Dashboard -> DashboardScreen(ps, es, ::push)
                Route.Projects -> ProjectsScreen(ps, ::push)
                Route.Experiences -> ExperiencesScreen(es, ::push)
                Route.Backup -> BackupScreen(
                    ps.size, es.size, BuildConfig.VERSION_NAME,
                    onExport = { vm.exportBackup(it) },
                    onImport = { vm.importBackup(it); goTab(Route.Dashboard) }
                )
                is Route.ProjectDetail -> ProjectDetailScreen(
                    project = ps.firstOrNull { it.id == r.id },
                    allExperiences = es,
                    onBack = ::pop, go = ::push,
                    onSaveProject = { vm.saveProject(it) },
                    onDelete = { vm.deleteProject(it) }
                )
                is Route.ProjectEdit -> ProjectEditScreen(
                    existing = r.id?.let { id -> ps.firstOrNull { it.id == id } },
                    onBack = ::pop,
                    onSave = { p, done -> vm.saveProject(p, done) },
                    onSaved = { id -> replaceTop(Route.ProjectDetail(id)) }
                )
                is Route.ExperienceDetail -> {
                    val e = es.firstOrNull { it.id == r.id }
                    ExperienceDetailScreen(
                        experience = e,
                        project = e?.projectId?.let { pid -> ps.firstOrNull { it.id == pid } },
                        allExperiences = es,
                        mediaFile = vm.repo::mediaFile,
                        onBack = ::pop, go = ::push,
                        onDelete = { vm.deleteExperience(it) }
                    )
                }
                is Route.ExperienceEdit -> ExperienceEditScreen(
                    existing = r.id?.let { id -> es.firstOrNull { it.id == id } },
                    fromProject = r.fromProjectId?.let { pid -> ps.firstOrNull { it.id == pid } },
                    mediaFile = vm.repo::mediaFile,
                    onBack = ::pop,
                    onSave = { e, done -> vm.saveExperience(e, done) },
                    onSaved = { id -> replaceTop(Route.ExperienceDetail(id)) },
                    onImportMedia = { uri, cb -> vm.importMedia(uri, cb) },
                    onDeleteMedia = { vm.deleteMedia(it) }
                )
            }
        }
    }
}

/** نوار پایین قرص‌شکل و تیره (الهام از نوار «Confirm Split / Cancel»). */
@Composable
private fun BottomBar(current: Route, onSelect: (Route) -> Unit) {
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(PdrColors.SurfaceDeep, RoundedCornerShape(30.dp))
                .padding(6.dp),
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
        ) {
            tabs.forEach { (route, label) ->
                val sel = route == current
                Box(
                    Modifier
                        .weight(1f)
                        .background(if (sel) PdrColors.Surface else androidx.compose.ui.graphics.Color.Transparent, RoundedCornerShape(24.dp))
                        .clickable { onSelect(route) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        label,
                        color = if (sel) PdrColors.Peach else PdrColors.Muted,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
