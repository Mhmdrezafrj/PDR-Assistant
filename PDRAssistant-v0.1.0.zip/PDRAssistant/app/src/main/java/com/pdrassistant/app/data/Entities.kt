package com.pdrassistant.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** پروژه تعمیراتی (یک خودرو / یک قطعه / یک آسیب). */
@Entity(tableName = "projects")
data class Project(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val vehicle: String = "",          // مثلاً «پژو ۲۰۶ - سفید»
    val plate: String = "",            // اختیاری
    val carPart: String = "",
    val damageType: String = "",
    val repairType: String = "PDR",
    val status: String = "PLANNED",
    val notes: String = "",
    val resultNotes: String = "",      // ارزیابی نتیجه بعد از پایان کار
    val createdAt: Long,
    val updatedAt: Long
)

/** تجربه/تکنیک ثبت‌شده استادکار؛ همه فیلدهای بخش ۶ مستند. */
@Entity(
    tableName = "experiences",
    foreignKeys = [
        ForeignKey(
            entity = Project::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("projectId")]
)
data class Experience(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val repairType: String = "PDR",
    val carPart: String = "",
    val damageType: String = "",
    val tools: String = "",            // هر ابزار در یک خط
    val steps: String = "",            // هر مرحله در یک خط
    val conditions: String = "",       // شرایط استفاده
    val result: String = "",
    val possibleErrors: String = "",   // خطاهای احتمالی
    val mediaFiles: String = "",       // نام فایل‌های داخل حافظه برنامه، هر کدام در یک خط
    val source: String = "",           // منبع اطلاعات
    val confidence: String = "UNSURE",
    val masterNotes: String = "",      // یادداشت استادکار
    val projectId: Long? = null,
    val createdAt: Long,
    val updatedAt: Long
)
