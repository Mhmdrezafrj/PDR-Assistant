package com.pdrassistant.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pdrassistant.app.data.BackupCodec
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Project
import com.pdrassistant.app.data.Repository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val repo: Repository = (app as PdrApp).repository

    val projects: StateFlow<List<Project>?> =
        repo.projects.stateIn(viewModelScope, SharingStarted.Eagerly, null)
    val experiences: StateFlow<List<Experience>?> =
        repo.experiences.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** پیام کوتاه برای کاربر (Toast-مانند). */
    val message = MutableStateFlow<String?>(null)

    fun saveProject(p: Project, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveProject(p)
        onDone(id)
    }

    fun deleteProject(p: Project) = viewModelScope.launch { repo.deleteProject(p) }

    fun saveExperience(e: Experience, onDone: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repo.saveExperience(e)
        onDone(id)
    }

    fun deleteExperience(e: Experience) = viewModelScope.launch { repo.deleteExperience(e) }

    fun importMedia(uri: Uri, onResult: (String?) -> Unit) = viewModelScope.launch {
        val name = repo.importMedia(uri)
        if (name == null) message.value = "افزودن فایل ناموفق بود."
        onResult(name)
    }

    fun deleteMedia(name: String) = viewModelScope.launch { repo.deleteMedia(name) }

    fun exportBackup(uri: Uri) = viewModelScope.launch {
        message.value = try {
            repo.exportBackup(uri)
            "پشتیبان با موفقیت ذخیره شد."
        } catch (e: Exception) {
            "ذخیره پشتیبان ناموفق بود: ${e.message ?: "خطای نامشخص"}"
        }
    }

    fun importBackup(uri: Uri) = viewModelScope.launch {
        message.value = try {
            val (p, e) = repo.importBackup(uri)
            "بازیابی انجام شد: $p پروژه و $e تجربه."
        } catch (e: BackupCodec.BackupException) {
            e.message
        } catch (e: Exception) {
            "بازیابی ناموفق بود؛ اطلاعات فعلی دست‌نخورده ماند."
        }
    }
}
