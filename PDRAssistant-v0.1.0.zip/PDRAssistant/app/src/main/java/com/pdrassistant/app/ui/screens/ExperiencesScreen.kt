package com.pdrassistant.app.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.pdrassistant.app.data.Experience
import com.pdrassistant.app.data.Project
import com.pdrassistant.app.domain.Confidence
import com.pdrassistant.app.domain.RelatedExperiences
import com.pdrassistant.app.domain.RepairType
import com.pdrassistant.app.domain.Suggestions
import com.pdrassistant.app.ui.Route
import com.pdrassistant.app.ui.components.ChoiceRow
import com.pdrassistant.app.ui.components.DarkCard
import com.pdrassistant.app.ui.components.DetailBlock
import com.pdrassistant.app.ui.components.Dot
import com.pdrassistant.app.ui.components.EmptyState
import com.pdrassistant.app.ui.components.PdrField
import com.pdrassistant.app.ui.components.PeachCard
import com.pdrassistant.app.ui.components.PillButton
import com.pdrassistant.app.ui.components.ScreenTitle
import com.pdrassistant.app.ui.components.SectionLabel
import com.pdrassistant.app.ui.components.SuggestionRow
import com.pdrassistant.app.ui.components.Tag
import com.pdrassistant.app.ui.formatDate
import com.pdrassistant.app.ui.repairColor
import com.pdrassistant.app.ui.theme.PdrColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

// ============================ فهرست + جستجو ============================

@Composable
fun ExperiencesScreen(experiences: List<Experience>, go: (Route) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<RepairType?>(null) }

    val q = RelatedExperiences.normalize(query)
    val shown = experiences.filter { e ->
        (filter == null || e.repairType == filter!!.key) &&
            (q.isEmpty() || RelatedExperiences.normalize(
                listOf(e.title, e.carPart, e.damageType, e.tools, e.steps, e.masterNotes, e.source)
                    .joinToString(" ")
            ).contains(q))
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle("حافظه تجربیات", "${experiences.size} تجربه", Modifier.weight(1f))
                PillButton("ثبت", onClick = { go(Route.ExperienceEdit(null)) })
            }
        }
        item { PdrField(query, { query = it }, "جستجو (عنوان، قطعه، آسیب، ابزار، مراحل...)") }
        item {
            ChoiceRow(
                listOf<RepairType?>(null) + RepairType.entries, filter,
                { it?.label ?: "همه" }, { filter = it }
            )
        }
        if (shown.isEmpty()) {
            item {
                EmptyState(
                    if (experiences.isEmpty()) "حافظه خالی است" else "نتیجه‌ای پیدا نشد",
                    if (experiences.isEmpty()) "اولین تکنیک یا تجربه‌تان را ثبت کنید." else "عبارت یا فیلتر را تغییر دهید."
                )
            }
        }
        items(shown, key = { it.id }) { e -> ExperienceRow(e) { go(Route.ExperienceDetail(e.id)) } }
    }
}

@Composable
fun ExperienceRow(e: Experience, onClick: () -> Unit) {
    DarkCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Dot(repairColor(e.repairType), 18)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    e.title, color = PdrColors.Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                val sub = listOf(RepairType.labelOf(e.repairType), e.carPart, e.damageType)
                    .filter { it.isNotBlank() }.joinToString(" · ")
                Text(sub, color = PdrColors.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Tag(Confidence.fromKey(e.confidence).label, color = PdrColors.Peach)
        }
    }
}

// ============================ جزئیات ============================

@Composable
fun ExperienceDetailScreen(
    experience: Experience?,
    project: Project?,
    allExperiences: List<Experience>,
    mediaFile: (String) -> File,
    onBack: () -> Unit,
    go: (Route) -> Unit,
    onDelete: (Experience) -> Unit
) {
    if (experience == null) {
        SubScreen("تجربه", onBack) { EmptyState("تجربه پیدا نشد", "ممکن است حذف شده باشد.") }
        return
    }
    var confirmDelete by remember { mutableStateOf(false) }
    val related = RelatedExperiences.rank(
        experience.repairType, experience.carPart, experience.damageType, allExperiences, excludeId = experience.id
    )
    val conf = Confidence.fromKey(experience.confidence)
    val media = experience.mediaFiles.lines().filter { it.isNotBlank() }

    SubScreen(experience.title, onBack) {
        PeachCard {
            Column {
                Text(RepairType.labelOf(experience.repairType), color = PdrColors.PeachDark, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(experience.title, color = PdrColors.PeachDark, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                Text("اطمینان: ${conf.label} — ${conf.hint}", color = PdrColors.PeachDark, fontSize = 13.sp)
            }
        }

        DarkCard {
            Column {
                DetailBlock("قطعه", experience.carPart)
                DetailBlock("نوع آسیب", experience.damageType)
                DetailBlock("ابزار", experience.tools)
                DetailBlock("مراحل اجرا", experience.steps)
                DetailBlock("شرایط استفاده", experience.conditions)
                DetailBlock("نتیجه", experience.result)
                DetailBlock("خطاهای احتمالی", experience.possibleErrors)
                DetailBlock("منبع اطلاعات", experience.source)
                DetailBlock("یادداشت استادکار", experience.masterNotes)
                if (project != null) DetailBlock("پروژه مرتبط", project.title)
                DetailBlock("آخرین ویرایش", formatDate(experience.updatedAt))
            }
        }

        if (media.isNotEmpty()) {
            SectionLabel("تصاویر و ویدئوها")
            MediaStrip(media, mediaFile, onRemove = null)
        }

        SectionLabel("تجربه‌های مرتبط")
        if (related.isEmpty()) Text("مورد مشابهی در حافظه نیست.", color = PdrColors.Muted, fontSize = 14.sp)
        related.forEach { r -> ExperienceRow(r.experience) { go(Route.ExperienceDetail(r.experience.id)) } }

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("ویرایش", onClick = { go(Route.ExperienceEdit(experience.id)) }, primary = false)
            PillButton("حذف", onClick = { confirmDelete = true }, primary = false)
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            "حذف تجربه؟",
            "تجربه «${experience.title}» و فایل‌های همراه آن برای همیشه حذف می‌شود.",
            "حذف",
            onConfirm = { confirmDelete = false; onDelete(experience); onBack() },
            onDismiss = { confirmDelete = false }
        )
    }
}

// ============================ ایجاد/ویرایش ============================

@Composable
fun ExperienceEditScreen(
    existing: Experience?,
    fromProject: Project?,
    mediaFile: (String) -> File,
    onBack: () -> Unit,
    onSave: (Experience, (Long) -> Unit) -> Unit,
    onSaved: (Long) -> Unit,
    onImportMedia: (Uri, (String?) -> Unit) -> Unit,
    onDeleteMedia: (String) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var repair by remember {
        mutableStateOf(RepairType.fromKey(existing?.repairType ?: fromProject?.repairType) ?: RepairType.PDR)
    }
    var carPart by remember { mutableStateOf(existing?.carPart ?: fromProject?.carPart.orEmpty()) }
    var damage by remember { mutableStateOf(existing?.damageType ?: fromProject?.damageType.orEmpty()) }
    var tools by remember { mutableStateOf(existing?.tools.orEmpty()) }
    var steps by remember { mutableStateOf(existing?.steps.orEmpty()) }
    var conditions by remember { mutableStateOf(existing?.conditions.orEmpty()) }
    var result by remember { mutableStateOf(existing?.result.orEmpty()) }
    var errors by remember { mutableStateOf(existing?.possibleErrors.orEmpty()) }
    var source by remember { mutableStateOf(existing?.source.orEmpty()) }
    var notes by remember { mutableStateOf(existing?.masterNotes.orEmpty()) }
    var confidence by remember { mutableStateOf(Confidence.fromKey(existing?.confidence ?: "ONCE")) }
    val media = remember { mutableStateListOf<String>().also { l ->
        existing?.mediaFiles?.lines()?.filter { it.isNotBlank() }?.let { l.addAll(it) }
    } }
    // فایل‌هایی که در همین جلسه اضافه شده‌اند؛ اگر کاربر بدون ذخیره برگردد باید پاک شوند.
    val addedThisSession = remember { mutableStateListOf<String>() }
    var saved by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris ->
        uris.forEach { uri ->
            onImportMedia(uri) { name -> if (name != null) { media.add(name); addedThisSession.add(name) } }
        }
    }

    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose { if (!saved) addedThisSession.forEach { onDeleteMedia(it) } }
    }

    SubScreen(if (existing == null) "ثبت تجربه" else "ویرایش تجربه", onBack) {
        if (fromProject != null && existing == null) {
            Text("از پروژه «${fromProject.title}» — قطعه و آسیب از پروژه پر شده است.", color = PdrColors.Muted, fontSize = 13.sp)
        }
        PdrField(title, { title = it }, "عنوان تکنیک (الزامی)")

        SectionLabel("نوع تعمیر")
        ChoiceRow(RepairType.entries, repair, { it.label }, { repair = it })

        PdrField(carPart, { carPart = it }, "قطعه خودرو")
        SuggestionRow(Suggestions.carParts) { carPart = it }
        PdrField(damage, { damage = it }, "نوع آسیب")
        SuggestionRow(Suggestions.damageTypes) { damage = it }

        PdrField(tools, { tools = it }, "ابزار مورد استفاده (هر ابزار در یک خط)", minLines = 2)
        SuggestionRow(Suggestions.tools) { t -> tools = if (tools.isBlank()) t else tools.trimEnd() + "\n" + t }
        PdrField(steps, { steps = it }, "مراحل اجرا (هر مرحله در یک خط)", minLines = 4)
        PdrField(conditions, { conditions = it }, "شرایط استفاده (جنس ورق، ضخامت، دما، دسترسی...)", minLines = 2)
        PdrField(result, { result = it }, "نتیجه", minLines = 2)
        PdrField(errors, { errors = it }, "خطاهای احتمالی", minLines = 2)

        SectionLabel("تصاویر و ویدئوها")
        if (media.isNotEmpty()) {
            MediaStrip(media.toList(), mediaFile, onRemove = { name ->
                media.remove(name)
                // اگر فایل همین جلسه اضافه شده بود فوراً پاک می‌شود؛ فایل‌های قدیمی بعد از ذخیره پاک می‌شوند.
                if (addedThisSession.remove(name)) onDeleteMedia(name)
            })
        }
        PillButton(
            "افزودن تصویر یا ویدئو",
            onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
            },
            primary = false
        )

        PdrField(source, { source = it }, "منبع اطلاعات (ویدئو، استاد، تجربه خودم...)")

        SectionLabel("میزان اطمینان: ${confidence.label}")
        val steps4 = Confidence.entries.reversed() // از نامطمئن تا آزموده‌شده
        Slider(
            value = steps4.indexOf(confidence).toFloat(),
            onValueChange = { v -> confidence = steps4[v.toInt().coerceIn(0, steps4.lastIndex)] },
            valueRange = 0f..(steps4.lastIndex).toFloat(),
            steps = steps4.size - 2,
            colors = SliderDefaults.colors(
                thumbColor = PdrColors.Peach,
                activeTrackColor = PdrColors.Lavender,
                inactiveTrackColor = PdrColors.SurfaceDeep,
                activeTickColor = PdrColors.Cream,
                inactiveTickColor = PdrColors.Muted
            )
        )
        Text(confidence.hint, color = PdrColors.Muted, fontSize = 13.sp)

        PdrField(notes, { notes = it }, "یادداشت استادکار", minLines = 3)

        PillButton(
            if (saving) "در حال ذخیره..." else "ذخیره",
            onClick = {
                if (title.isNotBlank() && !saving) {
                    saving = true
                    saved = true
                    val removedOld = (existing?.mediaFiles?.lines() ?: emptyList())
                        .filter { it.isNotBlank() && it !in media }
                    val base = existing ?: Experience(title = "", createdAt = 0, updatedAt = 0)
                    onSave(
                        base.copy(
                            title = title.trim(), repairType = repair.key, carPart = carPart.trim(),
                            damageType = damage.trim(), tools = tools.trim(), steps = steps.trim(),
                            conditions = conditions.trim(), result = result.trim(),
                            possibleErrors = errors.trim(), mediaFiles = media.joinToString("\n"),
                            source = source.trim(), confidence = confidence.key, masterNotes = notes.trim(),
                            projectId = existing?.projectId ?: fromProject?.id
                        )
                    ) { id ->
                        removedOld.forEach { onDeleteMedia(it) }
                        onSaved(id)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
        )
        if (title.isBlank()) Text("برای ذخیره، عنوان را وارد کنید.", color = PdrColors.Muted, fontSize = 13.sp)
    }
}

// ============================ رسانه ============================

@Composable
private fun MediaStrip(names: List<String>, mediaFile: (String) -> File, onRemove: ((String) -> Unit)?) {
    val context = LocalContext.current
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(names, key = { it }) { name ->
            val file = mediaFile(name)
            val isVideo = name.endsWith(".mp4")
            val thumb by produceThumb(file, isVideo)
            Box(
                Modifier
                    .size(110.dp)
                    .background(PdrColors.SurfaceDeep, RoundedCornerShape(18.dp))
                    .clickable { openFile(context, file, isVideo) },
                contentAlignment = Alignment.Center
            ) {
                val bmp = thumb
                if (bmp != null) {
                    Image(
                        bitmap = bmp.asImageBitmap(), contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().background(PdrColors.SurfaceDeep, RoundedCornerShape(18.dp))
                    )
                }
                if (isVideo) Text("▶", color = PdrColors.Cream, fontSize = 28.sp)
                if (bmp == null && !isVideo) Text("؟", color = PdrColors.Muted, fontSize = 24.sp)
                if (onRemove != null) {
                    Box(
                        Modifier.align(Alignment.TopStart).padding(6.dp).size(28.dp)
                            .background(PdrColors.Danger, RoundedCornerShape(10.dp))
                            .clickable { onRemove(name) },
                        contentAlignment = Alignment.Center
                    ) { Text("✕", color = PdrColors.PeachDark, fontSize = 14.sp) }
                }
            }
        }
    }
}

@Composable
private fun produceThumb(file: File, isVideo: Boolean) =
    androidx.compose.runtime.produceState<Bitmap?>(initialValue = null, file.path) {
        value = withContext(Dispatchers.IO) { loadThumb(file, isVideo) }
    }

private fun loadThumb(file: File, isVideo: Boolean): Bitmap? = try {
    if (!file.exists()) null
    else if (isVideo) {
        val r = MediaMetadataRetriever()
        try { r.setDataSource(file.absolutePath); r.getFrameAtTime(0) } finally { r.release() }
    } else {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 400 && bounds.outHeight / (sample * 2) >= 400) sample *= 2
        BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }
} catch (e: Exception) {
    null
}

private fun openFile(context: Context, file: File, isVideo: Boolean) {
    if (!file.exists()) return
    try {
        val uri = FileProvider.getUriForFile(context, "com.pdrassistant.app.files", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, if (isVideo) "video/*" else "image/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        // برنامه‌ای برای نمایش فایل نصب نیست؛ کاربر پیام دیگری نیاز ندارد.
    }
}
